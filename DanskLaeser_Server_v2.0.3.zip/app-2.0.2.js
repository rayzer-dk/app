(function (env) {
 'use strict';
 const stores = new Map();
 env.StudyProgress = function (name) {
  if (!env.indexedDB) return null;
  if (stores.has(name)) return stores.get(name);
  const opened = new Promise((resolve,reject) => {
   const request = env.indexedDB.open(name,1);
   request.onupgradeneeded = () => request.result.createObjectStore('data');
   request.onblocked = () => reject(new Error('Study database is busy'));
   request.onerror = () => reject(request.error);
   request.onsuccess = () => {
    request.result.onversionchange = () => request.result.close();
    resolve(request.result);
   };
  });
  opened.catch(() => {});
  const run = async (mode,operation) => {
   const db=await opened;
   return new Promise((resolve,reject)=>{
    const tx=db.transaction('data',mode);
    const request=operation(tx.objectStore('data'));
    tx.oncomplete=()=>resolve(request.result);
    tx.onabort=()=>reject(tx.error);
   });
  };
  const api={
   read:key=>run('readonly',store=>store.get(key)),
   write:(key,value)=>run('readwrite',store=>store.put(value,key))
  };
  stores.set(name,api);
  return api;
 };
})(globalThis);


/* DanskLæser: полностью автономная читательская PWA. Без внешних библиотек. */
(() => {
'use strict';
const STORAGE = 'dansklaeser.state.v1';
const DEFAULT = {theme:'light',fontSize:20,rate:0.85,voice:'',favorites:{},translations:{},positions:{},bookmarks:{},customBooks:[],lastBook:null,sentenceOffsets:{},phraseTranslations:{},bookSort:"featured",paragraphTranslations:false,readerFocus:false,paper:'auto',spacing:'normal',wideReader:false,paperBackground:'#f7edda',paperText:'#38291b'};
const builtinBooks = window.DANSK_BOOKS || [];
const classicBooks = (window.DANSK_FULL_BOOKS || []).filter(b=>Array.isArray(b.paragraphs)&&b.paragraphs.length>0);
let activeAnchor = null, readerFirst = 0, readerLast = 0;
const lexicon = window.DANSK_LEXICON || {};
const {reviewed: reviewedWords = {}, reference: referenceWords = {}, generated: generatedWords = {}, forms: wordForms = {}} = window.DANSK_OFFLINE_DICTIONARY || {};
const synth = 'speechSynthesis' in window ? window.speechSynthesis : null;
let view = 'library', activeBookId = null, activeWord = null;
let fullscreenReader = null;
let voices = [], deferredInstall = null, reading = false, paused = false;
const appIsStandalone=window.matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
let readerNavIds=[], sentenceMode=false, sentenceIndex=0, reviewWords=[], reviewIndex=0, reviewRevealed=false;
let vocabLimit=100, batchController=null, translationVersion=0;
let pageHistory=true;
let pageLimit=24;let toastTimer = null, scrollTimer = null, favoriteQuery = '', searchQuery = '', selectedLevel='all', selectedGenre='all', selectedLength='all', onlinePending=false, vocabQuery='', vocabOnlyMissing=false, batchRunning=false;
const $ = (selector,root=document) => root.querySelector(selector);
const $$ = (selector,root=document) => [...root.querySelectorAll(selector)];
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const ICON_PATHS={"book":"<path d=\"M3 19.2V5.5C3 4.1 4 3.2 5.5 3.2c2.5 0 4.4.8 6.5 2.1 2.1-1.3 4-2.1 6.5-2.1 1.5 0 2.5.9 2.5 2.3v13.7c-3-.4-5.9.2-9 2-3.1-1.8-6-2.4-9-2Z\"/><path d=\"M12 5.3v15.9\"/>","home":"<path d=\"m3 10 9-7 9 7v10H3z\"/><path d=\"M9 20v-6h6v6\"/>","heart":"<path d=\"M20.8 8c0 4.4-8.8 11-8.8 11S3.2 12.4 3.2 8A4.8 4.8 0 0 1 12 5.5 4.8 4.8 0 0 1 20.8 8Z\"/>","settings":"<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"m19.6 12 1.1-2-2-3.5-2.3.1-1.2-.7L14 3.7h-4L8.8 6l-1.2.7-2.3-.1-2 3.5 1.1 2-1.1 2 2 3.5 2.3-.1 1.2.7L10 20.3h4l1.2-2.2 1.2-.7 2.3.1 2-3.5-1.1-2Z\"/>","search":"<circle cx=\"10.8\" cy=\"10.8\" r=\"6.8\"/><path d=\"m16 16 5 5\"/>","chevron-right":"<path d=\"m9 6 6 6-6 6\"/>","chevron":"<path d=\"m15 18-6-6 6-6\"/>","play":"<path d=\"m8 5 11 7-11 7z\"/>","pause":"<path d=\"M7 5h3v14H7zm7 0h3v14h-3z\"/>","stop":"<rect x=\"5\" y=\"5\" width=\"14\" height=\"14\" rx=\"2\"/>","volume":"<path d=\"M11 5 6.7 9H3v6h3.7l4.3 4zM15 9a4 4 0 0 1 0 6m2.8-9a8 8 0 0 1 0 12\"/>","edit":"<path d=\"M12 20h9\"/><path d=\"m16 4 4 4-11 11-5 1 1-5L16 4Z\"/>","bookmark":"<path d=\"M6 3.5h12a1 1 0 0 1 1 1V21l-7-4.5L5 21V4.5a1 1 0 0 1 1-1Z\"/>","plus":"<path d=\"M12 4v16M4 12h16\"/>","check":"<path d=\"m4 12 5 5L20 6\"/>","trash":"<path d=\"M4 7h16M9 7V4h6v3m-9 0 1 13h10l1-13M10 11v6m4-6v6\"/>","download":"<path d=\"M12 3v13m-5-5 5 5 5-5M4 18v3h16v-3\"/>","upload":"<path d=\"M12 19V6m-5 5 5-5 5 5M4 5V3h16v2\"/>","sun":"<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4\"/>","moon":"<path d=\"M20.7 14.4A8.7 8.7 0 0 1 9.6 3.3a8.7 8.7 0 1 0 11.1 11.1Z\"/>","x":"<path d=\"M5 5 19 19M19 5 5 19\"/>","external":"<path d=\"M14 4h6v6m0-6-9 9\"/><path d=\"M20 13v7H4V4h7\"/>","copy":"<rect x=\"8\" y=\"8\" width=\"12\" height=\"12\" rx=\"2\"/><path d=\"M16 8V4H4v12h4\"/>","info":"<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 11v6M12 7v.1\"/>","menu":"<path d=\"M4 6h16M4 12h16M4 18h16\"/>"};
ICON_PATHS.share='<path d="M12 16V3m-4 4 4-4 4 4M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>';
ICON_PATHS.refresh='<path d="M20 10a8 8 0 0 0-13.7-4.6L4 8m0-5v5h5m-5 6a8 8 0 0 0 13.7 4.6L20 16m0 5v-5h-5"/>';
ICON_PATHS.maximize='<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3m0 8v3a2 2 0 0 1-2 2h-3m-8 0H5a2 2 0 0 1-2-2v-3"/>';
ICON_PATHS.minimize='<path d="M8 3v3a2 2 0 0 1-2 2H3m13-5v3a2 2 0 0 0 2 2h3m0 8h-3a2 2 0 0 0-2 2v3m-8 0v-3a2 2 0 0 0-2-2H3"/>';
const icon=(name)=>`<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[name]||ICON_PATHS.info}</svg>`;
const norm = (w) => String(w||'').toLocaleLowerCase('da-DK').normalize('NFC');
const wordPattern = /[\p{L}\p{M}]+(?:[’'][\p{L}\p{M}]+)?/gu;
let state = loadState();
const bundledBooks=[...builtinBooks.filter(b=>b.paragraphRu),...classicBooks.filter(b=>b.paragraphRu),...builtinBooks.filter(b=>!b.paragraphRu),...classicBooks.filter(b=>!b.paragraphRu)];
const allBooks = () => [...bundledBooks,...onlineSaved.values(),...state.customBooks];
const getBook = (id) => allBooks().find(b=>b.id===id);
function freshState(){return {...DEFAULT,favorites:Object.create(null),translations:Object.create(null),positions:Object.create(null),bookmarks:Object.create(null),sentenceOffsets:Object.create(null),phraseTranslations:Object.create(null),customBooks:[]};}
function record(value){return value && typeof value==='object' && !Array.isArray(value)?Object.entries(value):[];}
function cleanState(raw){
 const s=freshState();
 s.theme=raw.theme==='dark'?'dark':'light';
 s.fontSize=Math.round(Math.max(16,Math.min(32,Number(raw.fontSize)||20)));
 s.rate=[.7,.85,1,1.15,1.3].includes(Number(raw.rate))?Number(raw.rate):.85;
 s.voice=typeof raw.voice==='string'?raw.voice.slice(0,200):'';
 for(const [key,t] of record(raw.translations))if(key.length<90 && typeof t==='string' && t.trim())s.translations[norm(key)]=t.slice(0,300);
 for(const [key,v] of record(raw.favorites))if(key.length<90 && v && typeof v.translation==='string'){
  s.favorites[norm(key)]={translation:v.translation.slice(0,300),learned:!!v.learned,addedAt:Number(v.addedAt)||0};
 }
 for(const key of ['positions','bookmarks','sentenceOffsets']){
  for(const [id,v] of record(raw[key]))if(/^[a-z0-9-]{1,100}$/i.test(id)&&Number.isInteger(v)&&v>=0)s[key][id]=v;
 }
 if(Array.isArray(raw.customBooks)){
  const ids=new Set();
  s.customBooks=raw.customBooks.map(sanitizeBook).filter(b=>{
   if(!b || ids.has(b.id))return false;
   ids.add(b.id);return true;
  });
 }
 s.lastBook=typeof raw.lastBook==='string'?raw.lastBook:null;
 s.paragraphTranslations=raw.paragraphTranslations===true;
 s.bookSort=['shortest','longest'].includes(raw.bookSort)?raw.bookSort:'featured';
 for(const [key,value] of record(raw.phraseTranslations).slice(-250)){
  if(key.length<=1300&&typeof value==='string'&&value.trim())s.phraseTranslations[key]=value.slice(0,2600);
 }
 s.readerFocus=raw.readerFocus===true;
 s.paper=['auto','light','sepia','dark','custom'].includes(raw.paper)?raw.paper:'auto';
 s.wideReader=raw.wideReader===true;
 s.paperBackground=safeColor(raw.paperBackground,DEFAULT.paperBackground);
 s.paperText=safeColor(raw.paperText,DEFAULT.paperText);
 s.spacing=['normal','wide'].includes(raw.spacing)?raw.spacing:'normal';
 return s;
}
const bookProgress=window.StudyProgress?.('dansklaeser-study');
let savedSinceOpen=false;
function loadState(){
 try{const value=JSON.parse(localStorage.getItem(STORAGE));return value&&typeof value==='object'?cleanState(value):freshState();}
 catch{return freshState();}
}
function persist(next=state){
 savedSinceOpen=true;
 const value=JSON.stringify(next);
 try{localStorage.setItem(STORAGE,value);bookProgress?.write('progress',value).catch(()=>{});return true;}
 catch{toast('Не удалось сохранить данные. Проверьте настройки и свободное место в браузере.');return false;}
}

function toast(message){const node=$('#toast');node.textContent=message;node.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.remove('visible'),3000);}
function applyTheme(){
 const dark=state.theme==='dark';
 document.body.classList.toggle('dark',dark);
 $('meta[name="theme-color"]').content=dark?'#14201e':'#f7f8f5';
 $('#themeQuick').innerHTML=icon(dark?'sun':'moon');
 $('#themeQuick').setAttribute('aria-pressed',String(dark));
}
function setTheme(theme){state.theme=theme==='dark'?'dark':'light';applyTheme();persist();}
function closeMenu(){$('#sidebar').classList.remove('open');$('#sidebarScrim').hidden=true;$('#mobileMenu').setAttribute('aria-expanded','false');}
function updateSideNav(){ $$('.nav-item,.mobile-tab').forEach(x=>{const active=x.dataset.view===(['reader','vocabulary','online'].includes(view)?'library':view);x.classList.toggle('active',active);if(x.classList.contains('mobile-tab'))x.setAttribute('aria-current',active?'page':'false');});$('#favCounter').textContent=Object.keys(state.favorites).length;}
function syncRoute(replace=false){
 if(!pageHistory)return;
 const route=view==='reader'||view==='vocabulary'?`#${view}/${encodeURIComponent(activeBookId)}`:view==='library'?'':`#${view}`;
 if(location.hash!==route)history[replace?'replaceState':'pushState'](null,'',location.pathname+location.search+route);
}
function restoreRoute(){
 pageHistory=false;
 try{
  const [target,id]=location.hash.slice(1).split('/');
  const book=id?getBook(decodeURIComponent(id)):null;
  if(book&&(target==='reader'||target==='vocabulary')){openBook(book.id);if(target==='vocabulary')renderVocabulary();}
  else setView(['favorites','settings','online'].includes(target)?target:'library');
 }catch{setView('library');}
 finally{pageHistory=true;}
}
function leaveReader(save=true){
 clearTimeout(scrollTimer);
 if(view==='reader'&&save)updateReaderProgress();
 if(fullscreenReader){
  const native=fullscreenReader.native;
  resetFullscreenReader(fullscreenReader,false);
  if(native&&document.fullscreenElement===document.documentElement)document.exitFullscreen().catch(()=>{});
 }
 cancelBatch();
 stopReading();
 closePanel();
 closeMenu();
}
function setView(next){
 if(view==='online')cancelOnline();
 leaveReader();
 view=next;
 if(next==='library'){readerNavIds=[];renderLibrary();}
 else if(next==='favorites')renderFavorites();
 else if(next==='settings')renderSettings();
 else if(next==='online')renderOnline();
 $('#pageContent').scrollTop=0;
 syncRoute();
}
function progressFor(book){
 const p=state.positions[book.id];
 if(p==null)return 0;
 if(p>=book.paragraphs.length-1)return 100;
 return Math.min(99,Math.round((p+1)/book.paragraphs.length*100));
}
const bookTimes=new WeakMap();
function bookMinutes(book){
 if(!bookTimes.has(book))bookTimes.set(book,Math.max(1,Math.ceil(book.paragraphs.join(' ').split(/\s+/).length/145)));
 return bookTimes.get(book);
}

function filteredBooks(){const found=allBooks().filter(b=>{
 const q=`${b.title} ${b.titleRu||''} ${b.author||''} ${b.level} ${b.genre} ${b.summary||''}`.toLocaleLowerCase('ru');
 return (!searchQuery||q.includes(searchQuery.toLocaleLowerCase('ru'))) && (selectedLevel==='all'||b.level===selectedLevel) && (selectedGenre==='all'||(selectedGenre==='other'?!['Eventyr','Fabel','Digt','Roman','Мой текст'].includes(b.genre):b.genre===selectedGenre)) && (selectedLength==='all'||(selectedLength==='full'&&b.fullOriginal)||(selectedLength==='short'&&!b.fullOriginal&&b.level!=='TXT')||(selectedLength==='translated'&&b.paragraphRu)||(selectedLength==='bookmarked'&&state.bookmarks[b.id]!=null));
});
 const sort=state.bookSort;
 if(sort==='featured')return found;
 return found.sort((a,b)=>{
  const diff=bookMinutes(a)-bookMinutes(b);
  return (sort==='shortest'?diff:-diff)||a.title.localeCompare(b.title,'da');
 });
}
function updateBookResults(){const grid=$('#bookGrid');if(!grid)return;const found=filteredBooks();grid.innerHTML=found.length?found.slice(0,pageLimit).map(bookCard).join(''):'<div class="empty-state">Ничего не найдено. Измените фильтр или строку поиска.</div>';const c=$('#resultsCount');if(c)c.textContent=`Показано ${Math.min(pageLimit,found.length)} из ${found.length} произведений`;const more=$('#loadMoreBooks');if(more)more.hidden=pageLimit>=found.length;}
function renderLibrary(){
  view='library';updateSideNav();$('#crumb').textContent='Библиотека';
  const resume=getBook(state.lastBook), levels=['all','A1','A2','B1','B2','C1','C2'];
  $('#pageContent').innerHTML=`<div class="page-inner library-page">
   <div class="hero"><div class="hero-copy"><div class="page-eyebrow">ЧТЕНИЕ НА ДАТСКОМ · A1–C2</div><h1 class="page-title">Откройте датский<br><em>через истории.</em></h1><p class="page-description">Сказки, рассказы и тексты для всех уровней. Нажмите на слово, узнайте перевод, добавьте в словарь и слушайте датскую озвучку.</p><div class="hero-facts"><span>${allBooks().length} текстов</span><span>${classicBooks.length} полных оригиналов офлайн</span><span>6 уровней</span></div>${resume?`<button class="button button-primary hero-continue" data-act="open-book" data-id="${esc(resume.id)}">${icon('play')} Продолжить: ${esc(resume.title)}</button>`:''}</div><div class="hero-art" aria-hidden="true"><div class="art-sun"></div><div class="art-book art-back"></div><div class="art-book art-front"><span>DANSK</span><strong>Danske<br>eventyr</strong><small>LÆS · LYT · LÆR</small></div><div class="art-leaf">✧</div></div></div>
   <div class="library-toolbar"><div><h2 class="section-heading">Библиотека</h2><p class="section-hint" id="resultsCount"></p></div><div class="toolbar-right"><label class="search-wrapper">${icon('search')}<input type="search" id="bookSearch" placeholder="Название, автор, тема..." value="${esc(searchQuery)}" aria-label="Поиск по книгам"></label><button class="button import-button" data-act="import-txt" title="Добавить текст TXT">${icon('plus')}<span>Мой текст</span></button></div></div>
   <div class="filter-bar"><div class="level-filters" role="group" aria-label="Уровень чтения">${levels.map(l=>`<button type="button" class="filter-pill ${selectedLevel===l?'active':''}" data-act="filter-level" data-level="${l}" aria-pressed="${selectedLevel===l}">${l==='all'?'Все уровни':l}</button>`).join('')}</div><div class="genre-filters"><label class="visually-hidden" for="lengthFilter">Тип текста</label><select id="lengthFilter" class="genre-select"><option value="all">Все тексты</option><option value="full">Полные оригиналы</option><option value="short">Учебные тексты</option><option value="translated">С переводом абзацев</option><option value="bookmarked">С закладками</option></select><label class="visually-hidden" for="genreFilter">Жанр</label><select id="genreFilter" class="genre-select"><option value="all">Все жанры</option><option value="Eventyr">Сказки</option><option value="Fabel">Басни</option><option value="Roman">Романы</option><option value="Digt">Стихи</option><option value="Мой текст">Мои тексты</option><option value="other">Рассказы и эссе</option></select></div></div>
   <div class="library-controls"><label class="visually-hidden" for="bookSort">Сортировка по времени чтения</label><select id="bookSort" class="genre-select" aria-label="Сортировка по времени чтения"><option value="featured">По умолчанию</option><option value="shortest">Время: короткие сначала</option><option value="longest">Время: длинные сначала</option></select><button class="button" data-act="online-library">${icon('download')} Онлайн-библиотека</button></div>
   <div class="corpus-toolbar"><div><strong>Классика на датском</strong><small>${classicBooks.length} полных текстов · ${allBooks().filter(b=>b.paragraphRu).length} с переводом абзацев</small></div><span class="corpus-ready">${icon('check')} Офлайн</span></div><div class="book-grid" id="bookGrid"></div><button type="button" id="loadMoreBooks" data-act="load-more-books" class="more-story" hidden>Показать ещё книги</button>
   <div class="feature-strip">${icon('info')}<div><strong>Встроенные и загруженные книги доступны офлайн.</strong><span>Для изучения используются встроенный датско-русский словарь и сохранённые вами переводы. Сложные словоформы могут отсутствовать в словаре.</span></div></div>
  </div>`;
  $('#bookSearch').addEventListener('input',e=>{searchQuery=e.target.value;pageLimit=24;updateBookResults();});
  $('#lengthFilter').value=selectedLength;
  $('#lengthFilter').addEventListener('change',e=>{selectedLength=e.target.value;pageLimit=24;updateBookResults();});
  $('#bookSort').value=state.bookSort;
  $('#bookSort').addEventListener('change',e=>{state.bookSort=e.target.value;persist();pageLimit=24;updateBookResults();});
  $('#genreFilter').value=selectedGenre;
  $('#genreFilter').addEventListener('change',e=>{selectedGenre=e.target.value;pageLimit=24;updateBookResults();});
  updateBookResults();
}
function bookCard(book){
 const p=progressFor(book),full=!!book.fullOriginal;
 const kind=full?`Оригинал · ${esc(book.author)}`:book.genre==='Eventyr'?'Учебный пересказ':book.genre==='Fabel'?'Басня · учебный пересказ':esc(genreLabel(book.genre)||'Рассказ');
 const length=`${bookMinutes(book)} мин${book.paragraphRu?' · есть перевод':''}`;
 return `<article tabindex="0" role="button" aria-label="Открыть книгу ${esc(book.title)}" data-act="open-book" data-id="${esc(book.id)}" class="book-card ${full?'book-card-full':''}"><div class="book-card-cover" style="--cover:${esc(book.color||'#e5e9e5')};--accent:${esc(book.accent||'#547d67')}"><span class="cover-level">${esc(book.level)}</span><span class="cover-mark">${full?'ОРИГИНАЛ':book.genre==='Eventyr'?'EVENTYR':'LÆSNING'}</span></div><div class="book-card-body"><div class="book-author">${kind}</div><h3 class="book-name" lang="da">${esc(book.title)}</h3><div class="book-name-ru" lang="ru">${esc(book.titleRu||'')}</div><div class="book-summary">${esc(book.summary||'Ваш текст на датском языке')}</div><div class="book-meta"><span>${length}${p?` · ${p}%`:''}</span><span class="book-open">${p?'Продолжить':'Читать'}${icon('chevron')}</span></div>${p?`<div class="progress-track"><div style="width:${p}%"></div></div>`:''}</div></article>`;
}
function paragraphPlay(p){return `<button type="button" class="paragraph-play" data-act="tts-from" data-p="${p}" title="Читать с этого абзаца" aria-label="Читать с абзаца ${p+1}" aria-pressed="false">${icon('play')}</button>`;}
function paragraphHTML(text,p,offset=0){const found=String(text).matchAll(wordPattern);let result='',last=0;for(const match of found){result+=esc(text.slice(last,match.index));const w=match[0];result+=`<button type="button" class="word" data-act="lookup" data-word="${esc(w)}" data-p="${p}" data-pos="${offset+match.index}" title="Перевести: ${esc(w)}">${esc(w)}</button>`;last=match.index+w.length;}return result+esc(text.slice(last));}
function openBook(id,position){
 const book=getBook(id);
 if(!book)return toast('Книга не найдена');
 if(view==='online')cancelOnline();
 const fromLibrary=view==='library';
 leaveReader(position==null);
 if(fromLibrary||!readerNavIds.includes(id)){
  const filtered=filteredBooks().map(b=>b.id);
  readerNavIds=filtered.includes(id)?filtered:allBooks().map(b=>b.id);
 }
 activeBookId=id;view='reader';sentenceMode=false;
 state.lastBook=id;
 if(position!=null)storeReadingPosition(book,position);
 else persist();
 updateSideNav();syncRoute();
 $('#crumb').textContent=book.title;
 const bookmark=Math.min(state.positions[id]||0,book.paragraphs.length-1);const percent=progressFor(book);readerFirst=Math.max(0,bookmark-3);readerLast=Math.min(book.paragraphs.length,readerFirst+12);
 $('#pageContent').innerHTML=`<div class="reader-screen"><div class="reader-toolbar"><div class="reader-book-title"><button class="icon-button" data-act="back-library" title="Вернуться в библиотеку" aria-label="Вернуться в библиотеку">${icon('chevron')}</button><div><div class="name">${esc(book.title)}</div><div class="sub">${esc(book.titleRu||'')} · ${esc(book.level)} · <span id="progressLabel">${percent?`${percent}%`:'Начало'}</span></div></div><button type="button" class="icon-button reader-fullscreen-enter" data-act="reader-fullscreen" title="На весь экран" aria-label="На весь экран">${icon('maximize')}</button></div>
 <div class="reader-actions">${speedControl()}<button class="button button-primary" id="ttsPlay" data-act="tts-toggle" title="Начать или приостановить чтение">${icon('play')}<span>Слушать</span></button>
 <button class="button" id="ttsStop" data-act="tts-stop" title="Остановить озвучку" aria-label="Остановить озвучку" disabled>${icon('stop')}</button>
 <button class="button" id="sentenceMode" data-act="sentence-mode" aria-pressed="false" title="Читать по предложениям">${icon('book')}<span>По фразам</span></button>
 <details class="reader-controls"><summary class="button" title="Оформление чтения" aria-label="Оформление чтения"><span class="reader-aa">Aa</span><span class="reader-more-caption">Вид текста</span></summary><div class="reader-control-panel">
 <div class="reader-control-options">
 <div class="reader-control-row"><span>Размер шрифта</span><div class="font-buttons"><button data-act="font-minus" title="Уменьшить шрифт">A−</button><button data-act="font-plus" title="Увеличить шрифт">A+</button></div></div>

 ${appearanceControls(false)}
 </div>
 <div class="reader-control-actions">
 <button class="button" data-act="reader-focus" aria-pressed="false">${icon('book')} Режим чтения</button>
 ${book.paragraphRu?'<button class="button" data-act="paragraph-translations" aria-pressed="false">Перевод под текстом</button>':''}
 <button class="button" data-act="bookmark" title="Сохранить текущую позицию">${icon('bookmark')} Закладка</button>
 <button class="button bookmark-jump" data-act="jump-bookmark" ${state.bookmarks[id]==null?'hidden':''}>${icon('chevron')} К закладке</button>
 <button class="button" data-act="book-vocabulary">${icon('book')} Все слова</button>${book.level==='TXT'?'<button class="button" data-act="delete-text">Удалить мой текст</button>':book.onlineSaved?'<button class="button" data-act="delete-online">Удалить загруженную копию</button>':''}
 ${resetAppearanceButton}
 </div></div></details></div></div>
 <div class="reader-area" id="readerArea"><article class="reader-paper" style="--reader-font:${state.fontSize}px"><section id="sentenceCard" class="sentence-card" aria-label="Чтение по предложениям" hidden></section><div id="readerFlow"><div class="reading-eyebrow">${esc(genreLabel(book.genre))} · ${esc(book.level)}</div><h1 class="reading-title" lang="da">${esc(book.title)}</h1><div class="reading-title-ru">${esc(book.titleRu||'')}</div><div class="reading-subtitle">${esc(book.author)} · Датский язык</div>${book.onlineSaved&&!book.fullOriginal?`<div class="source-note">Текст из датского Викиисточника. <a href="${esc(book.sourceUrl)}" target="_blank" rel="noopener noreferrer">Источник ↗</a></div>`:book.fullOriginal?`<div class="source-note"><strong>Полный оригинал, сохранённый в библиотеке.</strong> ${esc(book.sourceTitle||'')}${book.verse?' · историческое написание.':''}${book.sourceUrl?` <a href="${esc(book.sourceUrl)}" target="_blank" rel="noopener noreferrer">Источник ↗</a>`:''}</div>`:book.sourceTitle?`<div class="source-note">Учебный пересказ по мотивам «${esc(book.sourceTitle)}»${book.sourceUrl?` · <a href="${esc(book.sourceUrl)}" target="_blank" rel="noopener noreferrer">Оригинальный источник ↗</a>`:''}</div>`:''}<div class="reading-rule"></div><div class="reader-hint">${icon('info')}Нажмите слово для перевода или кнопку ▶ возле абзаца для чтения с выбранного места.</div><button type="button" id="readerMorePrev" class="more-story" data-act="reader-previous" ${readerFirst===0?'hidden':''}>↑ Показать предыдущие абзацы</button><section class="story-text ${book.verse?'verse':''}" id="storyText">${book.paragraphs.slice(readerFirst,readerLast).map((_,i)=>storyParagraph(book,readerFirst+i)).join('')}</section><button type="button" id="readerMoreNext" class="more-story" data-act="reader-next" ${readerLast===book.paragraphs.length?'hidden':''}>Читать дальше ↓</button><div class="reader-end" id="readerEnd" ${readerLast!==book.paragraphs.length?'hidden':''}><strong lang="da">Slut. Godt læst!</strong>Вы дочитали произведение.</div><nav class="book-neighbor-nav" aria-label="Переход между книгами"><button class="button" data-act="previous-book" title="Предыдущая книга">${icon('chevron')}<span>Предыдущая</span></button><button class="button" data-act="back-library" title="Библиотека">${icon('book')}<span>Библиотека</span></button><button class="button button-primary" data-act="next-book" title="Следующая книга"><span>Следующая</span>${icon('chevron-right')}</button></nav></div></article></div><div class="reading-progress" role="progressbar" aria-label="Позиция чтения" aria-valuenow="${percent}"><div id="readerProgress" style="width:${percent}%"></div></div></div>`;
 $('#ttsRate').value=String(state.rate);
 $('#ttsRate').addEventListener('change',e=>{state.rate=Number(e.target.value);persist();if(reading)toast('Новая скорость применится со следующей фразы.');});
 updateReadingOptions();
 const exit=document.createElement('button');
 exit.type='button';
 exit.className='icon-button reader-fullscreen-exit';
 exit.dataset.act='reader-fullscreen-exit';
 exit.title='Выйти из полноэкранного режима';
 exit.setAttribute('aria-label',exit.title);
 exit.innerHTML=icon('minimize');
 exit.hidden=true;
 $('.reader-screen').prepend(exit);
 const area=$('#readerArea');
 area.tabIndex=0;
 area.setAttribute('role','region');
 area.setAttribute('aria-label','Текст произведения');
 area.addEventListener('scroll',()=>{
  if(fullscreenReader?.area===area)fullscreenReader.anchor=captureReadingAnchor(area);
  if(sentenceMode)return;
  if(area.scrollHeight-area.scrollTop-area.clientHeight<260 && readerLast<book.paragraphs.length)appendReaderText();
  if(activeWord&&!window.matchMedia('(max-width:700px)').matches)closePanel();
  clearTimeout(scrollTimer);scrollTimer=setTimeout(updateReaderProgress,150);
 },{passive:true});
 if(bookmark>0||position!=null)showReaderPosition(bookmark);
}
function captureReadingAnchor(area){
 const edge=area.getBoundingClientRect().top;
 const block=sentenceMode?$('#sentenceCard'):$('.story-paragraph[data-p="'+visibleParagraph()+'"]',area);
 if(!block||area.scrollTop===0)return {top:area.scrollTop};
 const words=block.querySelectorAll('.word');
 let start=0,end=words.length;
 while(start<end){
  const middle=(start+end)>>1;
  if(words[middle].getBoundingClientRect().bottom>edge+2)end=middle;
  else start=middle+1;
 }
 const item=words[start]||block;
 return {item,y:item.getBoundingClientRect().top-edge,top:area.scrollTop};
}
function restoreReadingAnchor(area,anchor){
 const {item,y,top}=anchor;
 const position=item?.isConnected?area.scrollTop+item.getBoundingClientRect().top-area.getBoundingClientRect().top-y:top;
 area.scrollTo({top:position,behavior:'instant'});
}
function resetFullscreenReader(mode,restore=true){
 fullscreenReader=null;
 document.body.classList.remove('reader-fullscreen');
 mode.exit.hidden=true;
 if(restore){
  restoreReadingAnchor(mode.area,mode.anchor);
  mode.trigger.focus({preventScroll:true});
 }
}
async function enterFullscreenReader(trigger){
 const area=$('#readerArea'),exit=$('[data-act="reader-fullscreen-exit"]');
 if(fullscreenReader||!area||!exit)return;
 const mode={area,exit,trigger,anchor:captureReadingAnchor(area),native:false};
 fullscreenReader=mode;
 closePanel();
 document.body.classList.add('reader-fullscreen');
 exit.hidden=false;
 restoreReadingAnchor(area,mode.anchor);
 area.focus({preventScroll:true});
 if(!document.fullscreenEnabled||document.fullscreenElement)return;
 try{
  await document.documentElement.requestFullscreen();
  if(fullscreenReader!==mode&&document.fullscreenElement===document.documentElement){
   await document.exitFullscreen();
  }
 }catch{/* The reader already fills the available viewport. */}
}
async function exitFullscreenReader(){
 const mode=fullscreenReader;
 if(!mode)return;
 closePanel();
 mode.anchor=captureReadingAnchor(mode.area);
 if(mode.native&&document.fullscreenElement===document.documentElement){
  try{await document.exitFullscreen();}
  catch{toast('Не удалось выйти. Нажмите Esc или повторите попытку.');}
 }else resetFullscreenReader(mode);
}
function updateNativeFullscreen(){
 const mode=fullscreenReader;
 if(!mode)return;
 if(document.fullscreenElement===document.documentElement){
  mode.native=true;
  restoreReadingAnchor(mode.area,mode.anchor);
 }else if(mode.native){
  closePanel();
  resetFullscreenReader(mode);
 }
}
function genreLabel(genre){
 return {Eventyr:'Сказка',Fabel:'Басня',Digt:'Стихотворение',Roman:'Роман',Hverdag:'Повседневная жизнь'}[genre]||genre;
}
function appendReaderText(){
 const book=getBook(activeBookId),node=$('#storyText');
 if(!book||!node||readerLast>=book.paragraphs.length)return;
 const to=Math.min(book.paragraphs.length,readerLast+12);
 node.insertAdjacentHTML('beforeend',book.paragraphs.slice(readerLast,to).map((_,i)=>storyParagraph(book,i+readerLast)).join(''));
 readerLast=to;
 $('#readerMoreNext').hidden=readerLast>=book.paragraphs.length;
 $('#readerEnd').hidden=readerLast<book.paragraphs.length;
}
function prependReaderText(){
 const book=getBook(activeBookId),node=$('#storyText'),area=$('#readerArea');
 if(!book||!node||!area||readerFirst<=0)return;
 const from=Math.max(0,readerFirst-12),anchor=node.firstElementChild,top=anchor.getBoundingClientRect().top;
 node.insertAdjacentHTML('afterbegin',book.paragraphs.slice(from,readerFirst).map((_,i)=>storyParagraph(book,i+from)).join(''));
 readerFirst=from;
 $('#readerMorePrev').hidden=readerFirst===0;
 area.scrollTop+=anchor.getBoundingClientRect().top-top;
}
function visibleParagraph(){
 if(sentenceMode)return sentencesOf(getBook(activeBookId))[sentenceIndex]?.p||0;
 const area=$('#readerArea');
 if(!area)return 0;
 const rect=area.getBoundingClientRect(),children=$('#storyText').children;
 // Paragraph positions are ordered, so no full layout scan is required.
 let low=0,high=children.length-1;
 while(low<high){
  const middle=(low+high)>>1;
  if(children[middle].getBoundingClientRect().bottom>rect.top+15)high=middle;
  else low=middle+1;
 }
 return Number(children[low]?.dataset.p)||0;
}
function storeReadingPosition(book,p,offset=0){
 if(state.positions[book.id]!==p||(state.sentenceOffsets[book.id]||0)!==offset){
  state.positions[book.id]=p;
  state.sentenceOffsets[book.id]=offset;
  persist();
 }
 const progress=progressFor(book),bar=$('#readerProgress'),label=$('#progressLabel');
 if(bar){bar.style.width=`${progress}%`;bar.parentElement.setAttribute('aria-valuenow',String(progress));}
 if(label)label.textContent=`${progress}%`;
}
function updateReaderProgress(){
 if(view!=='reader'||!activeBookId||!$('#readerArea')||sentenceMode)return;
 const book=getBook(activeBookId),area=$('#readerArea');
 if(!book||(area.scrollTop===0&&state.positions[book.id]==null))return;
 const end=$('#readerEnd');
 const reachedEnd=!end.hidden&&end.getBoundingClientRect().top<=area.getBoundingClientRect().bottom-12;
 const p=reachedEnd?book.paragraphs.length-1:visibleParagraph();
 storeReadingPosition(book,p,state.positions[book.id]===p?(state.sentenceOffsets[book.id]||0):0);
}
function bookmark(){
 const book=getBook(activeBookId);
 if(!book)return;
 const p=visibleParagraph();
 state.bookmarks[book.id]=p;
 persist();updateReaderProgress();
 $('.story-paragraph.is-bookmarked')?.classList.remove('is-bookmarked');
 $(`.story-paragraph[data-p="${p}"]`)?.classList.add('is-bookmarked');
 $('.bookmark-jump').hidden=false;
 $('.reader-controls').open=false;
 toast(`Закладка сохранена: абзац ${p+1}`);
}
function jumpBookmark(){
 const at=state.bookmarks[activeBookId];
 if(at==null)return toast('Закладка пока не установлена');
 openBook(activeBookId,at);
}
function deleteText(){
 const id=activeBookId,b=getBook(id);
 if(b?.level!=='TXT'||!confirm(`Удалить «${b.title}» из библиотеки?`))return;
 const next={...state,customBooks:state.customBooks.filter(book=>book.id!==id),lastBook:state.lastBook===id?null:state.lastBook};
 for(const field of ['positions','bookmarks','sentenceOffsets']){
  next[field]=Object.assign(Object.create(null),state[field]);delete next[field][id];
 }
 if(!persist(next))return;
 leaveReader(false);state=next;view='library';setView('library');
 toast('Текст удалён');
}

// Единый поиск перевода для карточки слова, словаря книги и избранного.
function derivedEntry(word){
 const w=norm(word), candidates=[];
 const add=(v)=>{if(v && v.length>2 && v!==w && !candidates.includes(v))candidates.push(v);};
 for(const [end,ends] of [['ernes',['','e']],['enes',['','e']],['ene',['','e']],['erne',['','e']],['ens',['','e']],['ets',['','e']],['hedens',['hed']],['heden',['hed']],['ende',['e']],['ende',['']],['ede',['e','']],['te',['e','']],['et',['','e']],['en',['','e']],['er',['','e']],['es',['','e']],['s',['']],['e',['']],['t',['']]]){
  if(w.endsWith(end) && w.length > end.length+2) for(const x of ends)add(w.slice(0,-end.length)+x);
 }
 for(const root of candidates){if(Object.prototype.hasOwnProperty.call(lexicon,root))return {text:lexicon[root],origin:'Возможная базовая форма: '+root+' · офлайн',derived:true};}
 return null;
}
function ownTranslation(dictionary,word){
 return Object.prototype.hasOwnProperty.call(dictionary,word) ? dictionary[word] : null;
}
function dictionaryEntry(word){
 const curated=ownTranslation(reviewedWords,word)||ownTranslation(lexicon,word);
 if(curated)return {text:curated,origin:'Встроенный словарь · офлайн'};
 const reference=ownTranslation(referenceWords,word);
 if(reference)return {text:reference,origin:'Викисловарь · офлайн'};
 const generated=ownTranslation(generatedWords,word);
 if(generated)return {text:generated,origin:'Автоматический перевод · офлайн'};
 return null;
}
function lookupEntry(word){
 const w=norm(word);
 if(state.translations[w])return {text:state.translations[w],origin:'Сохранённый перевод · офлайн'};
 const direct=dictionaryEntry(w);
 if(direct)return direct;
 const root=ownTranslation(wordForms,w);
 const base=root&&dictionaryEntry(root);
 if(base)return {text:base.text,origin:`Базовая форма: ${root} · ${base.origin}`};
 return derivedEntry(w) || {text:null,origin:'Пока нет перевода офлайн'};
}
function getTranslation(word){return lookupEntry(word).text;}
// Слова индексируются по точному написанию один раз; повторения учитываются числом.
const vocabularyCache=new WeakMap();
function uniqueWords(book){
 if(vocabularyCache.has(book))return vocabularyCache.get(book);
 const result=new Map();
 for(const paragraph of book.paragraphs){for(const match of paragraph.matchAll(wordPattern)){
  const w=norm(match[0]);result.set(w,(result.get(w)||0)+1);
 }}
 const words=[...result].map(([word,count])=>({word,count}));
 vocabularyCache.set(book,words);return words;
}
function vocabRow(item){const entry=lookupEntry(item.word);return `<div class="vocab-row" data-vocab-word="${esc(item.word)}"><button class="vocab-da" data-act="word-details" data-word="${esc(item.word)}" title="Посмотреть перевод и сохранить слово">${esc(item.word)}</button><span class="vocab-ru ${entry.text?'':'untranslated'}">${esc(entry.text||'Нужен перевод')}</span><span class="vocab-frequency" title="Сколько раз встречается">×${item.count}</span><button class="icon-button vocab-voice" data-act="speak-favorite" data-word="${esc(item.word)}" title="Произнести по-датски">${icon('volume')}</button></div>`;}
function updateVocabularyList(){
 const book=getBook(activeBookId);if(!book)return;
 const all=uniqueWords(book), translated=all.filter(x=>getTranslation(x.word)).length;
 const counter=$('#vocabStatistics');if(counter)counter.textContent=`${all.length} уникальных слов · ${translated} с переводом · ${all.length-translated} без перевода`;
 const filtered=all.filter(item=>(!vocabOnlyMissing || !getTranslation(item.word)) && (!vocabQuery || item.word.includes(norm(vocabQuery)) || (getTranslation(item.word)||'').toLowerCase().includes(vocabQuery.toLowerCase())));
 const list=$('#vocabList');if(list)list.innerHTML=filtered.length?filtered.slice(0,vocabLimit).map(vocabRow).join(''):'<div class="empty-state">Совпадений нет. Все имеющиеся переводы уже показаны.</div>';
 const more=$('#vocabMore');if(more)more.hidden=vocabLimit>=filtered.length;
 const btn=$('#vocabBatch');if(btn){btn.disabled=batchRunning || translated===all.length;btn.innerHTML=icon('download')+(batchRunning?'Переводим…':'Перевести недостающие · до 20 слов');}
}
function renderVocabulary(){
 const book=getBook(activeBookId);if(!book){setView('library');return;}
 leaveReader();view='vocabulary';syncRoute();updateSideNav();$('#crumb').textContent='Слова книги';
 $('#pageContent').innerHTML=`<div class="page-inner vocab-page"><button class="button" data-act="back-to-book">${icon('chevron')}К чтению</button><div class="page-eyebrow" style="margin-top:22px">ДАТСКИЙ → РУССКИЙ · БЕЗ ПОВТОРОВ</div><h1 class="page-title">Слова: ${esc(book.title)}</h1><p class="page-description">Все разные слова из текста собраны автоматически. Повторные вхождения не дублируются. Значения показываются по словарю, а для незнакомых форм можно запросить онлайн-перевод.</p><div class="vocab-summary"><strong id="vocabStatistics"></strong><button class="button button-primary" id="vocabBatch" data-act="batch-translate">${icon('download')}Перевести недостающие · до 20 слов</button><button class="button" id="vocabStop" data-act="batch-stop" hidden>Остановить</button></div><p class="online-hint">Для онлайн-запросов используется MyMemory: до 20 новых слов за запуск, без повторных запросов к сохранённым словам. Результаты автоматические и могут требовать исправления; лимит бесплатного сервиса — 5000 символов в день без регистрации.</p><p class="batch-status" id="batchStatus" aria-live="polite"></p><div class="vocab-controls"><label class="search-wrapper">${icon('search')}<input type="search" id="vocabSearch" aria-label="Найти слово или перевод" placeholder="Найти слово или перевод" value="${esc(vocabQuery)}"></label><label class="vocab-check"><input type="checkbox" id="vocabMissing" ${vocabOnlyMissing?'checked':''}> Только без перевода</label></div><div class="vocab-list" id="vocabList"></div><button class="more-story" id="vocabMore" data-act="vocab-more" hidden>Показать ещё слова</button></div>`;
 $('#vocabSearch').addEventListener('input',e=>{vocabQuery=e.target.value;vocabLimit=100;updateVocabularyList();});
 $('#vocabMissing').addEventListener('change',e=>{vocabOnlyMissing=e.target.checked;vocabLimit=100;updateVocabularyList();});
 updateVocabularyList();
}
async function requestTranslation(word,signal,maxLength=300){
 const controller=new AbortController();
 const abort=()=>controller.abort();
 signal?.addEventListener('abort',abort,{once:true});
 const timeout=setTimeout(abort,10000);
 try{
  const query=new URLSearchParams({q:word,langpair:'da|ru'});
  const response=await fetch('https://api.mymemory.translated.net/get?'+query,{signal:controller.signal,credentials:'omit',referrerPolicy:'no-referrer',headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error('HTTP '+response.status);
  const json=await response.json();
  const translated=String(json?.responseData?.translatedText||'').trim();
  if(Number(json?.responseStatus)!==200||!/[а-яё]/i.test(translated)||norm(translated)===norm(word)||translated.length>maxLength||/translated\.net|quota|limit exceeded/i.test(translated))throw new Error('Нет достоверного ответа');
  return translated;
 }finally{clearTimeout(timeout);signal?.removeEventListener('abort',abort);}
}
function cancelBatch(){batchController?.abort();}
function keepTranslation(word,text){
 state.translations[word]=text;
 if(state.favorites[word])state.favorites[word].translation=text;
 return persist();
}
async function translateBatch(){
 if(batchRunning)return;
 if(!navigator.onLine)return toast('Для онлайн-перевода нужен интернет');
 const book=getBook(activeBookId);
 if(!book)return;
 const controller=new AbortController();
 batchController=controller;
 batchRunning=true;
 const words=uniqueWords(book).map(x=>x.word).filter(w=>!getTranslation(w)).slice(0,20);
 const status=$('#batchStatus'),stop=$('#vocabStop');
 stop.hidden=false;
 updateVocabularyList();
 let done=0,errors=0;
 try{
  for(let i=0;i<words.length&&!controller.signal.aborted;i++){
   const word=words[i];
   status.textContent=`Запрос ${i+1} из ${words.length}: ${word}. Добавлено переводов: ${done}.`;
   try{
    const translation=await requestTranslation(word,controller.signal);
    if(!controller.signal.aborted&&!state.translations[word]&&keepTranslation(word,translation))done++;
   }catch{if(!controller.signal.aborted&&++errors>=4)break;}
   if(!controller.signal.aborted&&i+1<words.length)await new Promise(resolve=>setTimeout(resolve,450));
  }
 }finally{
  batchRunning=false;batchController=null;
  if(view==='vocabulary')updateVocabularyList();
  if(stop.isConnected){
   stop.hidden=true;
   status.textContent=`${controller.signal.aborted?'Перевод остановлен. ':''}Сохранено переводов: ${done}. Ошибок: ${errors}.`;
  }
 }
}
async function translateOnline(){
 if(!activeWord||onlinePending)return;
 if(!navigator.onLine)return toast('Нет соединения. Можно ввести перевод вручную.');
 const requested=activeWord,version=translationVersion,previous=state.translations[requested];
 onlinePending=true;
 const btn=$('#onlineTranslate');
 btn.disabled=true;btn.textContent='Переводим…';
 try{
  const translated=await requestTranslation(requested);
  if(version===translationVersion&&state.translations[requested]===previous&&keepTranslation(requested,translated)){
   if(activeWord===requested)openWord(requested);
   if(view==='vocabulary')updateVocabularyList();
   if(view==='favorites')renderFavorites(true);
   toast('Перевод сохранён офлайн');
  }
 }catch{if(version===translationVersion)toast('Онлайн-переводчик недоступен. Можно ввести перевод вручную.');}
 finally{
  onlinePending=false;
  const current=$('#onlineTranslate');
  if(current){current.disabled=false;current.textContent='Перевести онлайн';}
 }
}

function closePanel(restoreFocus=false){
 const anchor=activeAnchor;
 $('#dictionaryPanel').hidden=true;$('#panelScrim').hidden=true;
 activeWord=null;activeAnchor=null;
 $('.word.is-selected')?.classList.remove('is-selected');
 if(restoreFocus&&anchor?.isConnected)anchor.focus({preventScroll:true});
}
function placeWordPopover(){
 const box=$('#dictionaryPanel');
 if(box.hidden)return;
 const mobile=window.matchMedia('(max-width:700px)').matches;
 $('#panelScrim').hidden=!mobile;
 if(mobile){box.style.removeProperty('width');box.style.removeProperty('left');box.style.removeProperty('top');return;}
 const size=Math.min(336,window.innerWidth-24);
 box.style.width=size+'px';
 const rect=activeAnchor?.isConnected?activeAnchor.getBoundingClientRect():null,height=box.offsetHeight;
 const x=Math.max(12,Math.min(window.innerWidth-size-12,rect?rect.left-28:(window.innerWidth-size)/2));
 let y=rect?rect.bottom+9:(window.innerHeight-height)/2;
 if(rect&&y+height>window.innerHeight-10)y=rect.top-height-9;
 box.style.left=Math.round(x)+'px';
 box.style.top=Math.round(Math.max(8,Math.min(window.innerHeight-height-8,y)))+'px';
}

function openWord(word,anchor){
 if(anchor!==undefined){$$('.word.is-selected').forEach(el=>el.classList.remove('is-selected'));activeAnchor=anchor;if(anchor.classList.contains('word'))anchor.classList.add('is-selected');}
 const n=norm(word);activeWord=n;
 const entry=lookupEntry(n),meaning=entry.text,selected=!!state.favorites[n],hasMeaning=!!meaning;
 $('#dictionaryPanel').innerHTML=`<div class="pop-head"><strong lang="da">${esc(word)}</strong><button class="pop-icon" data-act="close-panel" aria-label="Закрыть перевод" title="Закрыть">${icon('x')}</button></div>
 <div class="pop-translation" lang="ru">${esc(meaning||'Перевод пока не найден')}</div>
 <div class="pop-toolbar"><span class="pop-source">${esc(entry.origin)}</span><div class="pop-actions" role="group" aria-label="Действия со словом"><button class="pop-icon" data-act="pronounce-word" title="Прослушать" aria-label="Прослушать">${icon('volume')}</button>${activeAnchor?.classList.contains('word')?`<button class="pop-icon" data-act="tts-from-word" title="Читать текст с этого слова" aria-label="Читать с этого слова">${icon('play')}</button>`:''}<button class="pop-icon ${selected?'pop-saved':''}" data-act="toggle-favorite" title="${selected?'Удалить из моих слов':'Сохранить в мои слова'}" aria-label="${selected?'Удалить слово':'Сохранить слово'}">${icon(selected?'check':'bookmark')}</button><button class="pop-icon" data-act="edit-translation" title="Изменить или перевести онлайн" aria-label="Изменить перевод">${icon('edit')}</button></div></div>
 <div class="pop-edit" id="popEdit" ${hasMeaning?'hidden':''}><label for="translationEdit">Перевод слова</label><input id="translationEdit" type="text" maxlength="300" value="${esc(state.translations[n]||meaning||'')}" placeholder="Введите перевод"><div class="pop-edit-actions"><button data-act="save-translation" class="button button-primary">Сохранить</button><button data-act="translate-online" id="onlineTranslate" class="button" ${onlinePending?'disabled':''}>${onlinePending?'Переводим…':'Перевести онлайн'}</button></div></div>`;
 $('#dictionaryPanel').hidden=false;$('#panelScrim').hidden=true;
 placeWordPopover();
 if(anchor) $('[data-act="close-panel"]').focus({preventScroll:true});
}
function toggleFavorite(){if(!activeWord)return;const w=activeWord;
 if(state.favorites[w]){delete state.favorites[w];toast('Слово удалено');}
 else{const translation=getTranslation(w);if(!translation){$('#popEdit').hidden=false;placeWordPopover();return toast('Сначала добавьте перевод слова');}state.favorites[w]={translation,learned:false,addedAt:Date.now()};toast('Слово сохранено');}
 persist();openWord(w);updateSideNav();
 if(view==='favorites')renderFavorites(true);
}
function saveTranslation(){if(!activeWord)return;const input=$('#translationEdit');const value=input?.value.trim();if(!value)return toast('Введите перевод');
 if(!keepTranslation(activeWord,value))return;
 openWord(activeWord);
 if(view==='vocabulary')updateVocabularyList();
 if(view==='favorites')renderFavorites(true);
 toast('Перевод сохранён');
}

function renderFavorites(keepPanel=false){if(!keepPanel)closePanel();view='favorites';updateSideNav();$('#crumb').textContent='Мои слова';const items=Object.entries(state.favorites).sort((a,b)=>(b[1].addedAt||0)-(a[1].addedAt||0));const filtered=items.filter(([word,v])=>`${word} ${v.translation||''}`.toLocaleLowerCase('ru').includes(favoriteQuery.toLocaleLowerCase('ru')));
 $('#pageContent').innerHTML=`<div class="page-inner"><div class="words-head"><div><div class="page-eyebrow">ВАШ ЛИЧНЫЙ СЛОВАРЬ</div><h1 class="page-title">Мои слова</h1><p class="page-description">Слова, которые вы встретили в книгах. Слушайте произношение и отмечайте выученные.</p></div><div class="settings-actions"><button class="button button-primary" data-act="review-start">Повторить слова</button><button class="button" data-act="export-words">${icon('download')}Экспорт CSV</button></div></div><section id="reviewCard" class="review-card" aria-label="Карточки слов" hidden></section>
 <div class="library-toolbar"><div class="words-count">Всего: ${items.length} · Выучено: ${items.filter(([,v])=>v.learned).length}</div><label class="search-wrapper">${icon('search')}<input type="search" id="wordsSearch" aria-label="Поиск сохранённых слов" placeholder="Поиск слов" value="${esc(favoriteQuery)}"></label></div>
 <div class="words-list" id="wordsList">${filtered.length?filtered.map(([w,v])=>favoriteRow(w,v)).join(''):'<div class="empty-state">Здесь пока нет слов. Откройте книгу, нажмите на слово и сохраните его.</div>'}</div><p class="words-help">Все слова хранятся на этом устройстве. В настройках можно создать резервную копию и перенести данные на другое устройство.</p></div>`;
 $('#wordsSearch')?.addEventListener('input',(e)=>{favoriteQuery=e.target.value;const f=Object.entries(state.favorites).sort((a,b)=>(b[1].addedAt||0)-(a[1].addedAt||0)).filter(([w,v])=>`${w} ${v.translation||''}`.toLocaleLowerCase('ru').includes(favoriteQuery.toLocaleLowerCase('ru')));$('#wordsList').innerHTML=f.length?f.map(([w,v])=>favoriteRow(w,v)).join(''):'<div class="empty-state">Ничего не найдено</div>';});
}
function favoriteRow(w,v){return `<div class="words-row ${v.learned?'marked':''}"><button class="book-open words-da" data-act="favorite-detail" data-word="${esc(w)}">${esc(w)}</button><div class="words-ru">${esc(v.translation)}</div><div class="words-tools"><button class="icon-button" title="Прослушать слово" data-act="speak-favorite" data-word="${esc(w)}">${icon('volume')}</button><button class="icon-button" title="${v.learned?'Отметить как невыученное':'Отметить как выученное'}" data-act="learn-favorite" data-word="${esc(w)}">${icon('check')}</button><button class="icon-button" title="Удалить слово" data-act="delete-favorite" data-word="${esc(w)}">${icon('trash')}</button></div></div>`;}
function renderSettings(){view='settings';updateSideNav();$('#crumb').textContent='Настройки';$('#pageContent').innerHTML=`<div class="page-inner"><div class="page-eyebrow">ПАРАМЕТРЫ ЧТЕНИЯ</div><h1 class="page-title">Настройки</h1><p class="page-description">Удобный размер текста, датская озвучка и управление личной библиотекой.</p><div class="settings-layout">
 <section class="settings-card"><h3>Отображение</h3><p>Выберите тему приложения и размер букв для чтения.</p><div class="settings-actions"><button class="button" data-act="theme-toggle">${icon(state.theme==='dark'?'sun':'moon')}${state.theme==='dark'?'Светлая тема':'Тёмная тема'}</button><div class="font-size-stepper" role="group" aria-label="Размер текста"><button class="button" type="button" data-act="font-minus" title="Уменьшить шрифт" aria-label="Уменьшить шрифт">A−</button><output class="font-size-value" aria-live="polite">${state.fontSize} px</output><button class="button" type="button" data-act="font-plus" title="Увеличить шрифт" aria-label="Увеличить шрифт">A+</button></div></div></section>
 <section class="settings-card settings-appearance"><h3>Оформление чтения</h3><p>Цвет страницы и ширина текста настраиваются независимо от темы приложения.</p>${appearanceControls()}</section>
 <section class="settings-card"><h3>Датский голос</h3><p>Озвучка использует голоса вашего устройства. Для работы без интернета может понадобиться установить датский голосовой пакет в системе.</p><div class="settings-field"><label class="settings-label" for="voiceSelect">Голос (da-DK)</label><select class="settings-select" id="voiceSelect">${voiceOptions()}</select></div><button class="button" data-act="test-voice">${icon('volume')}Проверить произношение</button></section>
 <section class="settings-card"><h3>Моя библиотека</h3><p>Добавляйте тексты на датском из TXT-файла в кодировке UTF-8. Каждый пустой промежуток между абзацами создаёт отдельный абзац книги. Импортированное содержимое хранится локально.</p><div class="settings-actions"><button class="button button-primary" data-act="import-txt">${icon('plus')}Загрузить TXT</button><button class="button" data-act="toggle-paste">${icon('book')}Вставить текст</button></div><div id="pasteBox" hidden style="margin-top:18px"><label class="settings-label" for="bookTitle">Название книги</label><input class="dictionary-edit" id="bookTitle" maxlength="120" placeholder="Название рассказа"><label class="settings-label" for="bookText">Текст на датском</label><textarea id="bookText" placeholder="Вставьте датский текст. Разделяйте абзацы пустой строкой."></textarea><button class="button button-primary" data-act="save-pasted">${icon('check')}Добавить в библиотеку</button></div></section>
 <section class="settings-card"><h3>Сохранение и перенос данных</h3><p>Книги, переводы, закладки и избранные слова хранятся в браузере. Между телефоном и компьютером данные автоматически не синхронизируются.</p><div class="settings-actions"><button class="button" data-act="backup-export">${icon('download')}Скачать резервную копию</button><button class="button" data-act="backup-import">${icon('upload')}Восстановить из файла</button></div></section>
 <section class="settings-card"><h3>Установка на устройство</h3><p>${location.protocol==='file:'?'Этот HTML-файл уже содержит все книги и работает локально. Ярлык на телефоне устанавливается с веб-версии.':'Установите ярлык, чтобы открывать библиотеку с домашнего экрана. После первого открытия книги и словарь доступны без сети.'}</p><p class="settings-version">Версия ${APP_VERSION}</p><div class="settings-actions"><button class="button" data-act="app-update">${icon('refresh')} Проверить обновление</button><button class="button button-primary" data-act="pwa-install" ${appIsStandalone||location.protocol==='file:'?'hidden':''}>${icon('download')}Установить приложение</button><button class="button" data-act="share-app">${icon('share')} Поделиться приложением</button></div><p id="installHelp" hidden></p></section>
 <section class="settings-card"><details><summary>Источники офлайн-словаря</summary><p>Датские словоформы: <a href="https://ordregister.dk/" target="_blank" rel="noopener noreferrer">Det Centrale Ordregister (COR, CC0)</a>. Словарные значения: <a href="https://ru.wiktionary.org/" target="_blank" rel="noopener noreferrer">авторы Викисловаря</a>, через <a href="https://kaikki.org/ruwiktionary/rawdata.html" target="_blank" rel="noopener noreferrer">Kaikki / Wiktextract</a>. Использованы <a href="https://kaikki.org/dictionary/Danish/" target="_blank" rel="noopener noreferrer">английский</a> и русский выпуски. Выбранные значения сокращены или переведены и распространяются по <a href="https://creativecommons.org/licenses/by-sa/4.0/deed.ru" target="_blank" rel="noopener noreferrer">CC BY-SA 4.0</a>. Автоматические переводы подготовлены с помощью <a href="https://huggingface.co/Helsinki-NLP/opus-mt-en-ru" target="_blank" rel="noopener noreferrer">OPUS-MT</a> и хранятся в приложении.</p></details></section>
 <section class="settings-card"><h3>Сброс</h3><p>Удалить сохранённый прогресс, словарь и загруженные тексты только на этом устройстве.</p><button class="button" data-act="reset-all">${icon('trash')}Удалить все локальные данные</button></section>
 </div></div>`;
 $('#voiceSelect')?.addEventListener('change',e=>{state.voice=e.target.value;persist();});
 applyAppearance();announceUpdate();
}
let speechQueue=null, currentSpeech=null, speechTimer=null;
function voiceOptions(){
 const danish=voices.filter(v=>/^da(?:[-_]|$)/i.test(v.lang));
 return '<option value="">Автоматический выбор</option>'+danish.map(v=>`<option value="${esc(v.voiceURI)}" ${state.voice===v.voiceURI?'selected':''}>${esc(v.name)} · ${esc(v.lang)}${v.localService?' · локальный':''}</option>`).join('');
}
function refreshVoices(){
 if(!synth)return;
 voices=synth.getVoices()||[];
 const select=$('#voiceSelect');
 if(select)select.innerHTML=voiceOptions();
}
function getDanishVoice(){
 const danish=voices.filter(v=>/^da(?:[-_]|$)/i.test(v.lang));
 return danish.find(v=>v.voiceURI===state.voice)||danish.find(v=>v.localService)||danish[0]||null;
}
function prepareSpeech(){
 if(!synth){toast('Этот браузер не поддерживает озвучку.');return false;}
 refreshVoices();
 if(!getDanishVoice()){toast('Датский голос не найден. Добавьте голос Dansk в настройках устройства или браузера.');return false;}
 return true;
}
function speakText(text,onDone){
 const utterance=new SpeechSynthesisUtterance(text);
 currentSpeech=utterance;
 utterance.lang='da-DK';
 utterance.rate=state.rate;
 utterance.voice=getDanishVoice();
 utterance.onend=()=>{
  if(currentSpeech!==utterance)return;
  currentSpeech=null;
  onDone?.();
 };
 utterance.onerror=()=>{
  if(currentSpeech!==utterance)return;
  stopReading();
  toast('Не удалось озвучить текст. Проверьте датский голос в настройках.');
 };
 try{synth.speak(utterance);}
 catch{utterance.onerror();}
}
function pronounce(text){
 if(!prepareSpeech())return;
 stopReading();
 speakText(text);
}
function* speechItems(book,from,offset){
 for(let p=from;p<book.paragraphs.length;p++){
  const text=book.paragraphs[p].slice(p===from?offset:0);
  const segments=sentenceSegmenter?[...sentenceSegmenter.segment(text)].map(x=>x.segment):
   text.match(/[^.!?…]+[.!?…]*|[.!?…]+/g)||[];
  for(const segment of segments){
   const words=segment.trim().split(/\s+/);
   let chunk='';
   for(const word of words){
    if(chunk && chunk.length+word.length>155){yield {p,text:chunk};chunk='';}
    chunk+=(chunk?' ':'')+word;
   }
   if(chunk)yield {p,text:chunk};
  }
 }
}
let speechParagraph=null;
function setParagraphSpeechButton(p,isPlaying){
 if(p==null)return;
 const button=$(`.paragraph-play[data-p="${p}"]`);
 if(!button)return;
 const label=isPlaying?'Поставить чтение на паузу':reading&&speechParagraph===p?'Продолжить с паузы':`Читать с абзаца ${p+1}`;
 button.innerHTML=icon(isPlaying?'pause':'play');
 button.title=label;
 button.setAttribute('aria-label',label);
 button.setAttribute('aria-pressed',String(isPlaying));
}
function updateTTSButton(){
 const playLabel=reading&&!paused?'Пауза':reading?'Продолжить':'Слушать';
 const glyph=reading&&!paused?'pause':'play';
 const btn=$('#ttsPlay'),sentenceButton=$('[data-act="sentence-speak"]');
 if(btn)btn.innerHTML=icon(glyph)+`<span>${playLabel}</span>`;
 if(sentenceButton)sentenceButton.innerHTML=icon(glyph)+`<span>${reading?playLabel:'Прослушать'}</span>`;
 const stop=$('#ttsStop');
 if(stop)stop.disabled=!reading;
 setParagraphSpeechButton(speechParagraph,reading&&!paused);
 $('.story-paragraph.speaking')?.classList.toggle('speech-paused',paused);
}
function highlightSpeech(p){
 if(sentenceMode){$('#sentenceCard')?.classList.add('speaking');return;}
 const highlighted=$('.story-paragraph.speaking');
 if(highlighted?.dataset.p===String(p))return;
 highlighted?.classList.remove('speaking','speech-paused');
 const previous=speechParagraph;
 speechParagraph=p;
 setParagraphSpeechButton(previous,false);
 if(p>=readerLast || p<readerFirst)showReaderPosition(p);
 const el=$(`.story-paragraph[data-p="${p}"]`),area=$('#readerArea');
 if(!el||!area)return;
 el.classList.add('speaking');
 setParagraphSpeechButton(p,true);
 const r=el.getBoundingClientRect(),a=area.getBoundingClientRect();
 if(r.top<a.top||r.top>a.bottom-52)area.scrollTop+=r.top-a.top-10;
}
function playNext(){
 if(!reading||paused)return;
 const next=speechQueue.next();
 if(next.done){
  stopReading();
  if(!sentenceMode){updateReaderProgress();toast('Озвучивание завершено');}
  return;
 }
 highlightSpeech(next.value.p);
 speakText(next.value.text,()=>{speechTimer=setTimeout(playNext,35);});
}
function readFromWord(){
 const word=activeAnchor?.closest('.word');
 if(!word||!activeBookId)return;
 const p=Number(word.dataset.p),offset=Number(word.dataset.pos);
 closePanel();
 if(sentenceMode)setSentenceMode(false);
 readFromParagraph(p,offset);
}
function startSpeech(queue){
 if(!prepareSpeech())return;
 stopReading();
 reading=true;
 speechQueue=queue;
 updateTTSButton();
 // Keep the first utterance in the original click handler on mobile.
 playNext();
}
function readFromParagraph(p,startOffset=0){
 const book=getBook(activeBookId);
 if(!book)return;
 const start=Math.max(0,Math.min(book.paragraphs.length-1,Number(p)||0));
 storeReadingPosition(book,start);
 startSpeech(speechItems(book,start,startOffset));
}
function toggleParagraphSpeech(p){
 if(reading&&speechParagraph===p){toggleReading();return;}
 readFromParagraph(p);
}
function toggleReading(){
 if(!reading){
  if(sentenceMode){speakSentence();return;}
  readFromParagraph(visibleParagraph());return;
 }
 paused=!paused;
 if(currentSpeech){
  if(paused)synth.pause();
  else synth.resume();
 }else if(!paused){clearTimeout(speechTimer);playNext();}
 updateTTSButton();
}
function stopReading(){
 const shouldCancel=!!currentSpeech||reading;
 currentSpeech=null;
 clearTimeout(speechTimer);
 speechQueue=null;
 reading=false;paused=false;
 if(shouldCancel&&synth){
  try{synth.cancel();if(synth.paused)synth.resume();}catch{}
 }
 $('.story-paragraph.speaking')?.classList.remove('speaking','speech-paused');
 $('#sentenceCard')?.classList.remove('speaking');
 updateTTSButton();
 speechParagraph=null;
}

function bookNeighbor(dir){
 let order=readerNavIds.length?readerNavIds:allBooks().map(b=>b.id);
 const i=order.indexOf(activeBookId);if(i<0)return setView('library');
 const target=order[i+dir];if(!target)return toast(dir>0?'Это последняя книга в списке.':'Это первая книга в списке.');
 stopReading();openBook(target);
}

function changeFont(delta){
 const size=Math.max(16,Math.min(32,state.fontSize+delta));
 if(size===state.fontSize)return;
 state.fontSize=size;
 persist();
 $('.reader-paper')?.style.setProperty('--reader-font',size+'px');
 const value=$('.font-size-value');
 if(value)value.textContent=`${size} px`;
 else toast(`Размер текста: ${size} px`);
}
function triggerDownload(content,name,type){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);}
function exportWords(){const q=(s)=>'"'+String(s??'').replace(/^([\s]*[=+@-]|[\r\t])/,"'$1").replace(/"/g,'""')+'"';const lines=['Датский;Русский;Выучено',...Object.entries(state.favorites).map(([w,x])=>[w,x.translation,x.learned?'Да':'Нет'].map(q).join(';'))];triggerDownload('\ufeff'+lines.join('\r\n'),'dansklaeser-words.csv','text/csv;charset=utf-8');toast('Словарь экспортирован в CSV');}
function exportBackup(){triggerDownload(JSON.stringify({app:'DanskLaeser',version:1,exportedAt:new Date().toISOString(),state},null,2),'dansklaeser-backup.json','application/json;charset=utf-8');toast('Резервная копия сохранена');}
function sanitizeBook(raw){
 if(!raw||typeof raw.title!=='string'||!raw.title.trim()||!Array.isArray(raw.paragraphs))return null;
 const source=raw.paragraphs.filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim());
 if(!source.length||source.join('').length>160000)return null;
 const paragraphs=source.flatMap(text=>{
  const parts=[];
  while(text.length>1100){
   const space=text.lastIndexOf(' ',1100);
   const cut=space>400?space:1100;
   parts.push(text.slice(0,cut));text=text.slice(cut).trimStart();
  }
  if(text)parts.push(text);
  return parts;
 });
 const id=typeof raw.id==='string'&&/^custom-[a-z0-9-]{4,80}$/i.test(raw.id)?raw.id:'custom-'+Date.now()+'-'+Math.random().toString(36).slice(2,9);
 return {id,title:raw.title.trim().slice(0,120),author:'Моя библиотека',level:'TXT',genre:'Мой текст',color:'#e3edf0',accent:'#5a8794',summary:'Добавленный пользователем текст на датском языке',paragraphs};
}
function addTextBook(title,text){
 const paras=String(text||'').replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n').trim().split(/\n[ \t]*\n+|\n(?=[—-]\s)/);
 if(!title.trim()||!text.trim())return toast('Укажите название и текст');
 const book=sanitizeBook({title,paragraphs:paras});
 if(!book)return toast('Максимальный объём текста: 160 000 знаков.');
 const next={...state,customBooks:[...state.customBooks,book]};
 if(!persist(next))return;
 state=next;openBook(book.id);toast('Текст добавлен в библиотеку');
}
async function importTXT(file){
 if(!file)return;
 if(file.size>640000)return toast('Выберите TXT-файл размером до 640 КБ.');
 try{
  const contents=new TextDecoder('utf-8',{fatal:true}).decode(await file.arrayBuffer());
  addTextBook(file.name.replace(/\.txt$/i,'').replace(/[_-]/g,' '),contents);
 }catch{toast('Не удалось прочитать TXT. Сохраните файл в кодировке UTF-8.');}
}
async function importBackup(file){
 if(!file)return;
 if(file.size>12000000)return toast('Файл резервной копии слишком большой');
 try{
  const b=JSON.parse(await file.text());
  if(b.app!=='DanskLaeser'||b.version!==1||!b.state||typeof b.state!=='object'||Array.isArray(b.state))throw Error('format');
  const restored=cleanState(b.state);
  if(!confirm('Заменить локальный прогресс, книги и словарь данными из резервной копии?'))return;
  if(!persist(restored))return;
  leaveReader(false);translationVersion++;
  state=restored;view='library';applyTheme();setView('library');toast('Резервная копия восстановлена');
 }catch{toast('Некорректная резервная копия');}
}
async function resetAll(){
 if(!confirm('Безвозвратно удалить на этом устройстве все слова, закладки и добавленные тексты?'))return;
 const empty=freshState();
 if(!persist(empty))return;
 cancelOnline();
 if(onlineSaved.size){
  try{await onlineStore('readwrite',store=>store.clear());onlineSaved.clear();}
  catch{toast('Настройки сброшены. Браузер не удалил загруженные книги.');}
 }
 leaveReader(false);translationVersion++;
 state=empty;view='library';applyTheme();
 searchQuery='';favoriteQuery='';selectedLevel=selectedGenre=selectedLength='all';pageLimit=24;
 setView('library');toast('Локальные данные удалены');
}
async function installPWA(){
 if(appIsStandalone){toast('Приложение уже открыто в установленном режиме.');return;}
 if(deferredInstall){
  const prompt=deferredInstall;deferredInstall=null;
  try{await prompt.prompt();if((await prompt.userChoice).outcome==='accepted')toast('Приложение установлено');return;}catch{}
 }
 const help=$('#installHelp');
 if(!help)return;
 help.hidden=false;
 help.textContent=location.protocol==='file:'?'Откройте веб-версию для установки ярлыка.':
  /iPad|iPhone|iPod/.test(navigator.userAgent)||navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1?
  'В Safari нажмите «Поделиться», затем «На экран Домой».':
  'В меню браузера выберите «Установить приложение» или «Добавить на главный экран».';
}


const pagePresets=[['auto','Как в теме'],['light','Светлая'],['sepia','Сепия'],['dark','Тёмная'],['custom','Свои цвета']];
const resetAppearanceButton='<button class="button appearance-reset" data-act="reset-appearance">Сбросить оформление</button>';
function appearanceControls(showReset=true){
 return `<label class="reader-control-row">Оформление страницы
  <select class="rate-select appearance-select" id="paperStyle" data-reading-setting="paper">
  ${pagePresets.map(([key,label])=>`<option value="${key}">${label}</option>`).join('')}</select>
 </label>
 <label class="reader-control-row reading-width"><span>На всю ширину</span>
  <input type="checkbox" role="switch" data-reading-setting="wideReader">
 </label>
 <label class="reader-control-row">Межстрочный интервал
  <select class="rate-select" id="readingSpacing" data-reading-setting="spacing">
   <option value="normal">Обычный</option><option value="wide">Широкий</option>
  </select>
 </label>
 <div class="reader-colors" ${state.paper==='custom'?'':'hidden'}>
  <label class="reader-control-row">Фон<input type="color" data-reading-setting="paperBackground"></label>
  <label class="reader-control-row">Текст<input type="color" data-reading-setting="paperText"></label>
  <p class="reader-palette-note" role="status" hidden>Контраст выбранных цветов низкий. В читалке используется более читаемый цвет текста.</p>
 </div>
 ${showReset?resetAppearanceButton:''}`;
}
function safeColor(value,fallback){
 return typeof value==='string'&&/^#[0-9a-f]{6}$/i.test(value)?value.toLowerCase():fallback;
}
function colorChannels(color){
 return color.slice(1).match(/.{2}/g).map(channel=>Number.parseInt(channel,16));
}
function luminance(color){
 const [r,g,b]=colorChannels(color).map(channel=>{
  const unit=channel/255;
  return unit<=0.04045?unit/12.92:((unit+0.055)/1.055)**2.4;
 });
 return r*.2126+g*.7152+b*.0722;
}
function colorContrast(a,b){
 const values=[luminance(a),luminance(b)].sort((x,y)=>y-x);
 return (values[0]+.05)/(values[1]+.05);
}
function readableText(background){
 return colorContrast(background,'#121715')>=colorContrast(background,'#ffffff')?'#121715':'#ffffff';
}
function mixColors(base,tint,weight){
 const tintChannels=colorChannels(tint);
 return '#'+colorChannels(base).map((channel,i)=>
  Math.round(channel+(tintChannels[i]-channel)*weight).toString(16).padStart(2,'0')).join('');
}
function applyAppearance(){
 const custom=state.paper==='custom';
 const originalInk=state.paperText,background=state.paperBackground;
 const weak=custom&&colorContrast(background,originalInk)<4.5;
 const ink=weak?readableText(background):originalInk;
 for(const control of $$('[data-reading-setting]')){
  const value=state[control.dataset.readingSetting];
  if(control.type==='checkbox')control.checked=value;
  else control.value=value;
 }
 for(const colors of $$('.reader-colors'))colors.hidden=!custom;
 for(const note of $$('.reader-palette-note'))note.hidden=!weak;
 const paper=$('.reader-paper');
 if(!paper)return;
 paper.dataset.paper=state.paper;
 paper.dataset.spacing=state.spacing;
 paper.classList.toggle('full-width',state.wideReader);
 const colors=custom?{
  '--custom-page':background,'--custom-ink':ink,
  '--custom-panel':mixColors(background,ink,.09),
  '--custom-line':mixColors(background,ink,.23),
  '--custom-scheme':luminance(background)<.3?'dark':'light'
 }:{};
 for(const name of ['--custom-page','--custom-ink','--custom-panel','--custom-line','--custom-scheme']){
  if(custom)paper.style.setProperty(name,colors[name]);
  else paper.style.removeProperty(name);
 }
}
function changeAppearance(control){
 const setting=control.dataset.readingSetting;
 switch(setting){
  case 'paper':state.paper=pagePresets.some(([key])=>key===control.value)?control.value:'auto';break;
  case 'wideReader':state.wideReader=control.checked;break;
  case 'spacing':state.spacing=control.value==='wide'?'wide':'normal';break;
  case 'paperBackground':case 'paperText':state[setting]=safeColor(control.value,state[setting]);break;
  default:return;
 }
 applyAppearance();persist();
}
function resetAppearance(){
 for(const key of ['paper','wideReader','spacing','paperBackground','paperText'])state[key]=DEFAULT[key];
 applyAppearance();persist();toast('Оформление чтения сброшено');
}

const APP_VERSION='2.0.2';
let workerRegistration=null, workerReady=null, checkingUpdate=false;
function setupAppUpdates(){
 if(!('serviceWorker' in navigator)||!/^https?:$/.test(location.protocol))return;
 workerReady=navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'})
  .then(registration=>{
   workerRegistration=registration;
   announceUpdate(!!registration.waiting);
   registration.addEventListener('updatefound',()=>{
    const worker=registration.installing;
    worker?.addEventListener('statechange',()=>{
     if(worker.state==='installed'&&navigator.serviceWorker.controller)announceUpdate(true);
    });
   });
   return registration;
  }).catch(()=>null);
}
function announceUpdate(available=!!workerRegistration?.waiting){
 for(const button of $$('[data-act="app-update"]')){
  button.classList.toggle('update-available',available);
  button.title=available?'Установить доступное обновление':'Проверить обновление приложения';
  if(button.id==='updateApp')button.setAttribute('aria-label',button.title);
 }
}
function waitForInstall(worker){
 if(!worker||!['installing','parsed'].includes(worker.state))return Promise.resolve();
 return new Promise(resolve=>{
  const done=()=>{
   clearTimeout(timer);
   worker.removeEventListener('statechange',changed);resolve();
  };
  const changed=()=>{if(!['parsed','installing'].includes(worker.state))done();};
  const timer=setTimeout(done,12000);
  worker.addEventListener('statechange',changed);
 });
}
async function fetchReleaseVersion(){
 const request=new AbortController();
 const timeout=setTimeout(()=>request.abort(),10000);
 try{
  const response=await fetch('./release.json',{cache:'no-store',redirect:'error',signal:request.signal});
  if(!response.ok)throw Error();
  const {version}=await response.json();
  if(typeof version!=='string'||!/^\d+\.\d+\.\d+$/.test(version))throw Error();
  return version;
 }catch{
  throw Error('Сервер обновлений недоступен. Текущая версия работает.');
 }finally{clearTimeout(timeout);}
}
function workerVersion(worker){
 if(!worker)return Promise.resolve('');
 return new Promise(resolve=>{
  const channel=new MessageChannel();
  const done=version=>{
   clearTimeout(timeout);
   channel.port1.close();
   resolve(version);
  };
  const timeout=setTimeout(()=>done(''),1500);
  channel.port1.onmessage=event=>done(event.data);
  try{worker.postMessage({type:'GET_VERSION'},[channel.port2]);}
  catch{done('');}
 });
}
function activateUpdate(worker,workers){
 if(workers.controller===worker)return Promise.resolve();
 return new Promise((resolve,reject)=>{
  const finish=error=>{
   clearTimeout(timeout);
   workers.removeEventListener('controllerchange',changed);
   if(error)reject(error);else resolve();
  };
  const changed=()=>{if(workers.controller===worker)finish();};
  const timeout=setTimeout(()=>finish(Error('Обновление подготовлено. Закройте и снова откройте читалку.')),10000);
  workers.addEventListener('controllerchange',changed);
  if(workers.controller===worker){finish();return;}
  try{worker.postMessage({type:'ACTIVATE_UPDATE'});}
  catch(error){finish(error);}
 });
}
async function checkAppUpdate(){
 if(checkingUpdate)return;
 if(location.protocol==='file:'){
  toast('Автономный HTML обновляется заменой файла. Веб-версия обновляется в браузере.');
  return;
 }
 if(!navigator.onLine){toast('Для проверки обновлений нужен интернет.');return;}
 checkingUpdate=true;
 for(const button of $$('[data-act="app-update"]'))button.disabled=true;
 try{
  toast('Проверяем обновление…');
  const release=await fetchReleaseVersion();
  if(release===APP_VERSION){toast(`Версия ${APP_VERSION} актуальна.`);return;}
  const registration=await workerReady;
  if(!registration)throw Error('Обновление недоступно здесь. Откройте приложение на HTTPS-сайте.');
  toast(`Устанавливаем версию ${release}…`);
  const workers=navigator.serviceWorker;
  if(await workerVersion(workers.controller)!==release){
   let waiting=registration.waiting;
   if(await workerVersion(waiting)!==release){
    await registration.update();
    await waitForInstall(registration.installing);
    waiting=registration.waiting;
   }
   if(await workerVersion(waiting)===release)await activateUpdate(waiting,workers);
  }
  if(await workerVersion(workers.controller)!==release){
   throw Error(`Доступна версия ${release}. Обновление ещё не установлено. Повторите проверку.`);
  }
  location.reload();
 }catch(error){toast(error.message||'Не удалось проверить обновление.');}
 finally{
  checkingUpdate=false;
  for(const button of $$('[data-act="app-update"]'))button.disabled=false;
  announceUpdate();
 }
}

const PUBLIC_SITE='https://dansklaeser.gontagro.chatgpt.site/';
function appShareURL(){
 return location.protocol==='file:'?PUBLIC_SITE:new URL('./',location.href).href;
}
async function shareApp(){
 const url=appShareURL();
 try{
  if(navigator.share){await navigator.share({title:'DanskLæser',url});return;}
 }catch(error){if(error.name==='AbortError')return;}
 try{
  if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);toast('Ссылка на приложение скопирована');return;}
 }catch{}
 const dialog=$('#shareDialog');
 $('#shareLink').value=url;
 dialog.showModal();
 $('#shareLink').select();
}
function speedControl(){
 return `<select class="rate-select reader-rate" id="ttsRate" aria-label="Скорость чтения" title="Скорость чтения">${[.7,.85,1,1.15,1.3].map(rate=>`<option value="${rate}">${rate}×</option>`).join('')}</select>`;
}

const onlineCatalog=window.DANSK_ONLINE_BOOKS||[];
const onlineSaved=new Map();
const wikiResults=new Map();
const onlineDBName='dansklaeser.online.v1';
let onlineDB,onlineController=null,wikiQuery='';
function openOnlineDB(){
 if(!onlineDB){
  onlineDB=new Promise((resolve,reject)=>{
   if(!window.indexedDB){reject(Error('Хранилище браузера недоступно.'));return;}
   const request=indexedDB.open(onlineDBName,1);
   request.onupgradeneeded=()=>request.result.createObjectStore('books',{keyPath:'id'});
   request.onsuccess=()=>resolve(request.result);
   request.onerror=()=>reject(Error('Хранилище браузера недоступно.'));
  });
 }
 return onlineDB;
}
async function onlineStore(mode,work){
 const db=await openOnlineDB();
 return new Promise((resolve,reject)=>{
  const tx=db.transaction('books',mode);
  const request=work(tx.objectStore('books'));
  tx.oncomplete=()=>resolve(request.result);
  tx.onabort=()=>reject(Error('Не удалось сохранить данные на устройстве.'));
  tx.onerror=()=>reject(Error('Не удалось сохранить данные на устройстве.'));
 });
}
async function restoreOnlineBooks(){
 const initialHash=location.hash;
 try{
  const entries=await onlineStore('readonly',store=>store.getAll());
  for(const book of entries)if(Array.isArray(book.paragraphs)&&book.paragraphs.length)onlineSaved.set(book.id,book);
 }catch{}
 if(!onlineSaved.size)return;
 // Restore a saved book from a direct link once its local data is available.
 if(location.hash===initialHash&&/^#(?:reader|vocabulary)\//.test(initialHash)&&view==='library'){
  restoreRoute();return;
 }
 if(view==='library')renderLibrary();
 if(view==='online')updateOnlineCatalog();
}
function cancelOnline(){
 onlineController?.abort();
 onlineController=null;
}
async function fetchPublicData(url,signal){
 const response=await fetch(url,{credentials:'omit',signal,referrerPolicy:'no-referrer'});
 if(!response.ok)throw Error(`Сервер вернул ошибку ${response.status}.`);
 const text=await response.text();
 if(text.length>4000000)throw Error('Текст слишком большой. Откройте отдельную главу.');
 const data=JSON.parse(text);
 if(data.error)throw Error('Викиисточник не вернул текст.');
 return data;
}
function onlineStatus(text){
 const status=$('#onlineStatus');
 if(status)status.textContent=text;
}
function renderOnline(){
 view='online';
 updateSideNav();
 $('#crumb').textContent='Онлайн-библиотека';
 $('#pageContent').innerHTML=`<div class="page-inner online-panel"><button class="button" data-act="back-library">${icon('chevron')} К библиотеке</button><h1 class="page-title">Онлайн-библиотека</h1>
 <p class="page-description">Длинные произведения из подборки входят в офлайн-комплект приложения. Интернет нужен для поиска новых произведений в Викиисточнике.</p>
 <button type="button" class="button" id="jumpWikiSearch">${icon('search')} К поиску в Викиисточнике</button>
 <h2>Длинные произведения (${onlineCatalog.length})</h2>
 ${location.protocol==='file:'?`<p class="online-note">Длинные произведения из подборки включены в приложение. Для поиска новых книг во Викиисточнике потребуется интернет.</p>`:''}
 <div id="onlineCatalogList" class="online-results"></div><h2>Поиск в датском Викиисточнике</h2>
 <form id="wikiSearchForm" class="online-form"><input id="wikiQuery" type="search" maxlength="100" required placeholder="Название на датском" aria-label="Название произведения" value="${esc(wikiQuery)}"><button class="button button-primary" type="submit">${icon('search')} Найти</button></form>
 <p class="online-note">Если произведение разбито на страницы, найдите название нужной главы.</p><p id="onlineStatus" role="status"></p><div id="wikiResults" class="online-results"></div></div>`;
 $('#jumpWikiSearch').addEventListener('click',()=>$('#wikiQuery').focus());
 $('#wikiSearchForm').addEventListener('submit',event=>{event.preventDefault();searchWikisource();});
 updateOnlineCatalog();updateWikiResults();
}
function updateOnlineCatalog(){
 const list=$('#onlineCatalogList');
 if(!list)return;
 list.innerHTML=onlineCatalog.map(book=>{
  const saved=onlineSaved.has(book.id);
  const btn=saved?`<button class="button" data-act="open-book" data-id="${book.id}">Читать офлайн</button>`:location.protocol==='file:'?'':`<button class="button" data-act="download-book" data-id="${book.id}">${icon('book')} Читать</button>`;
  return `<div class="online-entry"><div><strong lang="da">${esc(book.title)}</strong><p>${esc(book.author)} · ${book.minutes} мин</p>${book.summary?`<p>${esc(book.summary)}</p>`:''}</div>${btn}</div>`;
 }).join('');
}
function updateWikiResults(){
 const node=$('#wikiResults');
 if(!node)return;
 node.innerHTML=[...wikiResults.values()].map(result=>`<div class="online-entry"><div><strong lang="da">${esc(result.title)}</strong><p><a href="${wikiPageURL(result.pageid)}" target="_blank" rel="noopener noreferrer">Источник ↗</a></p></div><button class="button" data-act="download-wiki" data-id="${result.pageid}">${icon('book')} Открыть</button></div>`).join('');
}
function wikiPageURL(id){return 'https://da.wikisource.org/?curid='+Number(id);}
function wikiAPI(parameters){
 return 'https://da.wikisource.org/w/api.php?'+new URLSearchParams({origin:'*',format:'json',formatversion:'2',...parameters});
}
async function onlineWork(message,callback,{bundled=false}={}){
 if(!bundled&&!navigator.onLine){onlineStatus('Для загрузки нужен интернет. Уже загруженные книги есть в библиотеке.');return;}
 cancelOnline();
 const controller=new AbortController();
 onlineController=controller;
 onlineStatus(message);
 const timeout=setTimeout(()=>controller.abort('timeout'),17000);
 try{await callback(controller.signal);}
 catch(error){
  if(onlineController===controller){
   onlineStatus(controller.signal.reason==='timeout'?'Время ожидания истекло. Повторите загрузку.':
    error instanceof TypeError?'Не удалось подключиться к источнику. Проверьте интернет и повторите.':String(error.message||'Не удалось загрузить текст.'));
  }
 }finally{
  clearTimeout(timeout);
  if(onlineController===controller)onlineController=null;
 }
}
async function searchWikisource(){
 wikiQuery=$('#wikiQuery').value.trim();
 if(!wikiQuery)return;
 wikiResults.clear();updateWikiResults();
 await onlineWork('Ищем произведения…',async signal=>{
  const response=await fetchPublicData(wikiAPI({action:'query',list:'search',srnamespace:'0',srlimit:'16',srsearch:wikiQuery}),signal);
  if(signal.aborted)return;
  for(const row of response.query?.search||[])if(Number.isInteger(row.pageid)&&typeof row.title==='string')wikiResults.set(row.pageid,row);
  updateWikiResults();
  onlineStatus(wikiResults.size?`Найдено: ${wikiResults.size}.`:'Совпадений нет. Уточните название на датском.');
 });
}
function wikimediaText(markup){
 if(typeof markup!=='string')return [];
 const template=document.createElement('template');
 template.innerHTML=markup;
 const root=template.content.querySelector('.mw-parser-output')||template.content;
 root.querySelectorAll('table,style,script,link,iframe,.ws-noexport,.noprint,.mw-editsection,.toc,.reflist,.references,.ws-header,.licenseContainer,.pagenum,.ws-pagenum,.prp-pagequality,.mw-page-container,.catlinks,.thumb,.sisterproject').forEach(node=>node.remove());
 const blocks=[];
 for(const el of root.querySelectorAll('p,h2,h3,h4,div.poem')){
  if(el.closest('div.poem')!==el&&el.closest('div.poem'))continue;
  const text=el.textContent.trim().replace(/\s+/g,' ');
  if(text)blocks.push(text);
 }
 const chars=blocks.reduce((n,block)=>n+block.length,0);
 if(chars<140)return [];
 if(chars>1500000)throw Error('Страница слишком длинная. Откройте отдельную главу.');
 return splitReadingBlocks(blocks);
}
function splitReadingBlocks(blocks){
 return blocks.flatMap(value=>{
  const parts=[];
  let text=value.trim();
  while(text.length>1250){
   const space=text.lastIndexOf(' ',1250);
   const cut=space>500?space:1250;
   parts.push(text.slice(0,cut));
   text=text.slice(cut).trimStart();
  }
  if(text)parts.push(text);
  return parts;
 });
}
async function saveOnlineBook(book,signal){
 if(signal.aborted)return;
 book.onlineSaved=true;
 let saved=true;
 try{await onlineStore('readwrite',store=>store.put(book));}
 catch{saved=false;}
 if(signal.aborted)return;
 onlineSaved.set(book.id,book);
 openBook(book.id);
 if(!saved)toast('Текст открыт до закрытия страницы. Браузер не сохранил его для офлайн-чтения.');
}
async function downloadOnline(id){
 const meta=onlineCatalog.find(book=>book.id===id);
 if(!meta)return;
 if(onlineSaved.has(id)){openBook(id);return;}
 await onlineWork(`Загружаем «${meta.title}»…`,async signal=>{
  const data=await fetchPublicData('./books/'+meta.id+'.json',signal);
  if(!Array.isArray(data.paragraphs)||!data.paragraphs.length||!data.paragraphs.every(p=>typeof p==='string'))throw Error('Сервер не вернул текст произведения.');
  await saveOnlineBook({...meta,paragraphs:data.paragraphs},signal);
 },{bundled:true});
}
async function downloadWiki(rawId){
 const pageid=Number(rawId);
 const result=wikiResults.get(pageid);
 if(!result)return;
 const id='wiki-'+pageid;
 if(onlineSaved.has(id)){openBook(id);return;}
 await onlineWork(`Открываем «${result.title}»…`,async signal=>{
  const data=await fetchPublicData(wikiAPI({action:'parse',pageid,prop:'text',disableeditsection:'1',disabletoc:'1'}),signal);
  const paragraphs=wikimediaText(data.parse?.text);
  if(!paragraphs.length)throw Error('На странице мало текста. Откройте отдельную главу или другое произведение.');
  await saveOnlineBook({id,title:result.title,author:'Датский Викиисточник',sourceTitle:'Датский Викиисточник',
    sourceUrl:wikiPageURL(pageid),level:'C1',genre:'Онлайн-текст',paragraphs,summary:'Текст из датского Викиисточника.'},signal);
 });
}
async function removeOnlineBook(){
 const id=activeBookId;
 if(!onlineSaved.has(id)||!confirm('Удалить загруженную копию с этого устройства?'))return;
 try{await onlineStore('readwrite',store=>store.delete(id));}
 catch{toast('Не удалось удалить загруженную книгу.');return;}
 leaveReader();onlineSaved.delete(id);view='online';setView('online');
 toast('Загруженная копия удалена');
}

function phrasePieces(text,verse){
 if(verse)return [...text.matchAll(/[^\n]+/g)].map(match=>({segment:match[0],index:match.index}));
 if(sentenceSegmenter)return [...sentenceSegmenter.segment(text)];
 return [...text.matchAll(/[^.!?…]+[.!?…]*|[.!?…]+/g)].map(match=>({segment:match[0],index:match.index}));
}
function phraseExplanation(){
 const book=getBook(activeBookId);
 const sentence=book&&sentencesOf(book)[sentenceIndex];
 if(!sentence)return null;
 const source=sentence.text;
 const fixed=book.phraseRu?.[sentence.p]?.[source];
 const saved=state.phraseTranslations[source];
 return {source,translation:fixed||saved||'',automatic:!fixed&&!!saved,label:book.verse?'Перевод строки':'Перевод предложения'};
}
function renderPhraseExplanation(){
 const phrase=phraseExplanation();
 if(!phrase)return '';
 return `<details class="sentence-translation" ${state.paragraphTranslations?'open':''}>
 <summary>${phrase.label}</summary>
 <p id="phraseResult" lang="ru" role="status">${esc(phrase.translation+(phrase.automatic?' · автоматический перевод':''))}</p>
 ${phrase.translation?'':'<button class="button" data-act="phrase-translate">Перевести онлайн</button>'}</details>`;
}
function translationChunks(text){
 const result=[];
 const encoder=new TextEncoder();
 let part='',bytes=0;
 for(const ch of text){
  const count=encoder.encode(ch).length;
  if(bytes+count>440){
   const space=part.lastIndexOf(' ');
   if(space>100){
    result.push(part.slice(0,space));
    part=part.slice(space+1);bytes=encoder.encode(part).length;
   }else{
    result.push(part);part='';bytes=0;
   }
  }
  part+=ch;bytes+=count;
 }
 if(part.trim())result.push(part.trim());
 return result;
}
async function translateCurrentPhrase(button){
 const phrase=phraseExplanation(),output=$('#phraseResult');
 if(!phrase||phrase.translation)return;
 if(!navigator.onLine){output.textContent='Для перевода этого текста нужен интернет.';return;}
 const version=translationVersion;
 button.disabled=true;
 output.textContent='Переводим…';
 try{
  const parts=[];
  for(const chunk of translationChunks(phrase.source))parts.push(await requestTranslation(chunk,undefined,1200));
  if(version!==translationVersion)return;
  const translation=parts.join(' ');
  const saved=state.phraseTranslations;
  if(Object.keys(saved).length>=250)delete saved[Object.keys(saved)[0]];
  saved[phrase.source]=translation;
  persist();
  if(output.isConnected){output.textContent=translation+' · автоматический перевод';button.hidden=true;}
 }catch{
  if(output.isConnected)output.textContent='Переводчик недоступен. Попробуйте ещё раз.';
 }finally{button.disabled=false;}
}

const sentenceSegmenter = window.Intl && typeof Intl.Segmenter === 'function' ? new Intl.Segmenter('da', {granularity:'sentence'}) : null;
const sentenceCache = new WeakMap();
function sentencesOf(book){
 let sentences=sentenceCache.get(book);
 if(sentences)return sentences;
 sentences=[];
 book.paragraphs.forEach((text,p)=>{
  const segments=phrasePieces(text,book.verse);
  for(const {segment,index} of segments){
   const clean=segment.trim();
   if(clean)sentences.push({p,text:clean,offset:index+segment.indexOf(clean)});
  }
 });
 sentenceCache.set(book,sentences);
 return sentences;
}
function sentenceIndexFor(book,p,offset=0){
 const list=sentencesOf(book);
 let index=list.findIndex(s=>s.p>p || (s.p===p && s.offset>offset));
 if(index===-1)index=list.length;
 return Math.max(0,index-1);
}
function ruParagraph(book,p){
 return book.paragraphRu?.[p] || '';
}
function storyParagraph(book,p){
 const translation=ruParagraph(book,p);
 return `<div class="story-paragraph ${state.bookmarks[book.id]===p?'is-bookmarked':''}" data-p="${p}"><div lang="da" class="paragraph-text">${paragraphPlay(p)}${paragraphHTML(book.paragraphs[p],p)}</div>${translation?`<p class="paragraph-ru" lang="ru">${esc(translation)}</p>`:''}</div>`;
}
function updateReadingOptions(){
 const paper=$('.reader-paper');
 if(!paper)return;
 paper.classList.toggle('with-translations',state.paragraphTranslations);
 paper.classList.toggle('focus-reading',state.readerFocus);
 applyAppearance();
 $('#sentenceMode').setAttribute('aria-pressed',String(sentenceMode));
 const ru=$('[data-act="paragraph-translations"]');
 if(ru)ru.setAttribute('aria-pressed',String(state.paragraphTranslations));
 const focus=$('[data-act="reader-focus"]');
 focus.setAttribute('aria-pressed',String(state.readerFocus));
}
function renderSentence(){
 const book=getBook(activeBookId),card=$('#sentenceCard');
 const list=sentencesOf(book),s=list[sentenceIndex];
 if(!card||!s)return;
 const itemLabel=book.verse?'Строка':'Предложение';
 card.innerHTML=`<div class="sentence-header"><span id="sentenceCount" aria-live="polite">${itemLabel} ${sentenceIndex+1} из ${list.length}</span><button class="button" data-act="sentence-speak" title="Управлять озвучкой фразы">${icon('volume')} Прослушать</button></div>
 <div class="sentence-text" lang="da">${paragraphHTML(s.text,s.p,s.offset)}</div>
 ${renderPhraseExplanation()}
 <div class="sentence-nav"><button class="button" data-act="sentence-prev" ${sentenceIndex===0?'disabled':''}>${icon('chevron')} Назад</button><button class="button button-primary" data-act="sentence-next" ${sentenceIndex===list.length-1?'disabled':''}>Дальше ${icon('chevron-right')}</button></div>`;
 storeReadingPosition(book,s.p,s.offset);
 if(fullscreenReader)fullscreenReader.anchor=captureReadingAnchor(fullscreenReader.area);
 updateTTSButton();
}
function showReaderPosition(p){
 const display=()=>$(`.story-paragraph[data-p="${p}"]`);
 while(p<readerFirst && readerFirst>0)prependReaderText();
 while(p>=readerLast && p<getBook(activeBookId).paragraphs.length)appendReaderText();
 const area=$('#readerArea'),paragraph=display();
 if(area&&paragraph)area.scrollTo({top:area.scrollTop+paragraph.getBoundingClientRect().top-area.getBoundingClientRect().top-10,behavior:'instant'});
}
function setSentenceMode(enabled){
 const book=getBook(activeBookId),area=$('#readerArea');
 if(!book||!area||!sentencesOf(book).length)return;
 const p=visibleParagraph();
 stopReading();closePanel();
 sentenceMode=enabled;
 if(enabled)sentenceIndex=sentenceIndexFor(book,p,state.sentenceOffsets[book.id]);
 $('#readerFlow').hidden=enabled;
 $('#sentenceCard').hidden=!enabled;
 updateReadingOptions();
 if(enabled){area.scrollTop=0;renderSentence();}
 else showReaderPosition(p);
}
function switchSentence(step){
 const book=getBook(activeBookId);
 stopReading();closePanel();
 sentenceIndex=Math.min(sentencesOf(book).length-1,Math.max(0,sentenceIndex+step));
 renderSentence();
 $('#readerArea').scrollTop=0;
 const next=$(step<0?'[data-act="sentence-prev"]':'[data-act="sentence-next"]');
 (next.disabled?$('#sentenceMode'):next).focus({preventScroll:true});
}
function speakSentence(){
 const s=sentencesOf(getBook(activeBookId))[sentenceIndex];
 if(s)startSpeech(speechItems({paragraphs:[s.text]},0,0));
}
function renderFlashcard(){
 const box=$('#reviewCard');
 if(!box)return;
 reviewWords=reviewWords.filter(w=>state.favorites[w]&&!state.favorites[w].learned);
 if(!reviewWords.length){
  box.innerHTML='<p role="status">Все слова в этой подборке выучены.</p><button class="button" data-act="review-close">К списку слов</button>';
  return;
 }
 reviewIndex%=reviewWords.length;
 const word=reviewWords[reviewIndex],item=state.favorites[word];
 box.innerHTML=`<div class="review-head"><span aria-live="polite">Карточка ${reviewIndex+1} из ${reviewWords.length}</span><button class="icon-button" data-act="review-close" title="Закрыть карточки" aria-label="Закрыть карточки">${icon('x')}</button></div>
 <strong class="review-word" lang="da">${esc(word)}</strong>
 <p class="review-answer" ${reviewRevealed?'':'hidden'}>${esc(item.translation)}</p>
 <div class="review-actions"><button class="button" data-act="speak-favorite" data-word="${esc(word)}" title="Прослушать слово">${icon('volume')} Слушать</button>
 ${reviewRevealed?'<button class="button button-primary" data-act="review-learn">Выучено</button>':'<button class="button button-primary" data-act="review-reveal">Показать перевод</button>'}
 <button class="button" data-act="review-next">Дальше ${icon('chevron-right')}</button></div>`;
}
function startReview(){
 const words=Object.entries(state.favorites).filter(([,item])=>!item.learned).map(([word])=>word);
 if(!words.length)return toast('Добавьте слова для повторения в читалке.');
 reviewWords=words;reviewIndex=0;reviewRevealed=false;
 const card=$('#reviewCard');card.hidden=false;renderFlashcard();
 card.scrollIntoView({block:'nearest'});$('[data-act="review-reveal"]',card).focus({preventScroll:true});
}
function reviewAction(action){
 const card=$('#reviewCard');
 if(action==='review-close'){renderFavorites();$('[data-act="review-start"]').focus();return;}
 if(action==='review-learn'){
  state.favorites[reviewWords[reviewIndex]].learned=true;
  persist();renderFavorites();$('#reviewCard').hidden=false;
 }
 if(action==='review-next')reviewIndex++;
 reviewRevealed=action==='review-reveal';
 renderFlashcard();
 const current=$('#reviewCard');
 if(card!==current)current.scrollIntoView({block:'nearest'});
 ($(`[data-act="${reviewRevealed?'review-learn':'review-reveal'}"]`,current)||$('button',current))?.focus({preventScroll:true});
}

function dispatchAction(button){
 const {act,word,id,p}=button.dataset;
 switch(act){
  case 'open-book': openBook(id); break;
  case 'book-vocabulary': vocabQuery='';vocabOnlyMissing=false;vocabLimit=100;renderVocabulary();break;
  case 'back-to-book': openBook(activeBookId);break;
  case 'reader-fullscreen': void enterFullscreenReader(button);break;
  case 'reader-fullscreen-exit': void exitFullscreenReader();break;
  case 'word-details': case 'lookup': case 'favorite-detail': openWord(word,button);break;
  case 'batch-translate': translateBatch();break;
  case 'batch-stop': cancelBatch();break;
  case 'vocab-more': vocabLimit+=100;updateVocabularyList();break;
  case 'filter-level':
   selectedLevel=button.dataset.level;
   $$('.filter-pill').forEach(b=>{
    const selected=b===button;
    b.classList.toggle('active',selected);b.setAttribute('aria-pressed',String(selected));
   });
   pageLimit=24;updateBookResults();break;
  case 'load-more-books': pageLimit+=24;updateBookResults();break;
  case 'translate-online': translateOnline();break;
  case 'back-library': setView('library');break;
  case 'close-panel': closePanel(true);break;
  case 'edit-translation': {
   const edit=$('#popEdit');edit.hidden=!edit.hidden;placeWordPopover();
   if(!edit.hidden)$('#translationEdit').focus({preventScroll:true});
   break;
  }
  case 'tts-from-word': readFromWord();break;
  case 'tts-from': toggleParagraphSpeech(Number(p));break;
  case 'previous-book': bookNeighbor(-1);break;
  case 'next-book': bookNeighbor(1);break;
  case 'reader-next': appendReaderText();break;
  case 'reader-previous': prependReaderText();break;
  case 'pronounce-word': if(activeWord)pronounce(activeWord);break;
  case 'toggle-favorite': toggleFavorite();break;
  case 'save-translation': saveTranslation();break;
  case 'tts-toggle': toggleReading();break;
  case 'tts-stop': stopReading();break;
  case 'bookmark': bookmark();break;
  case 'jump-bookmark': jumpBookmark();break;
  case 'delete-text': deleteText();break;
  case 'font-minus': changeFont(-1);break;
  case 'font-plus': changeFont(1);break;
  case 'sentence-mode': setSentenceMode(!sentenceMode);break;
  case 'sentence-prev': switchSentence(-1);break;
  case 'sentence-next': switchSentence(1);break;
  case 'sentence-speak': toggleReading();break;
  case 'paragraph-translations':
   state.paragraphTranslations=!state.paragraphTranslations;persist();updateReadingOptions();
   if(sentenceMode)renderSentence();
   break;
  case 'reader-focus': state.readerFocus=!state.readerFocus;persist();updateReadingOptions();break;
  case 'speak-favorite': pronounce(word);break;
  case 'learn-favorite':
   if(state.favorites[word]){state.favorites[word].learned=!state.favorites[word].learned;persist();renderFavorites();}
   break;
  case 'delete-favorite':
   if(state.favorites[word]){delete state.favorites[word];persist();renderFavorites();}
   break;
  case 'review-start': startReview();break;
  case 'review-close': case 'review-reveal': case 'review-next': case 'review-learn': reviewAction(act);break;
  case 'export-words': exportWords();break;
  case 'theme-toggle': setTheme(state.theme==='dark'?'light':'dark');renderSettings();break;
  case 'import-txt': $('#importTextFile').click();break;
  case 'toggle-paste': {
   const box=$('#pasteBox');box.hidden=!box.hidden;
   button.setAttribute('aria-expanded',String(!box.hidden));
   if(!box.hidden)$('#bookTitle').focus();
   break;
  }
  case 'save-pasted': addTextBook($('#bookTitle').value,$('#bookText').value);break;
  case 'test-voice': pronounce('Jeg læser dansk hver dag. Det er dejligt at lære et nyt sprog.');break;
  case 'backup-export': exportBackup();break;
  case 'backup-import': $('#importBackupFile').click();break;
  case 'reset-all': resetAll();break;
  case 'pwa-install': installPWA();break;
  case 'share-app': shareApp();break;
  case 'app-update': checkAppUpdate();break;
  case 'reset-appearance': resetAppearance();break;
  case 'online-library': setView('online');break;
  case 'download-book': downloadOnline(id);break;
  case 'download-wiki': downloadWiki(id);break;
  case 'delete-online': removeOnlineBook();break;
  case 'phrase-translate': translateCurrentPhrase(button);break;
 }
}
function init(){
 applyTheme();
 $('#shareApp').innerHTML=icon('share');
 $('#updateApp').innerHTML=icon('refresh');
 const brandIcon=$('link[rel=icon]').href;
 for(const mark of $$('.brand-mark')){
  const image=new Image();
  image.alt='';
  image.src=brandIcon;
  mark.replaceChildren(image);
 }
 $$('.nav-item,.mobile-tab').forEach(btn=>btn.addEventListener('click',()=>setView(btn.dataset.view)));
 $('#brandBtn').addEventListener('click',()=>setView('library'));
 $('#themeQuick').addEventListener('click',()=>{
  setTheme(state.theme==='dark'?'light':'dark');
  if(view==='settings')renderSettings();
 });
 $('#mobileMenu').addEventListener('click',()=>{
  const open=$('#sidebar').classList.toggle('open');
  $('#sidebarScrim').hidden=!open;
  $('#mobileMenu').setAttribute('aria-expanded',String(open));
  if(open)$('[data-view="library"]',$('#sidebar')).focus({preventScroll:true});
 });
 $('#sidebarScrim').addEventListener('click',()=>{closeMenu();$('#mobileMenu').focus();});
 $('#panelScrim').addEventListener('click',()=>closePanel(true));
 document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
   if(activeWord){closePanel(true);return;}
   if(fullscreenReader&&!fullscreenReader.native){void exitFullscreenReader();return;}
   if($('#sidebar').classList.contains('open')){closeMenu();$('#mobileMenu').focus();return;}
   const details=$('.reader-controls[open]');
   if(details){details.open=false;$('summary',details).focus();}
  }
  if(e.key==='Enter'&&e.target.id==='translationEdit'){e.preventDefault();saveTranslation();}
  if((e.key==='Enter'||e.key===' ')&&e.target.classList.contains('book-card')){
   e.preventDefault();openBook(e.target.dataset.id);
  }
 });
 document.addEventListener('fullscreenchange',updateNativeFullscreen);
 document.addEventListener('change',e=>{if(e.target.matches('[data-reading-setting]'))changeAppearance(e.target);});
 document.addEventListener('click',e=>{
  const details=$('.reader-controls[open]');
  if(details&&!e.target.closest('.reader-controls'))details.open=false;
  const button=e.target.closest('[data-act]');
  if(button)dispatchAction(button);
  else if(activeWord&&!e.target.closest('#dictionaryPanel'))closePanel();
 });
 window.addEventListener('resize',()=>{if(activeWord)placeWordPopover();});
 window.visualViewport?.addEventListener('resize',()=>{
  document.documentElement.style.setProperty('--visual-height',window.visualViewport.height+'px');
  if(activeWord)placeWordPopover();
 });
 for(const [id,callback] of [['importTextFile',importTXT],['importBackupFile',importBackup]]){
  $('#'+id).addEventListener('change',e=>{const file=e.target.files[0];e.target.value='';callback(file);});
 }
 if(synth){
  refreshVoices();
  if(synth.addEventListener)synth.addEventListener('voiceschanged',refreshVoices);
  else synth.onvoiceschanged=refreshVoices;
 }
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;});
 window.addEventListener('appinstalled',()=>{deferredInstall=null;toast('Приложение установлено');});
 window.addEventListener('pagehide',()=>leaveReader());
 window.addEventListener('popstate',restoreRoute);
 setupAppUpdates();
 restoreRoute();
 restoreOnlineBooks();
}

init();
bookProgress?.read('progress').then(value=>{
 if(savedSinceOpen)return;
 const current=localStorage.getItem(STORAGE);
 if(current){cleanState(JSON.parse(current));return bookProgress.write('progress',current);}
 if(typeof value!=='string')return;
 const restored=cleanState(JSON.parse(value));
 localStorage.setItem(STORAGE,value);
 state=restored;applyTheme();restoreRoute();
}).catch(()=>{});
})();

