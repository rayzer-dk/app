const status = document.querySelector('#status');
const retry = document.querySelector('#retry');
const targetVersion = '2.0.0';

function workerVersion(worker) {
  if (!worker) return Promise.resolve('');
  return new Promise(resolve => {
    const channel = new MessageChannel();
    const done = value => {
      clearTimeout(timer);
      channel.port1.close();
      resolve(value);
    };
    const timer = setTimeout(() => done(''), 400);
    channel.port1.onmessage = event => done(event.data);
    try {
      worker.postMessage({type: 'GET_VERSION'}, [channel.port2]);
    } catch {
      done('');
    }
  });
}

function waitForRepair(workers, registration) {
  return new Promise((resolve, reject) => {
    const cancel = () => {
      clearTimeout(timer);
      workers.removeEventListener('controllerchange', check);
    };
    const check = async () => {
      const version = await workerVersion(workers.controller);
      if (version === targetVersion) {
        cancel();
        resolve();
      } else if (registration.waiting && await workerVersion(registration.waiting) === targetVersion) {
        registration.waiting?.postMessage({type: 'ACTIVATE_UPDATE'});
      }
    };
    const timer = setTimeout(() => {
      cancel();
      reject(new Error('Обновление ещё не активировалось. Попробуйте снова.'));
    }, 15000);
    workers.addEventListener('controllerchange', check);
    check();
  });
}

async function repair() {
  retry.hidden = true;
  status.textContent = 'Обновляем приложение. Книги, закладки и настройки сохраняются.';
  const workers = navigator.serviceWorker;
  if (!workers) {
    location.replace('./');
    return;
  }
  try {
    const registration = await workers.register('./sw.js', {updateViaCache: 'none'});
    await registration.update();
    await waitForRepair(workers, registration);
    location.replace('./');
  } catch {
    status.textContent = 'Не удалось завершить обновление. Проверьте подключение и попробуйте снова.';
    retry.hidden = false;
  }
}

retry.addEventListener('click', repair);
repair();
