importScripts('./vendor/workbox-7.4.0.js');
const {clientsClaim,setCacheNameDetails,PrecacheController,PrecacheRoute,registerRoute}=OfflineWorkbox;
const scope=self.registration.scope;
const prefix='dansklaeser:'+scope+':';
const release='2.0.3';
const homePath=new URL(scope).pathname;
setCacheNameDetails({prefix,precache:'workbox',suffix:'assets'});
const precache=new PrecacheController({plugins:[{
 async cacheWillUpdate({response,request}){
  if(!response.ok||response.redirected)return null;
  if(new URL(request.url).pathname!==homePath)return response;
  if(!/^text\/html\b/i.test(response.headers.get('content-type')||''))return null;
  const marker='<meta name="dansklaeser-version" content="'+release+'"';
  return (await response.clone().text()).includes(marker)?response:null;
 }
}]});
precache.precache([{"url":"./","revision":"43e04adc6bcea47e8096860a"},{"url":"manifest.webmanifest?v=2.0.3","revision":"0e952b79c12d55e56d4c8edb","integrity":"sha256-DpUrecEtVeVtTI7bNo91s6CUANYpButoo4tRrtDN7iY="},{"url":"app-2.0.3.js","revision":"2c61ca5741b33234ddd286f9","integrity":"sha256-LGHKV0GzMjTd0ob5RkbZnrkU2FbyBZbYQaZILMC3vcU="},{"url":"app-2.0.0.css","revision":"cad1be66a7b0e9f1c6be9893","integrity":"sha256-ytG+Zqew6fHGvpiT4iAnIKP8o+wsZnuR+fMBn8pE1Jo="},{"url":"catalog-1.9.9.js","revision":"ae3b8beeae8bd24e5a6893cf","integrity":"sha256-rjuL7q6L0k5aaJPPjzCzUuCs1V+sbYqF+7aTn0gnMOU="},{"url":"icons/icon-180-1.9.8.png","revision":"9e3b996c9b53f906d33dd785","integrity":"sha256-njuZbJtT+QbTPdeFtNKKvHFfo/IRMToD4MFZXwDusl4="},{"url":"icons/icon-192-1.9.8.png","revision":"79e930f81e937d012d7bbca8","integrity":"sha256-eekw+B6TfQEte7yor27ICQadLVR9HLNw5/n4irBLsac="},{"url":"icons/icon-512-1.9.8.png","revision":"329007bfa46de890ab06f384","integrity":"sha256-MpAHv6Rt6JCrBvOEYNVPzKZmVsVpzigdLO611WbTNbg="},{"url":"icons/icon-maskable-1.9.8.png","revision":"4de2295e149d189b7235d01b","integrity":"sha256-TeIpXhSdGJtyNdAbhS5pVEYNR0ZHDc9ykmzdvHqaaz4="},{"url":"books/pg-10829.json","revision":"3658e0476541218d7a7752af","integrity":"sha256-NljgR2VBIY16d1KvIPR7dySB9dzMAVl6ewXp9BJa0Wc="},{"url":"books/pg-12698.json","revision":"062fd0ecb029ef73b67874e8","integrity":"sha256-Bi/Q7LAp73O2eHToubZWrfv43+j5KRemfm46ebcjfRs="},{"url":"books/pg-33562.json","revision":"12a62ecc46c787b335ff7a59","integrity":"sha256-EqYuzEbHh7M1/3pZMXWBqgvK1k34qXw7q6cyKyX35Ro="},{"url":"books/pg-34747.json","revision":"128580c8b1a08abc5a3d225b","integrity":"sha256-EoWAyLGgirxaPSJbWlKufrUskCQP3QBepimp4XNc7Gc="},{"url":"books/pg-36871.json","revision":"f9191213c6116f30312aedee","integrity":"sha256-+RkSE8YRbzAxKu3uRcFRwzGyaj+w5P12zMnVauc5y5A="},{"url":"books/pg-36942.json","revision":"61b30f09f91834abe870d66e","integrity":"sha256-YbMPCfkYNKvocNZuQktlrWYqurVG4JJrV1mtGDH/PFU="},{"url":"books/pg-37594.json","revision":"d50658c4643561ef5b6895f1","integrity":"sha256-1QZYxGQ1Ye9baJXxhJrQ1fO5fFKqVj3Gryr91zgYs2E="},{"url":"books/pg-38080.json","revision":"977c2434176df48b7d05146f","integrity":"sha256-l3wkNBdt9It9BRRvhaFVCFPpEzGWDSEI8VYm9S7Lunk="},{"url":"books/pg-40291.json","revision":"df04f44184406c78e2c10a7f","integrity":"sha256-3wT0QYRAbHjiwQp/DUKsMOm3EH1Ye07sT4gEXpwKFlM="},{"url":"books/pg-41045.json","revision":"d6deb74d029ec71067cecc7f","integrity":"sha256-1t63TQKexxBnzsx/bACvKH87kzNemJ6VwajcE0ajTzc="},{"url":"books/pg-43781.json","revision":"5a8e4dac186462d59065d1b5","integrity":"sha256-Wo5NrBhkYtWQZdG19EJ/uAhlgr8+1LfhoeZgUlVpoPc="},{"url":"books/pg-63722.json","revision":"3d9fef968b62479d5db93c49","integrity":"sha256-PZ/vlotiR51duTxJd+wR6sN+wcxPMMKXkJSQTInXItA="},{"url":"books/pg-75414.json","revision":"224c2df205704a1166f81b0f","integrity":"sha256-Ikwt8gVwShFm+BsPC9PzkhfoHmWQW7XFk+nM6OWvq4I="},{"url":"books/pg-76563.json","revision":"59cdbc22b3bd8558b46ec05b","integrity":"sha256-Wc28IrO9hVi0bsBbCc5k0Lg5R5Blhdv+CQeJB0CYxvc="},{"url":"books/pg-76723.json","revision":"e28e57f70d359c5d93ce3cd9","integrity":"sha256-4o5X9w01nF2TzjzZmTEXr9WIU1MrGuR3MblmhC43ei0="},{"url":"books/pg-76883.json","revision":"677987c4c6e8d2408b7aa791","integrity":"sha256-Z3mHxMbo0kCLeqeR3u/xoD+P0Hd5nzhvZ6XiyewO5Fw="},{"url":"books/pg-77037.json","revision":"40510c3f6f60da9a446d7858","integrity":"sha256-QFEMP29g2ppEbXhYbCgFJJ4c/ntaSPvqRKKu1KrVQ90="},{"url":"books/ws-lykke-per-1.json","revision":"781b0bd023cbd927b48c30aa","integrity":"sha256-eBsL0CPL2Se0jDCqe4n6Bl9WOAT7kUgMdkiv5iK+5KA="},{"url":"books/ws-lykke-per-2.json","revision":"6501ba855e23c0be765b5f86","integrity":"sha256-ZQG6hV4jwL52W1+G4GrsZ84Vdog4ZTUowfcHO12dVb0="}]);
registerRoute(new PrecacheRoute(precache,{directoryIndex:null,cleanURLs:false}));
registerRoute(({request,url,sameOrigin})=>sameOrigin&&request.mode==='navigate'&&url.pathname===homePath+'index.html',
 async ({request})=>await precache.matchPrecache(scope)||fetch(request));
registerRoute(({url,sameOrigin})=>sameOrigin&&url.pathname.startsWith(homePath)&&/\/(?:app(?:-[\d.]+)?\.(?:js|css)|catalog(?:-[\d.]+)?\.js)$/.test(url.pathname),
 async ({request})=>{
  const prior=(await caches.keys()).filter(key=>key.startsWith(prefix)&&/^\d+\.\d+\.\d+$/.test(key.slice(prefix.length)));
  for(const key of prior.reverse()){const stored=await (await caches.open(key)).match(request);if(stored)return stored;}
  return fetch(request);
 });
self.addEventListener('message',event=>{
 if(event.data?.type==='ACTIVATE_UPDATE')event.waitUntil(self.skipWaiting());
 if(event.data?.type==='GET_VERSION')event.ports[0]?.postMessage(release);
});
clientsClaim();
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const prior=(await caches.keys()).filter(key=>key.startsWith(prefix)&&/^\d+\.\d+\.\d+$/.test(key.slice(prefix.length)));
 await Promise.all(prior.slice(0,-1).map(key=>caches.delete(key)));
})()));
