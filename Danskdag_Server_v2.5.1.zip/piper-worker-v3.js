const MODEL_CONFIG={"audio":{"sample_rate":22050,"quality":"medium"},"espeak":{"voice":"da"},"inference":{"noise_scale":0.667,"length_scale":1,"noise_w":0.8},"phoneme_type":"espeak","phoneme_map":{},"phoneme_id_map":{"_":[0],"^":[1],"$":[2]," ":[3],"!":[4],"'":[5],"(":[6],")":[7],",":[8],"-":[9],".":[10],":":[11],";":[12],"?":[13],"a":[14],"b":[15],"c":[16],"d":[17],"e":[18],"f":[19],"h":[20],"i":[21],"j":[22],"k":[23],"l":[24],"m":[25],"n":[26],"o":[27],"p":[28],"q":[29],"r":[30],"s":[31],"t":[32],"u":[33],"v":[34],"w":[35],"x":[36],"y":[37],"z":[38],"æ":[39],"ç":[40],"ð":[41],"ø":[42],"ħ":[43],"ŋ":[44],"œ":[45],"ǀ":[46],"ǁ":[47],"ǂ":[48],"ǃ":[49],"ɐ":[50],"ɑ":[51],"ɒ":[52],"ɓ":[53],"ɔ":[54],"ɕ":[55],"ɖ":[56],"ɗ":[57],"ɘ":[58],"ə":[59],"ɚ":[60],"ɛ":[61],"ɜ":[62],"ɞ":[63],"ɟ":[64],"ɠ":[65],"ɡ":[66],"ɢ":[67],"ɣ":[68],"ɤ":[69],"ɥ":[70],"ɦ":[71],"ɧ":[72],"ɨ":[73],"ɪ":[74],"ɫ":[75],"ɬ":[76],"ɭ":[77],"ɮ":[78],"ɯ":[79],"ɰ":[80],"ɱ":[81],"ɲ":[82],"ɳ":[83],"ɴ":[84],"ɵ":[85],"ɶ":[86],"ɸ":[87],"ɹ":[88],"ɺ":[89],"ɻ":[90],"ɽ":[91],"ɾ":[92],"ʀ":[93],"ʁ":[94],"ʂ":[95],"ʃ":[96],"ʄ":[97],"ʈ":[98],"ʉ":[99],"ʊ":[100],"ʋ":[101],"ʌ":[102],"ʍ":[103],"ʎ":[104],"ʏ":[105],"ʐ":[106],"ʑ":[107],"ʒ":[108],"ʔ":[109],"ʕ":[110],"ʘ":[111],"ʙ":[112],"ʛ":[113],"ʜ":[114],"ʝ":[115],"ʟ":[116],"ʡ":[117],"ʢ":[118],"ʲ":[119],"ˈ":[120],"ˌ":[121],"ː":[122],"ˑ":[123],"˞":[124],"β":[125],"θ":[126],"χ":[127],"ᵻ":[128],"ⱱ":[129],"0":[130],"1":[131],"2":[132],"3":[133],"4":[134],"5":[135],"6":[136],"7":[137],"8":[138],"9":[139],"̧":[140],"̃":[141],"̪":[142],"̯":[143],"̩":[144],"ʰ":[145],"ˤ":[146],"ε":[147],"↓":[148],"#":[149],"\"":[150],"↑":[151],"̺":[152],"̻":[153]},"num_symbols":256,"num_speakers":1,"speaker_id_map":{},"piper_version":"0.2.0","language":{"code":"da_DK","family":"da","region":"DK","name_native":"Dansk","name_english":"Danish","country_english":"Denmark"},"dataset":"talesyntese"};
const CACHE='danskdag-piper-talesyntese-v1';
const ASSETS={
 'ort.js':'90533a3fd7006df7f897c0d63c468996da5c8e430e39964d92ebe586c4996614',
 'ort.wasm':'f533b5f21790563d7556c611c3835ac65848ee326da2689aac54ed7d9cc8c6a4',
 'phonemize.js':'fef0c2fc442d24fdef5c7c7cc37d5da2314407640fe11ab1bfe347c723dff19b',
 'phonemize.wasm':'b777cd107a91d2bcc6a1ea46f2c26a662a7407394fe84589198aeaa83dd7a9d6',
 'phonemize.data':'29f1025eb23a5b5c192cd14a6efbce4509402ff265405072ee6f7d1a09b78f8c',
 'model.onnx':'b9271efd25f7b8494bbd28d48dd675c8c119daa284f3ee488008935f515f1241'
};
const AUDIO_CACHE='danskdag-piper-audio-v1',AUDIO_LIMIT=16*1024*1024,AUDIO_COUNT=64;
const REGISTRY='danskdag-piper-custom-registry-v1',CUSTOM_PREFIX='danskdag-piper-custom-';
// The same-origin URLs identify stored data. First downloads go to the upstream publishers.
const root=new URL('/voice/v1/',self.location.origin);
const npmCdn='https://cdn.jsdelivr.net/npm/';
const voiceSources={
 'ort.js':npmCdn+'onnxruntime-web@1.18.0/dist/ort.wasm.min.js',
 'ort.wasm':npmCdn+'onnxruntime-web@1.18.0/dist/ort-wasm-simd.wasm',
 'phonemize.js':npmCdn+'@diffusionstudio/piper-wasm@1.0.0/build/piper_phonemize.js',
 'phonemize.wasm':npmCdn+'@diffusionstudio/piper-wasm@1.0.0/build/piper_phonemize.wasm',
 'phonemize.data':npmCdn+'@diffusionstudio/piper-wasm@1.0.0/build/piper_phonemize.data',
 'model.onnx':'https://huggingface.co/rhasspy/piper-voices/resolve/b4e358ffcb232591bf73a540e70f7de528e4174a/da/da_DK/talesyntese/medium/da_DK-talesyntese-medium.onnx'
};
const ACTIVE_KEY=new URL('custom/active.json',root).href,MODEL_KEY=new URL('custom/model.onnx',root).href,CONFIG_KEY=new URL('custom/config.json',root).href;
const SIZES={"ort.js":142930,"ort.wasm":10595041,"phonemize.js":120714,"phonemize.wasm":635212,"phonemize.data":18077249,"model.onnx":63201294};
let latestId=0,session=null,activeVoice=null,activeConfig=MODEL_CONFIG,phonemizer=null,output=null,cache=null,stored=true,chain=Promise.resolve(),busyVoice='builtin',loadedBytes=0,totalBytes=0,quiet=false;
const voiceError=code=>Object.assign(Error(code),{code});
let lastProgress='',lastProgressAt=0;
function progress(phase,percent){if(quiet)return;const key=busyVoice+phase+percent;if(key===lastProgress&&Date.now()-lastProgressAt<150)return;lastProgress=key;lastProgressAt=Date.now();self.postMessage({type:'progress',voiceId:busyVoice,phase,percent,cached:stored,loadedBytes,totalBytes});}
async function customMetadata(){try{const registry=await caches.open(REGISTRY),response=await registry.match(ACTIVE_KEY);return response?await response.json():null;}catch{return null;}}
async function inspectVoices(){
 try{
  const c=await caches.open(CACHE),files=await Promise.all(Object.keys(ASSETS).map(name=>c.match(new URL(name,root).href))),runtime=files.slice(0,5).every(Boolean),count=files.filter(Boolean).length;
  const bytes=files.reduce((sum,r)=>sum+Number(r?.headers.get('content-length')||0),0),meta=await customMetadata();
  let own=null;if(meta?.cacheName?.startsWith(CUSTOM_PREFIX)){const cache=await caches.open(meta.cacheName);own=await cache.match(MODEL_KEY);}
  return {builtin:{phase:count===6?'stored':count?'partial':'absent',cached:count===6,bytes,name:'Talesyntese'},custom:{phase:own?(runtime?'stored':'partial'):'absent',cached:!!own&&runtime,bytes:own?meta.bytes:0,name:meta?.name||''}};
 }catch{return {builtin:{phase:'unavailable',cached:false},custom:{phase:'unavailable',cached:false}};}
}
async function audioKey(voiceId,text,rate){
 const meta=voiceId==='custom'?await customMetadata():null;
 const identity=voiceId==='builtin'?ASSETS['model.onnx']:meta?.hash&&meta?.configHash?meta.hash+meta.configHash:null;
 if(!identity)return null;
 return new URL('audio/'+voiceId+'/'+await hash(new TextEncoder().encode(JSON.stringify([identity,text,rate]))),root).href;
}
async function readAudio(key){
 if(!key)return null;
 try{
  const c=await caches.open(AUDIO_CACHE),response=await c.match(key);if(!response)return null;
  const sampleRate=Number(response.headers.get('x-sample-rate')),bytes=await response.arrayBuffer();
  if(!bytes.byteLength||bytes.byteLength>2*1024*1024||bytes.byteLength%4||!Number.isInteger(sampleRate)||sampleRate<8000||sampleRate>48000){await c.delete(key);return null;}
  const pcm=new Float32Array(bytes);if(!pcm.every(Number.isFinite)){await c.delete(key);return null;}
  return {pcm,sampleRate};
 }catch{return null;}
}
async function saveAudio(key,pcm,sampleRate){
 if(!key||!pcm.byteLength||pcm.byteLength>2*1024*1024)return;
 try{
  const c=await caches.open(AUDIO_CACHE);await c.put(key,new Response(pcm.buffer,{headers:{'content-length':String(pcm.byteLength),'x-sample-rate':String(sampleRate)}}));
  const keys=await c.keys(),sizes=await Promise.all(keys.map(async k=>Number((await c.match(k))?.headers.get('content-length')||0)));let bytes=sizes.reduce((a,b)=>a+b,0),count=keys.length;
  for(let i=0;i<keys.length&&(bytes>AUDIO_LIMIT||count>AUDIO_COUNT);i++){await c.delete(keys[i]);bytes-=sizes[i];count--;}
 }catch{}
}
async function removeAudio(voiceId){try{const c=await caches.open(AUDIO_CACHE);for(const key of await c.keys())if(new URL(key.url).pathname.startsWith('/voice/v1/audio/'+voiceId+'/'))await c.delete(key);}catch{}}
async function load(name){
 const url=new URL(name,root).href;let response=await cache?.match(url),fromCache=!!response;
 if(!response){response=await fetch(voiceSources[name],{credentials:'omit',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(180000)});if(!response.ok)throw voiceError('download');}
 const reader=response.body?.getReader(),parts=[];let length=0;const previous=loadedBytes;
 if(reader){while(true){const {done,value}=await reader.read();if(done)break;parts.push(value);length+=value.length;loadedBytes=previous+length;progress(fromCache?'preparing':'downloading',Math.min(96,Math.round(loadedBytes/totalBytes*96)));}}
 else{const bytes=new Uint8Array(await response.arrayBuffer());parts.push(bytes);length=bytes.length;}
 const bytes=new Uint8Array(length);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 const digest=await hash(bytes);if(digest!==ASSETS[name]){await cache?.delete(url);throw voiceError('integrity');}
 if(!fromCache&&cache)try{await cache.put(url,new Response(bytes,{headers:{'content-length':String(length)}}));}catch{stored=false;}
 loadedBytes=previous+length;progress('preparing',Math.min(96,Math.round(loadedBytes/totalBytes*96)));return bytes;
}
async function hash(bytes){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');}
function validateVoiceConfig(config){
 if(!config||config.phoneme_type!=='espeak'||config.espeak?.voice!=='da'||config.num_speakers!==1||config.num_symbols!==MODEL_CONFIG.num_symbols||Object.keys(config.phoneme_map||{}).length)throw voiceError('config');
 if(!Number.isInteger(config.audio?.sample_rate)||config.audio.sample_rate<8000||config.audio.sample_rate>48000)throw voiceError('config');
 for(const [key,ids]of Object.entries(MODEL_CONFIG.phoneme_id_map))if(JSON.stringify(config.phoneme_id_map?.[key])!==JSON.stringify(ids))throw voiceError('config');
 for(const [key,min,max]of [['noise_scale',0,2],['noise_w',0,2],['length_scale',.1,4]])if(!Number.isFinite(config.inference?.[key])||config.inference[key]<min||config.inference[key]>max)throw voiceError('config');
 return config;
}
async function runtime(){
 if(phonemizer){loadedBytes=Object.keys(ASSETS).slice(0,5).reduce((sum,n)=>sum+SIZES[n],0);return;}
 stored=true;try{cache=await caches.open(CACHE);}catch{stored=false;}
 const data={};for(const name of Object.keys(ASSETS).slice(0,5))data[name]=await load(name);
 const urls=[];
 try{
  for(const name of ['ort.js','phonemize.js']){const url=URL.createObjectURL(new Blob([data[name]],{type:'text/javascript'}));urls.push(url);importScripts(url);}
  const wasmUrl=URL.createObjectURL(new Blob([data['ort.wasm']],{type:'application/wasm'}));urls.push(wasmUrl);
  ort.env.wasm.numThreads=1;ort.env.wasm.proxy=false;ort.env.wasm.wasmPaths={'ort-wasm-simd.wasm':wasmUrl};
  // The WASM URL stays alive until its first inference session has been created.
  self.ortWasmUrl=wasmUrl;
  phonemizer=await createPiperPhonemize({wasmBinary:data['phonemize.wasm'],getPreloadedPackage:()=>data['phonemize.data'].buffer,noInitialRun:true,print:text=>{try{output=JSON.parse(text).phoneme_ids;}catch{}},printErr:()=>{}});
 }finally{for(const url of urls)if(url!==self.ortWasmUrl)URL.revokeObjectURL(url);}
}
async function releaseSession(){await session?.release();session=null;activeVoice=null;}
async function openModel(bytes,config,voiceId){
 await releaseSession();progress('preparing',97);
 session=await ort.InferenceSession.create(bytes,{executionProviders:['wasm'],graphOptimizationLevel:'all'});
 if(!['input','input_lengths','scales'].every(name=>session.inputNames.includes(name))||!session.outputNames.includes('output')){await releaseSession();throw voiceError('config');}
 activeConfig=config;activeVoice=voiceId;if(self.ortWasmUrl){URL.revokeObjectURL(self.ortWasmUrl);self.ortWasmUrl=null;}
}
async function initialize(voiceId){
 if(session&&activeVoice===voiceId)return;
 loadedBytes=0;totalBytes=Object.entries(SIZES).filter(([name])=>voiceId==='builtin'||name!=='model.onnx').reduce((s,[,n])=>s+n,0);
 await runtime();
 if(voiceId==='custom'){
  const meta=await customMetadata();if(!meta?.cacheName?.startsWith(CUSTOM_PREFIX))throw voiceError('missing');
  const c=await caches.open(meta.cacheName),model=await c.match(MODEL_KEY),config=await c.match(CONFIG_KEY);if(!model||!config)throw voiceError('missing');
  const bytes=new Uint8Array(await model.arrayBuffer()),configText=await config.text(),parsed=validateVoiceConfig(JSON.parse(configText));if(await hash(bytes)!==meta.hash||await hash(new TextEncoder().encode(configText))!==meta.configHash)throw voiceError('integrity');
  await openModel(bytes,parsed,voiceId);
 }else await openModel(await load('model.onnx'),MODEL_CONFIG,voiceId);
}
async function synthesize(text,rate=1){
 output=null;try{phonemizer.callMain(['-l',activeConfig.espeak.voice,'--input',JSON.stringify([{text}]),'--espeak_data','/espeak-ng-data']);}catch(e){if(e?.status!==0)throw e;}
 if(!output?.length)throw voiceError('phonemes');
 const ids=BigInt64Array.from(output,BigInt),inf=activeConfig.inference;
 const feeds={input:new ort.Tensor('int64',ids,[1,ids.length]),input_lengths:new ort.Tensor('int64',BigInt64Array.of(BigInt(ids.length)),[1]),scales:new ort.Tensor('float32',Float32Array.of(inf.noise_scale,inf.length_scale/Math.min(2,Math.max(.3,Number(rate)||1)),inf.noise_w),[3])};if(session.inputNames.includes('sid'))feeds.sid=new ort.Tensor('int64',BigInt64Array.of(0n),[1]);
 const result=await session.run(feeds);
 return new Float32Array(result.output.data);
}
async function importVoice(message){
 const config=validateVoiceConfig(message.config),model=message.model;if(!(model instanceof ArrayBuffer)||model.byteLength<1024||model.byteLength>150*1024*1024)throw voiceError('config');
 let registry;try{registry=await caches.open(REGISTRY);}catch{throw voiceError('storage');}
 const previous=await customMetadata(),digest=await hash(model),configText=JSON.stringify(config),configHash=await hash(new TextEncoder().encode(configText));
 const name=String(message.name||'Piper').replace(/\.onnx$/i,'').replace(/[\u0000-\u001f\u007f]/g,'').slice(0,100),cacheName=CUSTOM_PREFIX+digest.slice(0,24)+'-'+configHash.slice(0,12),candidate=await caches.open(cacheName);
 try{
  loadedBytes=0;totalBytes=Object.entries(SIZES).filter(([n])=>n!=='model.onnx').reduce((s,[,n])=>s+n,0);await runtime();await openModel(new Uint8Array(model),config,'custom');
  const pcm=await synthesize('Hej.');if(!pcm.length||!pcm.some(value=>Number.isFinite(value)&&Math.abs(value)>0))throw voiceError('config');
  await candidate.put(MODEL_KEY,new Response(model,{headers:{'content-length':String(model.byteLength)}}));await candidate.put(CONFIG_KEY,new Response(configText));
  const meta={cacheName,hash:digest,configHash,name,bytes:model.byteLength,savedAt:Date.now()};await registry.put(ACTIVE_KEY,new Response(JSON.stringify(meta)));
  if(previous?.cacheName?.startsWith(CUSTOM_PREFIX)&&previous.cacheName!==cacheName)await caches.delete(previous.cacheName);
  return meta;
 }catch(error){if(previous?.cacheName!==cacheName)await caches.delete(cacheName);await releaseSession();throw error;}
}
async function removeVoice(voiceId){
 await removeAudio(voiceId);await releaseSession();const meta=await customMetadata();
 if(voiceId==='custom'){
  if(meta?.cacheName?.startsWith(CUSTOM_PREFIX))await caches.delete(meta.cacheName);await caches.delete(REGISTRY);
  const c=await caches.open(CACHE);if(!await c.match(new URL('model.onnx',root).href))await caches.delete(CACHE);
 }else if(meta){const c=await caches.open(CACHE);await c.delete(new URL('model.onnx',root).href);}else await caches.delete(CACHE);
}
async function handle(message){
 const {id,type}=message,voiceId=message.voiceId==='custom'?'custom':'builtin';busyVoice=voiceId;quiet=type==='prefetch';
 try{
  if(type==='inspect'){self.postMessage({id,type:'inspected',voices:await inspectVoices()});return;}
  if(type==='remove'){await removeVoice(voiceId);self.postMessage({id,type:'removed',voiceId,cached:false});return;}
  if(type==='import'){const meta=await importVoice(message);self.postMessage({id,type:'imported',voiceId:'custom',cached:true,name:meta.name,bytes:meta.bytes});return;}
  if(type==='prepare'){await initialize(voiceId);self.postMessage({id,type:'ready',voiceId,cached:stored});return;}
  if(!['synthesize','prefetch'].includes(type))throw voiceError('config');
  const text=String(message.text||'').trim(),rate=Math.min(2,Math.max(.3,Number(message.rate)||1));if(!text||text.length>280)throw voiceError('config');
  const key=await audioKey(voiceId,text,rate);let audio=await readAudio(key);
  if(!audio){
   if(type==='prefetch'&&activeVoice!==voiceId&&!(await inspectVoices())[voiceId].cached){self.postMessage({id,type:'prefetched',voiceId,skipped:true});return;}
   await initialize(voiceId);audio={pcm:await synthesize(text,rate),sampleRate:activeConfig.audio.sample_rate};await saveAudio(key,audio.pcm,audio.sampleRate);
  }
  if(type==='prefetch'){self.postMessage({id,type:'prefetched',voiceId,cached:true});return;}
  self.postMessage({id,type:'audio',voiceId,...audio,cached:stored},[audio.pcm.buffer]);
 }catch(error){self.postMessage({id,type:'error',voiceId,code:error.code||'runtime'});}
}
self.onmessage=({data})=>{if(data.type==='synthesize')latestId=data.id;chain=chain.then(()=>data.type==='synthesize'&&data.id!==latestId?undefined:handle(data));};
