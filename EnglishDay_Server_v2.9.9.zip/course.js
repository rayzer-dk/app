/* Original English-language course for EnglishDay. Source/learning language: Russian. */
(()=>{'use strict';
const lessons=[];
function add(level,group,title,rule,pairs){
 const id='en-'+String(lessons.length+1).padStart(3,'0');
 const examples=pairs.trim().split('\n').map(s=>{const p=s.trim().split('|');return {en:p[0]?.trim(),ru:p[1]?.trim()};}).filter(x=>x.en&&x.ru);
 lessons.push({id,level,group,title,rule,examples});
}
add('A1','Основы','Приветствия и прощания','Hello — нейтральное приветствие; Hi — разговорное. Good evening говорят при встрече вечером, Good night — при прощании или перед сном.',`
Hello!|Здравствуйте!
Hi!|Привет!
Good morning!|Доброе утро!
Good afternoon!|Добрый день!
Good evening!|Добрый вечер!
Good night!|Спокойной ночи!
Goodbye!|До свидания!
See you later!|Увидимся позже!
How are you?|Как дела?
I am fine, thanks.|У меня всё хорошо, спасибо.
Nice to meet you.|Приятно познакомиться.
You're welcome.|Пожалуйста (в ответ на благодарность).
`);
add('A1','Основы','Знакомство','I am / I’m и My name is — способы представиться. В английском обычно обязательно подлежащее.',`
My name is Alex.|Меня зовут Алекс.
I am from Ukraine.|Я из Украины.
I live in Denmark.|Я живу в Дании.
What is your name?|Как тебя зовут?
Where are you from?|Откуда ты?
I am thirty years old.|Мне тридцать лет.
This is my friend.|Это мой друг.
I speak a little English.|Я немного говорю по-английски.
I don't understand.|Я не понимаю.
Could you repeat that?|Не могли бы вы повторить?
Please speak more slowly.|Пожалуйста, говорите медленнее.
`);
add('A1','Грамматика','Личные местоимения','I — я, you — ты/вы, he/she/it — он/она/оно, we — мы, they — они. Английское I всегда пишется с заглавной буквы.',`
I am a student.|Я студент.
You are my friend.|Ты мой друг.
He is at home.|Он дома.
She is my sister.|Она моя сестра.
It is a small dog.|Это маленькая собака.
We are ready.|Мы готовы.
They are here.|Они здесь.
You are welcome here.|Вам здесь рады.
It is very cold today.|Сегодня очень холодно.
`);
add('A1','Грамматика','Глагол to be','В настоящем времени: I am; he/she/it is; you/we/they are. Отрицание: am not/is not/are not. В вопросе am/is/are ставится перед подлежащим.',`
I am happy.|Я счастлив.
She is tired.|Она устала.
We are at work.|Мы на работе.
They are not ready.|Они не готовы.
Are you busy?|Ты занят?
Is it expensive?|Это дорого?
He is not at home.|Его нет дома.
I am not late.|Я не опоздал.
Where are you?|Где ты?
`);
add('A1','Грамматика','Артикли a, an, the','A/an используют с исчисляемым существительным в единственном числе, когда предмет упоминается не как конкретный. An — перед гласным звуком: an hour, но a university. The — для конкретного предмета.',`
This is a book.|Это книга.
I need an apple.|Мне нужно яблоко.
The book is on the table.|Книга лежит на столе.
She is a doctor.|Она врач.
It is an old house.|Это старый дом.
I have a university degree.|У меня университетский диплом.
He waited for an hour.|Он ждал час.
Close the door, please.|Закрой дверь, пожалуйста.
`);
add('A1','Основы','Числа и количество','Числа 13–19 оканчиваются на -teen; десятки 20, 30, 40: twenty, thirty, forty. Forty пишется без буквы u.',`
One, two, three.|Один, два, три.
Ten, twenty, thirty.|Десять, двадцать, тридцать.
Forty-five.|Сорок пять.
One hundred.|Сто.
One thousand.|Тысяча.
Two thousand five hundred.|Две тысячи пятьсот.
One hundred thousand.|Сто тысяч.
One million.|Миллион.
How much does it cost?|Сколько это стоит?
There are twelve people.|Там двенадцать человек.
`);
add('A1','Словарь','Цвета и предметы','Прилагательное обычно стоит перед существительным: a red car, a beautiful house.',`
A red car.|Красная машина.
A blue sky.|Голубое небо.
A green tree.|Зелёное дерево.
A white shirt.|Белая рубашка.
Black shoes.|Чёрные туфли.
A yellow flower.|Жёлтый цветок.
A brown table.|Коричневый стол.
A grey jacket.|Серая куртка.
My phone is new.|Мой телефон новый.
The bag is heavy.|Сумка тяжёлая.
`);
add('A1','Словарь','Семья и отношения','Притяжательные формы my, your, his, her, our, their показывают принадлежность.',`
This is my mother.|Это моя мама.
My father works here.|Мой отец работает здесь.
She has two brothers.|У неё два брата.
He has one sister.|У него одна сестра.
We have three children.|У нас трое детей.
My daughter is seven.|Моей дочери семь лет.
His son is at school.|Его сын в школе.
Our grandparents live nearby.|Наши бабушка и дедушка живут рядом.
I love my family.|Я люблю свою семью.
`);
add('A1','Словарь','Дом и мебель','There is — есть/находится для единственного числа; there are — для множественного.',`
There is a kitchen downstairs.|Внизу есть кухня.
The bedroom is upstairs.|Спальня наверху.
There are two chairs.|Там два стула.
The bathroom is small.|Ванная комната маленькая.
Open the window.|Открой окно.
Close the door.|Закрой дверь.
The keys are on the table.|Ключи на столе.
The sofa is comfortable.|Диван удобный.
I need a new lamp.|Мне нужна новая лампа.
`);
add('A1','Словарь','Еда и напитки','Some обычно употребляется в утверждениях, any — в вопросах и отрицаниях; некоторые просьбы с some — исключение.',`
I would like some water.|Я хотел бы воды.
Do you have any milk?|У тебя есть молоко?
I drink coffee in the morning.|Я пью кофе утром.
We eat bread and cheese.|Мы едим хлеб и сыр.
The soup is hot.|Суп горячий.
I need a glass of water.|Мне нужен стакан воды.
She doesn't eat meat.|Она не ест мясо.
May I have the menu?|Можно мне меню?
The food is delicious.|Еда вкусная.
`);
add('A1','Быт','Покупки и цены','How much — сколько (цена или неисчисляемое); how many — сколько (исчисляемое).',`
How much is this?|Сколько это стоит?
Can I pay by card?|Можно оплатить картой?
Do you take cash?|Вы принимаете наличные?
I am just looking.|Я просто смотрю.
Do you have a larger size?|У вас есть размер побольше?
This is too expensive.|Это слишком дорого.
Can I try it on?|Можно это примерить?
Where is the checkout?|Где касса?
I need a receipt.|Мне нужен чек.
`);
add('A1','Быт','Дни и месяцы','Перед днями недели используется on, перед месяцами in, перед точным временем at.',`
Today is Monday.|Сегодня понедельник.
Tomorrow is Tuesday.|Завтра вторник.
See you on Friday.|Увидимся в пятницу.
My birthday is in June.|Мой день рождения в июне.
Winter begins in December.|Зима начинается в декабре.
We meet at six.|Мы встречаемся в шесть.
I work from Monday to Friday.|Я работаю с понедельника по пятницу.
The meeting is next week.|Встреча на следующей неделе.
What day is it today?|Какой сегодня день?
`);
add('A1','Быт','Время и распорядок','At используется с часами: at seven o’clock; in the morning, in the afternoon, at night.',`
What time is it?|Который час?
It is half past seven.|Сейчас половина восьмого.
It is a quarter past eight.|Сейчас четверть девятого.
It is a quarter to nine.|Без четверти девять.
I wake up at seven.|Я просыпаюсь в семь.
I go to bed at ten.|Я ложусь спать в десять.
I have breakfast every day.|Я завтракаю каждый день.
The train leaves at noon.|Поезд отправляется в полдень.
I am usually on time.|Обычно я прихожу вовремя.
`);
add('A1','Грамматика','Множественное число','Обычно добавляют -s/-es: books, buses. Особые формы: child → children; person → people; mouse → mice.',`
I have two books.|У меня две книги.
There are three buses.|Там три автобуса.
The children are playing.|Дети играют.
Five people are waiting.|Пять человек ждут.
These boxes are heavy.|Эти коробки тяжёлые.
Those watches are expensive.|Те часы дорогие.
My feet are cold.|У меня замёрзли ноги.
I can see two mice.|Я вижу двух мышей.
`);
add('A1','Грамматика','Present Simple: утверждение','Present Simple описывает привычки и факты. В 3-м лице ед. числа добавляется -s/-es: he works, she watches.',`
I work every day.|Я работаю каждый день.
She works in a hospital.|Она работает в больнице.
He speaks English.|Он говорит по-английски.
We live near the sea.|Мы живём возле моря.
The shop opens at nine.|Магазин открывается в девять.
My brother studies at university.|Мой брат учится в университете.
The sun rises in the east.|Солнце встаёт на востоке.
I usually walk to work.|Обычно я хожу на работу пешком.
`);
add('A1','Грамматика','Present Simple: вопросы и отрицание','Do/does используется для вопросов и отрицаний. После does глагол без -s: Does she work?',`
Do you like tea?|Ты любишь чай?
Does she live here?|Она живёт здесь?
I do not smoke.|Я не курю.
He does not drive.|Он не водит машину.
Where do you work?|Где ты работаешь?
What does it mean?|Что это значит?
We do not have a car.|У нас нет машины.
Do they understand English?|Они понимают английский?
`);
add('A1','Быт','Город и направления','Excuse me — вежливое привлечение внимания. Go straight, turn left/right — указания направления.',`
Excuse me, where is the station?|Извините, где станция?
Go straight ahead.|Идите прямо.
Turn left at the traffic lights.|Поверните налево на светофоре.
Turn right after the bridge.|Поверните направо после моста.
The bank is next to the pharmacy.|Банк рядом с аптекой.
The museum is opposite the hotel.|Музей напротив гостиницы.
Is it far from here?|Это далеко отсюда?
I am looking for a bus stop.|Я ищу автобусную остановку.
Could you show me on the map?|Не могли бы вы показать на карте?
`);
add('A1','Грамматика','Can и повелительное наклонение','Can + начальная форма глагола: I can swim. Вежливее просьбы: Could you ...?',`
I can swim.|Я умею плавать.
Can you help me?|Ты можешь мне помочь?
She cannot drive.|Она не умеет водить.
Please sit down.|Пожалуйста, садитесь.
Be careful!|Будь осторожен!
Do not touch that.|Не трогай это.
Could you open the window?|Не могли бы вы открыть окно?
I can speak English.|Я умею говорить по-английски.
`);
add('A2','Грамматика','Present Continuous','am/is/are + -ing: действие происходит сейчас или запланировано на ближайшее время. I am working now.',`
I am studying English.|Я изучаю английский.
She is cooking dinner.|Она готовит ужин.
They are waiting outside.|Они ждут снаружи.
Are you listening?|Ты слушаешь?
He is not sleeping.|Он не спит.
We are meeting tomorrow.|Мы встречаемся завтра.
It is raining now.|Сейчас идёт дождь.
What are you doing?|Что ты делаешь?
`);
add('A2','Грамматика','Present Simple или Continuous','I work — привычка; I am working — сейчас. Stative verbs (know, want, like) обычно не ставят в Continuous.',`
I drink coffee every morning.|Я пью кофе каждое утро.
I am drinking coffee now.|Я сейчас пью кофе.
She usually drives to work.|Обычно она ездит на работу на машине.
She is taking the bus today.|Сегодня она едет на автобусе.
I know the answer.|Я знаю ответ.
He wants a new phone.|Он хочет новый телефон.
Do you like this song?|Тебе нравится эта песня?
They are building a new road.|Они строят новую дорогу.
`);
add('A2','Грамматика','Past Simple: was, were','I/he/she/it was; you/we/they were. Вопрос: Were you at home?',`
I was tired yesterday.|Вчера я устал.
We were at the cinema.|Мы были в кино.
She was late for work.|Она опоздала на работу.
They were not ready.|Они не были готовы.
Were you at home?|Ты был дома?
It was a difficult day.|Это был трудный день.
Where were they?|Где они были?
I was born in Ukraine.|Я родился в Украине.
`);
add('A2','Грамматика','Past Simple: правильные глаголы','В прошлом времени правильные глаголы получают -ed: worked, played. В вопросах и отрицаниях did + глагол без -ed.',`
I worked yesterday.|Я работал вчера.
She visited her parents.|Она навестила родителей.
We watched a film.|Мы посмотрели фильм.
He didn't call me.|Он мне не позвонил.
Did you finish the task?|Ты закончил задание?
They arrived on time.|Они прибыли вовремя.
I studied English last year.|Я учил английский в прошлом году.
We moved to a new house.|Мы переехали в новый дом.
`);
add('A2','Грамматика','Неправильные глаголы I','Неправильные глаголы запоминают по трём формам: go–went–gone; see–saw–seen.',`
I went to the shop.|Я сходил в магазин.
She saw a good film.|Она увидела хороший фильм.
We bought a new car.|Мы купили новую машину.
He wrote a letter.|Он написал письмо.
I ate breakfast early.|Я позавтракал рано.
They came home late.|Они пришли домой поздно.
She took my hand.|Она взяла меня за руку.
I made a mistake.|Я допустил ошибку.
`);
add('A2','Грамматика','Неправильные глаголы II','Past Simple используется с указанным законченным временем: yesterday, last week, in 2020.',`
I found my keys.|Я нашёл ключи.
He broke the glass.|Он разбил стакан.
She chose the blue dress.|Она выбрала синее платье.
We drove all night.|Мы ехали всю ночь.
They gave me a present.|Они подарили мне подарок.
I heard a strange noise.|Я услышал странный шум.
He left early.|Он ушёл рано.
She told me the truth.|Она сказала мне правду.
`);
add('A2','Грамматика','Future: will','Will + основная форма — прогноз, обещание или решение в момент речи.',`
I will call you tomorrow.|Я позвоню тебе завтра.
It will rain later.|Позже пойдёт дождь.
I will help you.|Я помогу тебе.
We will be there at six.|Мы будем там в шесть.
She will not agree.|Она не согласится.
Will you join us?|Ты к нам присоединишься?
I think it will work.|Думаю, это сработает.
I will send the email.|Я отправлю письмо.
`);
add('A2','Грамматика','Going to и планы','Be going to + глагол — намерение или прогноз по очевидным признакам.',`
I am going to learn English.|Я собираюсь выучить английский.
She is going to buy a car.|Она собирается купить машину.
We are going to travel in June.|Мы собираемся путешествовать в июне.
Look at those clouds! It is going to rain.|Посмотри на облака! Сейчас пойдёт дождь.
Are you going to call him?|Ты собираешься ему позвонить?
I am not going to give up.|Я не собираюсь сдаваться.
They are going to move next year.|Они собираются переехать в следующем году.
`);
add('A2','Грамматика','Сравнительные степени','Short: cheaper, bigger; long: more interesting. Исключения: good–better–best, bad–worse–worst.',`
This car is cheaper.|Эта машина дешевле.
My house is bigger than yours.|Мой дом больше твоего.
Today is colder than yesterday.|Сегодня холоднее, чем вчера.
This book is more interesting.|Эта книга интереснее.
She is the best student.|Она лучшая ученица.
This is the worst day.|Это худший день.
The train is faster than the bus.|Поезд быстрее автобуса.
This is the most expensive option.|Это самый дорогой вариант.
`);
add('A2','Грамматика','Much, many, few, little','Many/few + исчисляемые: many cars. Much/little + неисчисляемые: much water.',`
How many people are coming?|Сколько человек придёт?
How much time do we have?|Сколько у нас времени?
I have a few questions.|У меня есть несколько вопросов.
There is little water left.|Осталось мало воды.
She has too many bags.|У неё слишком много сумок.
We don't have much money.|У нас не так много денег.
Can I have some sugar?|Можно мне сахара?
There are a lot of cars.|Там много машин.
`);
add('A2','Грамматика','Предлоги места и движения','In — внутри; on — на поверхности; at — в точке; to — направление; from — источник.',`
The phone is in the bag.|Телефон в сумке.
The picture is on the wall.|Картина на стене.
I am at the station.|Я на станции.
She is going to work.|Она идёт на работу.
He comes from London.|Он родом из Лондона.
The cat is under the table.|Кот под столом.
The park is behind the school.|Парк за школой.
Walk across the street.|Перейдите через улицу.
`);
add('A2','Грамматика','Must, have to, should','Must — сильная обязанность/личная необходимость. Have to — внешнее требование. Should — совет.',`
You must stop here.|Ты должен остановиться здесь.
I have to work tomorrow.|Мне нужно работать завтра.
You should see a doctor.|Тебе следует обратиться к врачу.
You must not park here.|Здесь запрещено парковаться.
You don't have to come.|Тебе необязательно приходить.
Should I call her?|Мне стоит ей позвонить?
We have to be careful.|Нам нужно быть осторожными.
You should drink more water.|Тебе стоит пить больше воды.
`);
add('A2','Быт','Путешествия и транспорт','Could I ...? — вежливый запрос; I would like ... — желание.',`
I would like a return ticket.|Мне нужен билет туда и обратно.
What platform does the train leave from?|С какой платформы отправляется поезд?
My flight has been delayed.|Мой рейс задержали.
Where is the baggage claim?|Где выдача багажа?
Could I have a window seat?|Можно место у окна?
I have a reservation.|У меня есть бронирование.
How long does the journey take?|Сколько длится поездка?
Is breakfast included?|Завтрак включён?
I missed the last bus.|Я опоздал на последний автобус.
`);
add('A2','Быт','Врач и здоровье','I have a headache — у меня болит голова. I feel + adjective — я чувствую себя...',`
I have a headache.|У меня болит голова.
I feel dizzy.|У меня кружится голова.
I need an appointment.|Мне нужно записаться на приём.
Where is the nearest pharmacy?|Где ближайшая аптека?
I have a fever.|У меня температура.
It hurts when I walk.|Больно, когда я хожу.
I am allergic to nuts.|У меня аллергия на орехи.
Take this medicine twice a day.|Принимайте это лекарство два раза в день.
Could you call an ambulance?|Не могли бы вы вызвать скорую помощь?
`);
add('A2','Быт','Работа и встречи','At work — на работе; on time — вовремя; in time — успеть к определённому моменту.',`
I have a meeting at nine.|У меня встреча в девять.
Could you send me the file?|Не могли бы вы прислать файл?
I will check the details.|Я проверю детали.
The deadline is Friday.|Срок сдачи — пятница.
We need to discuss the budget.|Нам нужно обсудить бюджет.
I work remotely.|Я работаю удалённо.
Please confirm your attendance.|Пожалуйста, подтвердите участие.
Let's reschedule the meeting.|Давайте перенесём встречу.
I agree with your proposal.|Я согласен с вашим предложением.
`);
add('B1','Грамматика','Present Perfect','Have/has + V3 — опыт, результат и связь с настоящим. Не используется с yesterday или конкретным прошлым временем.',`
I have finished my work.|Я закончил работу.
She has already left.|Она уже ушла.
Have you ever been to London?|Ты когда-нибудь был в Лондоне?
We have never met.|Мы никогда не встречались.
I have lost my keys.|Я потерял ключи.
He has lived here for five years.|Он живёт здесь пять лет.
They have just arrived.|Они только что приехали.
I haven't seen that film yet.|Я ещё не видел этот фильм.
`);
add('B1','Грамматика','Present Perfect или Past Simple','Past Simple — законченный момент в прошлом. Present Perfect — результат сейчас или период до настоящего.',`
I saw her yesterday.|Я видел её вчера.
I have seen her before.|Я видел её раньше.
She went to Paris in 2022.|Она ездила в Париж в 2022 году.
She has been to Paris twice.|Она дважды бывала в Париже.
Did you finish it yesterday?|Ты закончил это вчера?
Have you finished it yet?|Ты уже закончил?
I lost my phone last week.|Я потерял телефон на прошлой неделе.
I have lost my phone.|Я потерял телефон (и сейчас его нет).
`);
add('B1','Грамматика','Past Continuous','Was/were + -ing — действие в процессе в определённый момент прошлого. Часто сочетается с when и while.',`
I was reading when you called.|Я читал, когда ты позвонил.
They were working all evening.|Они работали весь вечер.
She was sleeping at midnight.|Она спала в полночь.
What were you doing at six?|Что ты делал в шесть?
It was raining when we left.|Когда мы вышли, шёл дождь.
He wasn't listening.|Он не слушал.
We were having dinner.|Мы ужинали.
While I was driving, she called.|Пока я ехал за рулём, она позвонила.
`);
add('B1','Грамматика','First Conditional','If + Present Simple, will + глагол — реальное условие в будущем. После if не ставят will в стандартном условном придаточном.',`
If it rains, we will stay home.|Если пойдёт дождь, мы останемся дома.
If you study, you will improve.|Если будешь заниматься, станешь лучше.
I will call you if I am late.|Я позвоню, если опоздаю.
If she comes, we will start.|Если она придёт, мы начнём.
If you need help, ask me.|Если нужна помощь, спроси меня.
We will miss the train if we leave late.|Мы опоздаем на поезд, если выйдем поздно.
If I have time, I will visit you.|Если у меня будет время, я тебя навещу.
`);
add('B1','Грамматика','Second Conditional','If + Past Simple, would + глагол — гипотетическая ситуация сейчас или в будущем.',`
If I had more time, I would travel.|Если бы у меня было больше времени, я бы путешествовал.
If I were you, I would wait.|На твоём месте я бы подождал.
She would buy it if it were cheaper.|Она бы купила это, если бы оно было дешевле.
What would you do if you won?|Что бы ты сделал, если бы выиграл?
If we lived closer, we would meet often.|Если бы мы жили ближе, мы бы часто встречались.
I would learn Spanish if I had time.|Я бы учил испанский, если бы было время.
`);
add('B1','Грамматика','Страдательный залог','Be + V3: The report was written. Важнее объект действия, а не исполнитель.',`
The letter was sent yesterday.|Письмо отправили вчера.
English is spoken worldwide.|На английском говорят во всём мире.
The road is being repaired.|Дорогу сейчас ремонтируют.
The work has been completed.|Работа завершена.
This product is made in Germany.|Этот продукт сделан в Германии.
The window was broken.|Окно было разбито.
The rules must be followed.|Правила необходимо соблюдать.
`);
add('B1','Грамматика','Фразовые глаголы I','Phrasal verb — сочетание глагола с частицей. Значение не всегда выводится из отдельных слов.',`
Turn off the light.|Выключи свет.
Turn on the computer.|Включи компьютер.
I wake up early.|Я просыпаюсь рано.
Please fill in this form.|Пожалуйста, заполните эту форму.
I am looking for my keys.|Я ищу свои ключи.
Don't give up.|Не сдавайся.
We need to find out why.|Нам нужно выяснить почему.
He picked up the phone.|Он поднял телефонную трубку.
`);
add('B1','Грамматика','Относительные предложения','Who — люди; which — предметы; that — люди и предметы в определительных придаточных.',`
The man who called is my boss.|Мужчина, который звонил, — мой начальник.
This is the book that I bought.|Это книга, которую я купил.
The house which we saw was old.|Дом, который мы видели, был старым.
She knows a person who can help.|Она знает человека, который может помочь.
That's the place where we met.|Это место, где мы встретились.
I remember the day when we arrived.|Я помню день, когда мы приехали.
The laptop that I use is fast.|Ноутбук, которым я пользуюсь, быстрый.
`);
add('B1','Грамматика','Gerund и infinitive','Enjoy + -ing; want + to V; stop doing (прекратить) отличается от stop to do (остановиться, чтобы сделать).',`
I enjoy reading.|Я люблю читать.
She wants to travel.|Она хочет путешествовать.
We decided to leave early.|Мы решили уйти пораньше.
He avoided answering.|Он избегал ответа.
I stopped smoking.|Я бросил курить.
I stopped to get coffee.|Я остановился, чтобы купить кофе.
They suggested going by train.|Они предложили поехать поездом.
I hope to see you soon.|Надеюсь скоро тебя увидеть.
`);
add('B1','Быт','Обсуждение проблем','Уточняйте проблему и ожидаемое решение: The problem is...; What do you suggest?',`
The problem is more serious than expected.|Проблема серьёзнее, чем ожидалось.
Could you explain what happened?|Не могли бы вы объяснить, что произошло?
We need to find a solution.|Нам нужно найти решение.
I see your point.|Я понимаю твою точку зрения.
What do you suggest?|Что ты предлагаешь?
Let's compare the options.|Давайте сравним варианты.
I am not sure I agree.|Не уверен, что согласен.
That sounds reasonable.|Это звучит разумно.
`);
add('B1','Быт','Деловая переписка','В деловых письмах используют нейтральные и вежливые формулы. I look forward to + -ing.',`
Thank you for your message.|Спасибо за ваше сообщение.
Please find the document attached.|Документ прилагается.
I look forward to hearing from you.|С нетерпением жду вашего ответа.
Could you clarify the deadline?|Не могли бы вы уточнить срок?
I apologise for the delay.|Приношу извинения за задержку.
Please let me know if you have questions.|Пожалуйста, сообщите, если возникнут вопросы.
We appreciate your feedback.|Мы ценим ваш отзыв.
I will get back to you tomorrow.|Я отвечу вам завтра.
`);
add('B2','Грамматика','Past Perfect','Had + V3 — действие, которое произошло раньше другого момента в прошлом.',`
I had finished before she arrived.|Я закончил до её прихода.
They had already left when I called.|Они уже ушли, когда я позвонил.
She had never flown before.|Раньше она никогда не летала.
By noon, we had completed the task.|К полудню мы выполнили задачу.
He realised he had made a mistake.|Он понял, что совершил ошибку.
I hadn't seen the message.|Я не видел сообщение.
We had lived there for ten years.|Мы прожили там десять лет.
`);
add('B2','Грамматика','Reported Speech','В косвенной речи после прошедшего глагола сообщения часто сдвигается время: am → was; will → would.',`
She said that she was tired.|Она сказала, что устала.
He told me he would call.|Он сказал мне, что позвонит.
They said they had finished.|Они сказали, что закончили.
She asked where I lived.|Она спросила, где я живу.
He asked whether I was ready.|Он спросил, готов ли я.
I told her I couldn't come.|Я сказал ей, что не смогу прийти.
They explained that the train was late.|Они объяснили, что поезд опаздывает.
`);
add('B2','Грамматика','Модальные предположения','Must have + V3 — высокая уверенность о прошлом; might have — возможность; cannot have — логическая невозможность.',`
He must have forgotten.|Наверное, он забыл.
She might have missed the bus.|Возможно, она опоздала на автобус.
They can't have finished already.|Не может быть, чтобы они уже закончили.
You should have told me.|Тебе следовало мне сказать.
I could have helped you.|Я мог бы тебе помочь.
We might be wrong.|Возможно, мы ошибаемся.
He must be tired.|Он, должно быть, устал.
`);
add('B2','Грамматика','Used to и be used to','Used to + V — прежняя привычка; be used to + -ing/сущ. — привыкнуть к чему-то.',`
I used to live in Kyiv.|Раньше я жил в Киеве.
She used to smoke.|Раньше она курила.
Did you use to work here?|Ты раньше здесь работал?
I am used to waking up early.|Я привык рано вставать.
He is getting used to the weather.|Он привыкает к погоде.
We are used to working remotely.|Мы привыкли работать удалённо.
I didn't use to like coffee.|Раньше я не любил кофе.
`);
add('B2','Грамматика','Third Conditional','If + had + V3, would have + V3 — нереальная ситуация в прошлом.',`
If I had known, I would have called.|Если бы я знал, я бы позвонил.
She would have passed if she had studied.|Она бы сдала, если бы занималась.
If we had left earlier, we wouldn't have missed it.|Если бы мы вышли раньше, мы бы не опоздали.
I would have helped if you had asked.|Я бы помог, если бы ты попросил.
If he had listened, he would have understood.|Если бы он слушал, он бы понял.
We could have won if we had tried harder.|Мы могли бы победить, если бы старались сильнее.
`);
add('B2','Грамматика','Фразовые глаголы II','Run into — случайно встретить; put off — откладывать; carry out — выполнять; bring up — поднимать тему.',`
I ran into an old friend.|Я случайно встретил старого друга.
They put off the meeting.|Они отложили встречу.
We carried out the inspection.|Мы провели проверку.
She brought up an important issue.|Она подняла важный вопрос.
I will look into the problem.|Я изучу проблему.
He came up with a good idea.|Он придумал хорошую идею.
We ran out of time.|У нас закончилось время.
Please keep me updated.|Пожалуйста, держите меня в курсе.
`);
add('B2','Быт','Переговоры и аргументы','Для вежливого несогласия: I see your point, however... Для уточнения: Could you elaborate?',`
I understand your concerns.|Я понимаю ваши опасения.
Could you elaborate on that?|Не могли бы вы рассказать подробнее?
We need to consider the risks.|Нам нужно учитывать риски.
From my perspective, this is reasonable.|С моей точки зрения, это разумно.
The evidence suggests otherwise.|Данные говорят об обратном.
Let's reach a compromise.|Давайте найдём компромисс.
The proposal has several advantages.|У предложения есть несколько преимуществ.
What are the alternatives?|Каковы альтернативы?
`);
add('B2','Быт','Технологии и данные','Уточняйте technical context: backup — резервная копия; outage — сбой; deployment — развёртывание.',`
The server is temporarily unavailable.|Сервер временно недоступен.
We need to back up the database.|Нужно создать резервную копию базы данных.
The update fixed the issue.|Обновление устранило проблему.
The application works offline.|Приложение работает без интернета.
The data is encrypted.|Данные зашифрованы.
Please check the network connection.|Пожалуйста, проверьте подключение к сети.
The deployment was successful.|Развёртывание прошло успешно.
We should improve performance.|Нам стоит улучшить производительность.
`);
add('C1','Продвинутый','Нюансы и оговорки','Apparently — по-видимому, supposedly — якобы, arguably — можно утверждать; маркеры показывают степень уверенности.',`
Apparently, the plan has changed.|По-видимому, план изменился.
The results are somewhat surprising.|Результаты несколько удивительны.
This is arguably the best approach.|Можно утверждать, что это лучший подход.
The claim has yet to be verified.|Это утверждение ещё предстоит проверить.
There is little evidence to support it.|Доказательств в пользу этого мало.
The decision was made reluctantly.|Решение приняли неохотно.
I would hesitate to draw that conclusion.|Я бы не спешил делать такой вывод.
The outcome remains uncertain.|Исход остаётся неопределённым.
`);
add('C1','Продвинутый','Официальный и деловой стиль','В формальной речи: with regard to; in accordance with; subject to; notwithstanding.',`
With regard to your request, we can confirm the details.|Что касается вашего запроса, мы можем подтвердить детали.
The agreement is subject to approval.|Соглашение подлежит утверждению.
We will proceed in accordance with the policy.|Мы будем действовать в соответствии с политикой.
Please acknowledge receipt of this message.|Пожалуйста, подтвердите получение сообщения.
The findings warrant further investigation.|Результаты требуют дальнейшего изучения.
The company reserves the right to amend the terms.|Компания оставляет за собой право изменить условия.
We appreciate your continued cooperation.|Мы благодарим вас за дальнейшее сотрудничество.
`);
add('C1','Продвинутый','Идиомы и разговорные оттенки','Идиомы изучайте как смысловые единицы. Их дословный перевод часто вводит в заблуждение.',`
It's not my cup of tea.|Это не в моём вкусе.
Let's call it a day.|На сегодня хватит.
We are on the same page.|Мы одинаково понимаем ситуацию.
I'll keep an eye on it.|Я буду за этим следить.
That rings a bell.|Что-то знакомое.
He went the extra mile.|Он приложил дополнительные усилия.
Let's get straight to the point.|Давайте сразу к делу.
That is easier said than done.|Легче сказать, чем сделать.
`);
add('C1','Продвинутый','Британский и американский английский','Правописание и лексика различаются: colour/color, organise/organize, lift/elevator. Оба варианта считаются правильными.',`
The colour of this car is blue.|Цвет этой машины синий.
The color of this car is blue.|Цвет этой машины синий.
Take the lift to the third floor.|Поднимитесь на лифте на третий этаж.
Take the elevator to the third floor.|Поднимитесь на лифте на третий этаж.
I live in a flat.|Я живу в квартире.
I live in an apartment.|Я живу в квартире.
The queue is long.|Очередь длинная.
The line is long.|Очередь длинная.
We are going on holiday.|Мы едем в отпуск.
We are going on vacation.|Мы едем в отпуск.
`);
add('A1','Практика','Готовые фразы для каждого дня','Запоминайте целые словосочетания: не только слово, но и типичную конструкцию. Could I ...? звучит вежливее, чем прямой приказ.',`
Could I ask a question?|Можно задать вопрос?
I would like a cup of tea.|Я хотел бы чашку чая.
What does this word mean?|Что означает это слово?
Could you say that again?|Не могли бы вы повторить?
I am not sure.|Я не уверен.
I have no idea.|Я понятия не имею.
Let me think.|Дайте подумать.
That sounds good.|Звучит хорошо.
I need some help.|Мне нужна помощь.
It depends.|Это зависит от обстоятельств.
`);
add('A1','Практика','Шаблоны вопросов','Стройте свои вопросы по образцам. В Present Simple в большинстве вопросов нужен do или does. После does — глагол без окончания -s.',`
Do you live near here?|Ты живёшь неподалёку?
Does she work on Sundays?|Она работает по воскресеньям?
What time is it?|Который час?
Where can I buy a ticket?|Где можно купить билет?
How often do you exercise?|Как часто ты тренируешься?
Why are you late?|Почему ты опоздал?
How long does it take?|Сколько времени это занимает?
Can you help me?|Ты можешь мне помочь?
Are you ready?|Ты готов?
What happened?|Что случилось?
`);
add('A2','Слушание','Как переспрашивать на слух','Когда непонятно, не молчите: попросите повторить, уточните цифру, название или смысл. Эти конструкции особенно важны при общении с незнакомыми людьми.',`
Sorry, I didn't catch that.|Извините, я не расслышал.
Could you speak a little slower?|Не могли бы вы говорить чуть медленнее?
Did you say fifteen or fifty?|Вы сказали пятнадцать или пятьдесят?
How do you spell your surname?|Как пишется ваша фамилия по буквам?
Do you mean this one?|Вы имеете в виду вот этот?
Let me make sure I understood.|Давайте я проверю, правильно ли понял.
Could you give me an example?|Не могли бы вы привести пример?
What do you mean by that?|Что вы под этим подразумеваете?
So we meet at nine, right?|Итак, мы встречаемся в девять, верно?
Could you write it down?|Не могли бы вы это записать?
`);
add('A2','Грамматика','Make и do','Do — выполнять действие, работу или задачу; make — создавать, производить результат. Устойчивые сочетания нужно запоминать вместе.',`
I need to make a decision.|Мне нужно принять решение.
Can you do me a favour?|Можешь оказать мне услугу?
She does the shopping on Fridays.|Она ходит за покупками по пятницам.
Let's make a plan.|Давайте составим план.
I made a mistake.|Я допустил ошибку.
Do your best.|Сделай всё возможное.
They make a lot of noise.|Они сильно шумят.
I have to do my homework.|Мне нужно сделать домашнее задание.
We made progress today.|Сегодня мы добились прогресса.
Please do the dishes.|Пожалуйста, помой посуду.
`);
add('A2','Грамматика','Say, tell, speak, talk','Say — произнести слова; tell — сообщить кому-то; speak — говорить на языке или формально; talk — разговаривать.',`
Please tell me the truth.|Пожалуйста, скажи мне правду.
What did you say?|Что ты сказал?
She speaks English fluently.|Она свободно говорит по-английски.
We need to talk.|Нам нужно поговорить.
He told me a story.|Он рассказал мне историю.
Could I speak to the manager?|Можно поговорить с менеджером?
I said hello to him.|Я с ним поздоровался.
They talked for an hour.|Они разговаривали целый час.
Tell her I called.|Передай ей, что я звонил.
What are you talking about?|О чём ты говоришь?
`);
add('A2','Практика','Встречи и планы','Для договорённостей полезны are we still on?, does ... work for you?, could we move it?. Эти фразы лучше учить в контексте.',`
Are we still on for tomorrow?|Наша встреча на завтра остаётся в силе?
Does three o'clock work for you?|Тебе удобно в три часа?
Could we move it to Friday?|Можем перенести это на пятницу?
I will be there on time.|Я буду там вовремя.
Sorry, I am running late.|Извини, я опаздываю.
Let's meet outside the station.|Давай встретимся у входа на вокзал.
I need to reschedule our meeting.|Мне нужно перенести нашу встречу.
I am free after lunch.|Я свободен после обеда.
Please let me know.|Пожалуйста, дай мне знать.
See you at half past five.|Увидимся в половине шестого.
`);
add('B1','Грамматика','Present Perfect или Past Simple','Past Simple — завершённое действие в определённое время. Present Perfect — опыт или результат, важный сейчас. С конкретным yesterday обычно употребляют Past Simple.',`
I have lost my keys.|Я потерял ключи.
I lost my keys yesterday.|Я потерял ключи вчера.
Have you ever been to London?|Ты когда-нибудь бывал в Лондоне?
I went there last summer.|Я ездил туда прошлым летом.
She has just arrived.|Она только что приехала.
He called me an hour ago.|Он позвонил мне час назад.
We have lived here since 2022.|Мы живём здесь с 2022 года.
We moved here in 2022.|Мы переехали сюда в 2022 году.
Have you finished yet?|Ты уже закончил?
I finished it this morning.|Я закончил это сегодня утром.
`);
add('B1','Грамматика','Used to и be used to','Used to + глагол — прежняя привычка. Be used to + существительное или -ing — быть привычным к чему-либо.',`
I used to live in a small town.|Раньше я жил в маленьком городе.
She used to smoke.|Раньше она курила.
I didn't use to drink coffee.|Раньше я не пил кофе.
Did you use to play football?|Ты раньше играл в футбол?
I am used to the cold.|Я привык к холоду.
He is used to working at night.|Он привык работать ночью.
It took time to get used to driving here.|Понадобилось время, чтобы привыкнуть водить здесь.
We used to meet every Sunday.|Раньше мы встречались каждое воскресенье.
I am not used to this schedule.|Я не привык к этому расписанию.
You will get used to it.|Ты к этому привыкнешь.
`);
add('B1','Разговор','Фразовые глаголы с get','Фразовый глагол часто меняет значение в зависимости от частицы. Учите связку с примером, а не отдельную пару слов.',`
What time do you get up?|Во сколько ты встаёшь?
I get along with my colleagues.|Я хорошо лажу с коллегами.
Let's get started.|Давайте начнём.
I got back late yesterday.|Я вчера поздно вернулся.
We need to get rid of these boxes.|Нам нужно избавиться от этих коробок.
He got over the flu.|Он оправился после гриппа.
Could you get in touch with her?|Можешь связаться с ней?
I can't get through to the office.|Я не могу дозвониться в офис.
We got off at the next stop.|Мы вышли на следующей остановке.
Don't give up; you'll get there.|Не сдавайся, у тебя получится.
`);
add('B1','Разговор','Фразовые глаголы с take и put','Устойчивые глаголы с предлогами и частицами встречаются в разговорной речи чаще, чем книжные синонимы.',`
Please take off your shoes.|Пожалуйста, сними обувь.
The plane took off on time.|Самолёт взлетел вовремя.
I can take care of it.|Я могу об этом позаботиться.
We need to put off the meeting.|Нам нужно отложить встречу.
Put your phone away, please.|Убери, пожалуйста, телефон.
She put on her coat.|Она надела пальто.
He took over the project.|Он возглавил проект.
It took me a while to figure it out.|Мне понадобилось некоторое время, чтобы разобраться.
Don't put up with rude behaviour.|Не мирись с грубым поведением.
I will take a look at it.|Я посмотрю на это.
`);
add('B1','Работа','Деловые письма и просьбы','Вежливые письма часто используют could, would, I was wondering и мягкие формулировки. Точный русский перевод может отличаться по тону.',`
I am writing regarding your order.|Пишу по поводу вашего заказа.
Could you send me the updated file?|Не могли бы вы прислать обновлённый файл?
Please find the invoice attached.|Счёт приложен к письму.
I look forward to your reply.|С нетерпением жду вашего ответа.
Thank you for getting back to me.|Спасибо, что ответили мне.
Could we discuss this tomorrow?|Можем обсудить это завтра?
I will get back to you shortly.|Я скоро вам отвечу.
Please let me know if anything is unclear.|Дайте знать, если что-либо непонятно.
I appreciate your help.|Я ценю вашу помощь.
I am available at your convenience.|Я свободен в удобное для вас время.
`);
add('B2','Точность речи','Make, let, have и get somebody to do','Make somebody do — заставить; let somebody do — позволить; have somebody do — поручить; get somebody to do — убедить или организовать.',`
They made us wait outside.|Они заставили нас ждать снаружи.
Let me explain.|Позвольте мне объяснить.
I had the mechanic check the engine.|Я попросил механика проверить двигатель.
She got him to apologise.|Она добилась того, чтобы он извинился.
My boss let me leave early.|Начальник разрешил мне уйти раньше.
The news made me think.|Эта новость заставила меня задуматься.
I will have someone call you.|Я попрошу кого-нибудь вам позвонить.
Can you get them to send it today?|Можешь добиться, чтобы они отправили это сегодня?
Let us know what you decide.|Сообщите нам, что вы решите.
They had the room painted.|Они организовали покраску комнаты.
`);
add('B2','Понимание смысла','Вежливое несогласие и уточнения','В реальном разговоре важно распознавать не только слова, но и намерение: частичное согласие, осторожное возражение и компромисс.',`
I see your point, but I disagree.|Я понимаю вашу точку зрения, но не согласен.
That may be true, however we need evidence.|Возможно, это так, однако нужны доказательства.
I am not entirely convinced.|Я не полностью убеждён.
Could you elaborate on that?|Не могли бы вы раскрыть эту мысль подробнее?
We seem to be talking at cross purposes.|Кажется, мы говорим о разном.
I would put it differently.|Я бы сформулировал это иначе.
We can agree to disagree.|Мы можем остаться при разных мнениях.
From my perspective, the risk is too high.|С моей точки зрения, риск слишком высок.
What would be a fair compromise?|Какой компромисс был бы справедливым?
I appreciate your perspective.|Я ценю вашу точку зрения.
`);
add('B2','Грамматика','Будущее в прошлом и косвенная речь','В косвенной речи времена часто сдвигаются назад: will → would; am/is → was; have done → had done. Сдвиг зависит от контекста.',`
She said she would call later.|Она сказала, что позвонит позже.
He told me he was tired.|Он сказал мне, что устал.
They said they had finished the work.|Они сказали, что закончили работу.
I thought it would be easier.|Я думал, что будет легче.
She asked whether I could help.|Она спросила, могу ли я помочь.
He said he had never been there.|Он сказал, что никогда там не был.
They promised they would arrive early.|Они пообещали приехать рано.
I wondered whether she was coming.|Мне было интересно, придёт ли она.
He asked me what I wanted.|Он спросил меня, чего я хочу.
She said the documents were ready.|Она сказала, что документы готовы.
`);
add('C1','Нюансы','Убедительная аргументация','Для аргументации используйте concessive clauses: although, even though, whereas, nevertheless, provided that. Они точнее простых but и because.',`
Although the plan is ambitious, it is feasible.|Хотя план амбициозный, он осуществим.
The evidence is limited; nevertheless, the trend is clear.|Доказательства ограничены, тем не менее тенденция очевидна.
Provided that we act quickly, we can avoid delays.|При условии, что мы действуем быстро, мы сможем избежать задержек.
Whereas the first option is cheaper, the second is more reliable.|Хотя первый вариант дешевле, второй надёжнее.
Even though we disagree, we can cooperate.|Несмотря на разногласия, мы можем сотрудничать.
On balance, the benefits outweigh the risks.|В целом преимущества перевешивают риски.
It is worth considering the long-term implications.|Стоит рассмотреть долгосрочные последствия.
This conclusion rests on several assumptions.|Этот вывод основан на нескольких предположениях.
There is little evidence to support that claim.|В подтверждение этого утверждения мало доказательств.
We should distinguish correlation from causation.|Нужно отличать корреляцию от причинно-следственной связи.
`);

add('A1','Грамматика','Притяжательный апостроф','Форма с апострофом обозначает принадлежность: Anna’s book; при множественном числе с -s апостроф ставится после s: my parents’ house.',`
This is Anna's book.|Это книга Анны.
Where is John's phone?|Где телефон Джона?
My brother's car is red.|Машина моего брата красная.
The children's toys are here.|Игрушки детей здесь.
My parents' house is big.|Дом моих родителей большой.
The dog's bowl is empty.|Миска собаки пустая.
I know my friend's address.|Я знаю адрес своего друга.
The teacher's name is Emma.|Учителя зовут Эмма.
`);
add('A1','Грамматика','Исчисляемые и неисчисляемые слова','С исчисляемыми существительными возможны a/an и множественное число: an apple, two apples. Для неисчисляемых обычно используют some, much, a piece of.',`
I need an apple.|Мне нужно яблоко.
We have two apples.|У нас два яблока.
I need some advice.|Мне нужен совет.
This is useful information.|Это полезная информация.
Could I have a glass of water?|Можно мне стакан воды?
There is some rice in the bowl.|В миске есть немного риса.
How much money do you have?|Сколько у тебя денег?
I bought three pieces of furniture.|Я купил три предмета мебели.
`);
add('A1','Разговор','Вежливые просьбы','Please смягчает просьбу. Could you ...? и Would you mind ...? звучат вежливее, чем прямое повелительное наклонение.',`
Please open the window.|Пожалуйста, откройте окно.
Could you help me, please?|Не могли бы вы мне помочь?
Can I sit here?|Можно мне здесь сесть?
Could I have a glass of water?|Можно мне стакан воды?
Would you mind closing the door?|Не могли бы вы закрыть дверь?
Thank you for your help.|Спасибо за вашу помощь.
Sorry, could you say that again?|Извините, не могли бы вы повторить?
No problem at all.|Никаких проблем.
`);
add('A2','Грамматика','Too и enough','Too + прилагательное означает «слишком»; прилагательное + enough означает «достаточно». Enough ставится перед существительным.',`
It is too cold to swim.|Слишком холодно, чтобы плавать.
This box is too heavy.|Эта коробка слишком тяжёлая.
The room is big enough.|Комната достаточно большая.
I am not old enough to drive.|Я недостаточно взрослый, чтобы водить машину.
Do we have enough time?|У нас достаточно времени?
There isn't enough water.|Воды недостаточно.
He speaks clearly enough.|Он говорит достаточно ясно.
The price is too high for us.|Цена для нас слишком высокая.
`);
add('A2','Грамматика','One и ones вместо существительного','One заменяет исчисляемое существительное в единственном числе, ones — во множественном; это позволяет избежать повторения слова.',`
I want the blue one.|Я хочу синий (предмет).
Which one is yours?|Который из них твой?
The small one is cheaper.|Маленький дешевле.
These ones are comfortable.|Эти удобные.
I don't like the red ones.|Мне не нравятся красные.
Can I try on this one?|Можно мне примерить этот?
The new ones are much better.|Новые намного лучше.
Which ones would you recommend?|Какие из них вы бы посоветовали?
`);
add('A2','Разговор','Телефонные сообщения','При телефонном разговоре представляются: This is Alex speaking. Просьбу соединить выражают May I speak to ...?',`
Hello, this is Alex speaking.|Здравствуйте, это Алекс.
May I speak to Emma, please?|Можно поговорить с Эммой?
She is not available right now.|Сейчас она недоступна.
Could I leave a message?|Можно оставить сообщение?
Please call me back tomorrow.|Пожалуйста, перезвоните мне завтра.
Can you hear me clearly?|Вы хорошо меня слышите?
The connection is breaking up.|Связь прерывается.
I'll send you a text message.|Я отправлю тебе сообщение.
`);
add('B1','Грамматика','Zero Conditional','Нулевое условное предложение описывает общую закономерность: If + Present Simple, Present Simple.',`
If you heat ice, it melts.|Если нагреть лёд, он тает.
If it rains, the ground gets wet.|Если идёт дождь, земля становится мокрой.
If I am tired, I go to bed early.|Если я устаю, я рано ложусь спать.
Water boils if you heat it enough.|Вода закипает, если её достаточно нагреть.
If people exercise regularly, they often feel better.|Если люди регулярно занимаются спортом, они часто чувствуют себя лучше.
If you press this button, the machine stops.|Если нажать эту кнопку, машина остановится.
If the battery is empty, the device won't start.|Если батарея разряжена, устройство не запустится.
If you don't save the file, you lose your changes.|Если не сохранить файл, изменения пропадут.
`);
add('B1','Грамматика','Both, either и neither','Both — оба; either — любой из двух; neither — ни один из двух. После neither of чаще ставят глагол в единственном числе.',`
Both answers are correct.|Оба ответа правильные.
Either option is fine.|Любой из двух вариантов подойдёт.
Neither answer is correct.|Ни один ответ не правильный.
I like both tea and coffee.|Мне нравятся и чай, и кофе.
You can either stay or leave.|Ты можешь либо остаться, либо уйти.
Neither of these keys works.|Ни один из этих ключей не подходит.
She speaks both English and French.|Она говорит и по-английски, и по-французски.
I don't want either of them.|Я не хочу ни один из них.
`);
add('B1','Разговор','Объяснение причин и результатов','Because объясняет причину, so — результат, although — контраст. Despite требует существительного или формы -ing.',`
We stayed home because it was raining.|Мы остались дома, потому что шёл дождь.
It was raining, so we stayed home.|Шёл дождь, поэтому мы остались дома.
Although I was tired, I finished the job.|Хотя я устал, я закончил работу.
Despite the rain, we went for a walk.|Несмотря на дождь, мы пошли гулять.
As a result, sales increased.|В результате продажи выросли.
The meeting was postponed due to bad weather.|Встречу перенесли из-за плохой погоды.
I made a note so that I wouldn't forget.|Я сделал заметку, чтобы не забыть.
Even though it was difficult, we succeeded.|Хотя это было трудно, мы справились.
`);
add('B2','Грамматика','Modal Perfect: мог, должен был','Must have + V3 выражает уверенный вывод о прошлом, might have — предположение, should have — сожаление или критику.',`
She must have forgotten the meeting.|Должно быть, она забыла о встрече.
They might have missed the train.|Возможно, они опоздали на поезд.
You should have told me earlier.|Тебе следовало сказать мне раньше.
He can't have seen the message.|Не может быть, чтобы он видел сообщение.
I could have helped you.|Я мог бы тебе помочь.
We shouldn't have rushed the decision.|Нам не следовало торопиться с решением.
The parcel may have arrived already.|Возможно, посылка уже прибыла.
They must have worked very hard.|Должно быть, они очень много работали.
`);
add('B2','Грамматика','Wish и if only','Wish + Past Simple выражает сожаление о настоящем; wish + Past Perfect — о прошлом; wish + would — желание изменить поведение или ситуацию.',`
I wish I had more free time.|Жаль, что у меня нет больше свободного времени.
I wish I could speak English fluently.|Жаль, что я не могу свободно говорить по-английски.
If only I had listened to you.|Если бы я только тебя послушал.
I wish we had left earlier.|Жаль, что мы не вышли раньше.
I wish the bus would come sooner.|Хотелось бы, чтобы автобус приехал скорее.
She wishes she lived closer to work.|Ей хотелось бы жить ближе к работе.
If only it weren't so expensive.|Если бы только это не было таким дорогим.
I wish I hadn't made that mistake.|Жаль, что я допустил ту ошибку.
`);
add('B2','Разговор','Деловые уточнения и сроки','В работе полезны точные формулировки даты, зависимости и ответственного лица. Could you clarify ...? — вежливый запрос уточнения.',`
Could you clarify the deadline?|Не могли бы вы уточнить крайний срок?
We need a firm delivery date.|Нам нужна точная дата поставки.
Who is responsible for this task?|Кто отвечает за эту задачу?
The shipment is scheduled for Thursday.|Поставка запланирована на четверг.
We are waiting for the client's approval.|Мы ждём согласования клиента.
Please confirm receipt of this message.|Пожалуйста, подтвердите получение сообщения.
The estimate excludes installation costs.|В смету не входят расходы на монтаж.
We will keep you updated on progress.|Мы будем сообщать вам о ходе работ.
`);
add('C1','Грамматика','Инверсия после отрицательных наречий','После Never, Rarely, Hardly, Not only в начале предложения часто используется инверсия: вспомогательный глагол перед подлежащим.',`
Never have I seen such a result.|Никогда прежде я не видел такого результата.
Rarely do we encounter this problem.|Мы редко сталкиваемся с этой проблемой.
Hardly had we arrived when it started raining.|Едва мы приехали, как начался дождь.
Not only did she finish early, but she also helped others.|Она не только закончила раньше, но и помогла другим.
Only then did I understand the risk.|Только тогда я понял риск.
Under no circumstances should you share your password.|Ни при каких обстоятельствах нельзя сообщать свой пароль.
Seldom has the market changed so rapidly.|Редко рынок менялся так стремительно.
No sooner had he left than the phone rang.|Не успел он уйти, как зазвонил телефон.
`);
add('C1','Грамматика','Выделительные конструкции It и What','Cleft sentences помогают подчеркнуть важную часть: It was ... that ...; What I need is ...',`
It was Emma who suggested the idea.|Именно Эмма предложила эту идею.
What we need is more reliable data.|Нам нужны прежде всего более надёжные данные.
It is the timing that worries me.|Меня беспокоят именно сроки.
What surprised me most was the response.|Больше всего меня удивила реакция.
It wasn't the price that caused the delay.|Причиной задержки была не цена.
What matters is how we handle the problem.|Важно то, как мы решаем проблему.
It was in June that they launched the product.|Именно в июне они выпустили продукт.
What I found difficult was explaining the difference.|Мне было трудно объяснить различие.
`);
add('C1','Деловой английский','Осторожные формулировки и выводы','Hedging позволяет высказывать выводы без излишней категоричности: appears to, seems likely, may indicate, to some extent.',`
The data appears to support this conclusion.|Похоже, данные подтверждают этот вывод.
This may indicate a change in demand.|Это может указывать на изменение спроса.
The effect is likely to be temporary.|Эффект, вероятно, будет временным.
To some extent, both sides have a point.|В какой-то степени обе стороны правы.
We cannot rule out further delays.|Мы не можем исключить дальнейших задержек.
There is insufficient evidence to confirm this.|Недостаточно доказательств, чтобы это подтвердить.
It would be premature to draw firm conclusions.|Было бы преждевременно делать окончательные выводы.
The findings should be interpreted with caution.|Результаты следует интерпретировать с осторожностью.
`);

add('A1','Грамматика','There is и there are','There is — есть один предмет; there are — несколько. В вопросах: Is there...? Are there...? В отрицании: there is not / there are not.',`
There is a park near my house.|Рядом с моим домом есть парк.
There are three shops on this street.|На этой улице есть три магазина.
Is there a bank nearby?|Поблизости есть банк?
Are there any free seats?|Есть свободные места?
There isn't any milk left.|Молока не осталось.
There aren't enough chairs.|Стульев недостаточно.
There is a letter for you.|Для тебя есть письмо.
There are some apples in the bag.|В сумке есть несколько яблок.
`);
add('A1','Грамматика','Объектные местоимения','Me, you, him, her, it, us, them обозначают, на кого направлено действие. После предлогов тоже используйте объектную форму: with me, for him.',`
Please call me later.|Пожалуйста, позвони мне позже.
I know him well.|Я хорошо его знаю.
We can help her.|Мы можем ей помочь.
Can you see us?|Ты нас видишь?
I don't understand them.|Я их не понимаю.
This present is for you.|Этот подарок для тебя.
Come with me, please.|Пойдём со мной, пожалуйста.
She is waiting for him.|Она ждёт его.
`);
add('A1','Грамматика','Some и any','Some часто встречается в утверждениях и в предложениях помощи, any — обычно в вопросах и отрицаниях. Any также может значить «любой».',`
I have some questions.|У меня есть несколько вопросов.
Do you have any water?|У тебя есть вода?
We don't have any bread.|У нас нет хлеба.
Would you like some tea?|Хочешь чаю?
There are some books here.|Здесь есть несколько книг.
I can't find any keys.|Я не могу найти ни одного ключа.
You can choose any colour.|Ты можешь выбрать любой цвет.
Can I have some more time?|Можно мне ещё немного времени?
`);
add('A2','Грамматика','Наречия частотности','Always, usually, often, sometimes, rarely, never обычно ставятся перед смысловым глаголом, но после to be: I often work; she is always busy.',`
I usually get up at seven.|Обычно я встаю в семь.
She often works from home.|Она часто работает из дома.
We sometimes eat out.|Иногда мы едим вне дома.
He is always on time.|Он всегда приходит вовремя.
They rarely watch television.|Они редко смотрят телевизор.
I never drink coffee at night.|Я никогда не пью кофе на ночь.
Are you usually busy on Fridays?|Ты обычно занят по пятницам?
How often do you travel?|Как часто ты путешествуешь?
`);
add('A2','Грамматика','As ... as и not as ... as','Конструкция as + прилагательное/наречие + as сравнивает равенство. Not as ... as показывает, что качество выражено слабее.',`
This room is as bright as that one.|Эта комната такая же светлая, как та.
I am not as tall as my brother.|Я не такой высокий, как мой брат.
She speaks as clearly as the teacher.|Она говорит так же чётко, как преподаватель.
This road is not as busy as the main road.|Эта дорога не такая оживлённая, как главная.
It is as cold as yesterday.|Сегодня так же холодно, как вчера.
He runs as fast as his friend.|Он бегает так же быстро, как его друг.
The second option isn't as expensive.|Второй вариант не такой дорогой.
Can you finish as quickly as possible?|Можешь закончить как можно быстрее?
`);
add('A2','Общение','Встречи по расписанию','Present Continuous применяют к согласованным планам: I am meeting the client tomorrow. Для расписаний транспорта часто используется Present Simple.',`
I am meeting Anna at six.|Я встречаюсь с Анной в шесть.
We are flying to London tomorrow.|Завтра мы летим в Лондон.
The train leaves at half past eight.|Поезд отправляется в половине девятого.
What time does the meeting start?|Во сколько начинается встреча?
Are you working this weekend?|Ты работаешь в эти выходные?
I am seeing my doctor on Friday.|В пятницу я иду к врачу.
The shop opens at nine.|Магазин открывается в девять.
We are having dinner together tonight.|Сегодня вечером мы ужинаем вместе.
`);
add('B1','Грамматика','So do I и neither do I','Для согласия используйте so + вспомогательный глагол + подлежащее в утвердительных ситуациях, neither/nor — в отрицательных. Глагол зависит от исходного предложения.',`
I love this city. So do I.|Я люблю этот город. Я тоже.
I don't like the noise. Neither do I.|Мне не нравится этот шум. Мне тоже.
She can drive. So can he.|Она умеет водить. Он тоже.
We weren't ready. Neither were they.|Мы не были готовы. Они тоже.
I have finished. So has Emma.|Я закончил. Эмма тоже.
He won't be late. Neither will I.|Он не опоздает. Я тоже.
I was surprised. So was she.|Я был удивлён. Она тоже.
They didn't agree. Neither did we.|Они не согласились. Мы тоже.
`);
add('B1','Грамматика','Прямая и косвенная речь: вопросы','В косвенном вопросе порядок слов становится утвердительным: He asked where I lived. Для вопросов да/нет используется if или whether.',`
She asked where I worked.|Она спросила, где я работаю.
He wanted to know if I was ready.|Он хотел узнать, готов ли я.
They asked when the train left.|Они спросили, когда отправляется поезд.
I wondered whether she had received it.|Я задумался, получила ли она это.
Could you tell me where the station is?|Не могли бы вы сказать, где находится станция?
Do you know what time it starts?|Ты знаешь, во сколько это начинается?
He asked why we had changed the plan.|Он спросил, почему мы изменили план.
She wanted to know how much it cost.|Она хотела узнать, сколько это стоит.
`);
add('B1','Лексика','Фразовые глаголы с off и out','В фразовых глаголах частицы изменяют значение основы: put off — откладывать, run out of — исчерпать запас, find out — выяснять.',`
We had to put off the meeting.|Нам пришлось отложить встречу.
Please turn off the lights.|Пожалуйста, выключи свет.
The plane took off on time.|Самолёт взлетел вовремя.
We have run out of paper.|У нас закончилась бумага.
I will find out what happened.|Я выясню, что произошло.
She worked out the answer.|Она нашла решение.
Don't leave out any details.|Не пропускай никаких деталей.
He dropped off the parcel yesterday.|Вчера он оставил посылку в пункте доставки.
`);
add('B2','Грамматика','Относительные придаточные с запятыми','Уточняющее придаточное с дополнительной информацией выделяют запятыми. В таком non-defining clause нельзя использовать that вместо who/which.',`
My sister, who lives in York, is a doctor.|Моя сестра, которая живёт в Йорке, врач.
This book, which I bought yesterday, is excellent.|Эта книга, которую я купил вчера, превосходная.
The man who called is our neighbour.|Мужчина, который звонил, наш сосед.
The report that you sent is useful.|Отчёт, который ты прислал, полезен.
Our office, which opened in 2020, is expanding.|Наш офис, который открылся в 2020 году, расширяется.
The person whose bag was lost called us.|Нам позвонил человек, чья сумка потерялась.
Emma, who is leading the project, is away.|Эмма, которая руководит проектом, сейчас отсутствует.
The laptop that I ordered has arrived.|Ноутбук, который я заказал, прибыл.
`);
add('B2','Грамматика','Although, despite и however','Although + полноценное предложение, despite/in spite of + существительное или -ing, however связывает мысли и обычно отделяется пунктуацией.',`
Although it was raining, we went out.|Хотя шёл дождь, мы вышли.
Despite the rain, we went out.|Несмотря на дождь, мы вышли.
In spite of being tired, she continued.|Несмотря на усталость, она продолжила.
The price is high. However, the quality is excellent.|Цена высокая. Однако качество превосходное.
Even though he was late, he joined the meeting.|Хотя он опоздал, он присоединился к встрече.
Despite having little time, we finished the task.|Несмотря на нехватку времени, мы завершили задачу.
While I agree in principle, I have some concerns.|Хотя в целом я согласен, у меня есть некоторые опасения.
Nevertheless, the results were encouraging.|Тем не менее результаты обнадёживали.
`);
add('B2','Грамматика','Эмоциональное усиление через do','Do/does/did могут усиливать утверждение: I do understand. После вспомогательного do смысловой глагол используется в начальной форме.',`
I do appreciate your help.|Я действительно ценю вашу помощь.
She does know the answer.|Она и правда знает ответ.
We did send the document yesterday.|Мы действительно отправили документ вчера.
I do want to explain the difference.|Я правда хочу объяснить разницу.
He did try to contact you.|Он действительно пытался связаться с вами.
Please do come in.|Пожалуйста, обязательно заходите.
I do understand your concerns.|Я действительно понимаю ваши опасения.
They did finish the task on time.|Они всё-таки завершили задачу вовремя.
`);
add('C1','Грамматика','Needn’t have и didn’t need to','Needn’t have + V3 означает, что действие было выполнено зря. Didn’t need to + V показывает отсутствие необходимости; само по себе не сообщает, выполнили действие или нет.',`
You needn't have bought another ticket.|Тебе не стоило покупать ещё один билет.
We needn't have rushed; the train was delayed.|Мы зря спешили: поезд задержали.
I didn't need to call because she had emailed me.|Мне не понадобилось звонить, потому что она прислала письмо.
You shouldn't have shared that information.|Тебе не следовало делиться этой информацией.
He must have misunderstood the instructions.|Должно быть, он неправильно понял инструкции.
She can't have known the result in advance.|Не может быть, чтобы она знала результат заранее.
They might have missed the deadline.|Возможно, они пропустили срок.
I could have helped if you had asked.|Я мог бы помочь, если бы ты попросил.
`);
add('C1','Грамматика','Причастные обороты','Participle clauses с -ing или V3 сокращают придаточные, когда ясно, к кому относится действие. Не создавайте «висячих» оборотов.',`
Having reviewed the figures, we changed the forecast.|Изучив цифры, мы изменили прогноз.
Written in plain English, the guide is easy to follow.|Поскольку руководство написано простым английским, ему легко следовать.
Not knowing the answer, I asked for help.|Не зная ответа, я попросил помощи.
Built in the 19th century, the bridge is still in use.|Мост, построенный в XIX веке, до сих пор используется.
Having been informed of the risk, they proceeded.|Будучи предупреждёнными о риске, они продолжили.
Working remotely, she saves time on commuting.|Работая удалённо, она экономит время на поездках.
Given enough time, we could improve the design.|Если бы у нас было достаточно времени, мы могли бы улучшить дизайн.
Faced with a difficult choice, he remained calm.|Оказавшись перед трудным выбором, он сохранил спокойствие.
`);
add('C1','Деловой английский','Номинализация и ясный стиль','Номинализация превращает действие в существительное: decide → decision. В формальных документах это распространено, но чрезмерное количество существительных делает текст тяжёлым.',`
The implementation of the policy will take time.|Реализация политики потребует времени.
We need a clear explanation of the decision.|Нам нужно ясное объяснение решения.
The reduction in costs was significant.|Сокращение затрат было значительным.
Their failure to respond caused delays.|То, что они не ответили, вызвало задержки.
We evaluated the proposal before making a decision.|Мы оценили предложение, прежде чем принять решение.
The analysis revealed several weaknesses.|Анализ выявил несколько слабых мест.
Our priority is the improvement of customer service.|Наш приоритет — улучшение обслуживания клиентов.
A simpler explanation would be more effective.|Более простое объяснение было бы эффективнее.
`);


add('A1','Разговорная речь','Вежливые просьбы','Can I ...? — простая просьба. Could I ...? и Would you mind ...? звучат мягче. После Would you mind обычно ставится глагол с -ing.',`
Can I sit here?|Можно мне здесь сесть?
Could you open the window, please?|Не могли бы вы открыть окно, пожалуйста?
May I ask a question?|Можно задать вопрос?
Would you mind waiting a moment?|Вы не против немного подождать?
Could I have a glass of water?|Можно мне стакан воды?
Can you help me with this bag?|Можете помочь мне с этой сумкой?
Would you like some tea?|Хотите чаю?
That's very kind of you.|Это очень любезно с вашей стороны.
`);
add('A1','Лексика','Еда и количества','Some — некоторое количество; any часто употребляется в вопросах и отрицаниях. Much с неисчисляемыми, many с исчисляемыми существительными.',`
I would like some rice.|Я хотел бы немного риса.
Do you have any bread?|У вас есть хлеб?
How many eggs do we need?|Сколько яиц нам нужно?
How much milk is left?|Сколько молока осталось?
There isn't any sugar.|Сахара совсем нет.
I have a few apples.|У меня есть несколько яблок.
We need a little salt.|Нам нужно немного соли.
This soup is too salty.|Этот суп слишком солёный.
`);
add('A2','Грамматика','Just, already, yet','Just — только что; already — уже; yet — ещё/уже обычно в конце вопроса или отрицания. Часто используются с Present Perfect.',`
I have just arrived.|Я только что приехал.
She has already sent the email.|Она уже отправила письмо.
Have you finished yet?|Ты уже закончил?
We haven't eaten yet.|Мы ещё не ели.
He has just called me.|Он только что мне позвонил.
I have already seen that film.|Я уже видел этот фильм.
Have they left yet?|Они уже ушли?
The meeting hasn't started yet.|Встреча ещё не началась.
`);
add('A2','Грамматика','Сравнение as ... as','As + прилагательное + as показывает равенство: as fast as. Not as ... as — не такой ... как.',`
This phone is as good as mine.|Этот телефон так же хорош, как мой.
She is as tall as her brother.|Она такая же высокая, как её брат.
Today is not as cold as yesterday.|Сегодня не так холодно, как вчера.
This task is as important as the last one.|Эта задача так же важна, как предыдущая.
He speaks as clearly as the teacher.|Он говорит так же понятно, как учитель.
The new model is not as expensive as the old one.|Новая модель не такая дорогая, как старая.
I can't run as fast as you.|Я не могу бегать так же быстро, как ты.
The room is not as quiet as I expected.|Комната не такая тихая, как я ожидал.
`);
add('B1','Фразовые глаголы','Частые значения take и get','Get и take имеют множество сочетаний с частицами. Смысл часто не равен буквальному переводу глагола; запоминайте целую фразу.',`
Please take off your shoes.|Пожалуйста, снимите обувь.
The plane took off on time.|Самолёт взлетел вовремя.
I need to get up early tomorrow.|Мне нужно завтра рано встать.
We got along well with our neighbours.|Мы хорошо ладили с соседями.
Can you take care of the children?|Можешь присмотреть за детьми?
I got over the flu last week.|Я поправился после гриппа на прошлой неделе.
Please get back to me by Friday.|Пожалуйста, ответьте мне до пятницы.
Let's take a look at the numbers.|Давайте посмотрим на цифры.
`);
add('B1','Разговорная речь','Уточнение и переспрашивание','В разговоре полезно уточнять, а не угадывать. Do you mean ...? — «Вы имеете в виду ...?».',`
Sorry, could you say that again?|Извините, не могли бы вы повторить?
What exactly do you mean?|Что именно вы имеете в виду?
Could you give me an example?|Можете привести пример?
Let me check if I understood you correctly.|Дайте мне проверить, правильно ли я вас понял.
Did you mean next Thursday?|Вы имели в виду следующий четверг?
Could you speak a little more slowly?|Не могли бы вы говорить немного медленнее?
I'm not sure I follow.|Не уверен, что понимаю ход вашей мысли.
So, you're suggesting we wait?|То есть вы предлагаете подождать?
`);
add('B2','Академический английский','Выражение осторожных выводов','May, might, appear to и seem to позволяют отличать гипотезу от доказанного факта. Avoid overclaiming в отчётах.',`
The results may indicate a change in demand.|Результаты могут указывать на изменение спроса.
This seems to be a temporary issue.|Похоже, это временная проблема.
The evidence is not conclusive.|Доказательства не позволяют сделать однозначный вывод.
We cannot rule out other explanations.|Мы не можем исключать другие объяснения.
The trend appears to be weakening.|Похоже, тенденция ослабевает.
There is some evidence to suggest a connection.|Есть некоторые свидетельства возможной связи.
Further testing would be needed.|Потребуются дополнительные испытания.
This finding should be interpreted cautiously.|Этот результат следует интерпретировать осторожно.
`);
add('B2','Деловой английский','Оценки и прогнозы','Expected to, on track to, likely to и forecast to подходят для прогнозов; отличайте план от гарантии.',`
Sales are expected to grow this quarter.|Ожидается рост продаж в этом квартале.
We are on track to meet the deadline.|Мы идём по графику и должны успеть к сроку.
Costs are likely to rise next year.|Вероятно, в следующем году затраты вырастут.
The forecast is subject to change.|Прогноз может измениться.
Our estimate is based on current prices.|Наша оценка основана на текущих ценах.
We expect the shipment to arrive on Monday.|Мы ожидаем, что поставка прибудет в понедельник.
There is a risk of further delays.|Существует риск дальнейших задержек.
We should revise the plan if demand falls.|Нам следует пересмотреть план, если спрос упадёт.
`);
add('C1','Деловой английский','Тонкие способы несогласия','В профессиональной дискуссии можно выразить несогласие без резкого отрицания: I take your point, but ...; I would question whether ...',`
I take your point, but the data tell a different story.|Я понимаю вашу позицию, но данные говорят об ином.
I would question whether this approach is sustainable.|Я бы поставил под сомнение устойчивость этого подхода.
That is a fair observation, although it overlooks the cost.|Это справедливое замечание, хотя оно не учитывает стоимость.
I am not entirely convinced by that argument.|Меня не до конца убеждает этот аргумент.
We may have to agree to disagree.|Похоже, нам придётся остаться при разных мнениях.
Could we look at the assumptions behind that estimate?|Можем рассмотреть предпосылки этой оценки?
I see the merit in your proposal.|Я вижу достоинства вашего предложения.
My concern is less about cost than about reliability.|Меня беспокоит скорее надёжность, чем стоимость.
`);
add('C1','Разговорная речь','Нюансы и оттенки смысла','Hardly, barely, rather, fairly и somewhat смягчают или уточняют степень. Their meanings differ in context.',`
The solution is hardly ideal.|Это решение далеко не идеально.
We barely had time to respond.|Мы едва успели ответить.
The outcome was somewhat unexpected.|Результат оказался несколько неожиданным.
That was a rather unusual decision.|Это было довольно необычное решение.
The instructions were fairly straightforward.|Инструкции были довольно простыми.
The project is far from complete.|Проект ещё далеко не завершён.
His explanation was remarkably clear.|Его объяснение было на удивление ясным.
It would be premature to draw conclusions.|Делать выводы было бы преждевременно.
`);


/* EnglishDay 1.8.0: additional authored grammar and context lessons. */
add("A1","Быт","В магазине одежды","Для размеров используйте size, для примерки try on. Вежливый запрос обычно начинается с Could I или Could you.",`
Do you have this in a medium?|У вас есть это в среднем размере?
Could I try it on?|Можно это примерить?
Where is the fitting room?|Где примерочная?
This jacket is too small.|Эта куртка слишком маленькая.
I need a larger size.|Мне нужен размер побольше.
Does this shirt come in blue?|Эта рубашка бывает синего цвета?
It fits me well.|Она мне хорошо подходит по размеру.
Can I pay by card?|Можно оплатить картой?
`);
add("A1","Произношение","Правописание и немые буквы","В английском написание не всегда совпадает с произношением: k в know и b в climb не произносятся. Слушайте слово и запоминайте его целиком.",`
I know the answer.|Я знаю ответ.
Please write your name.|Пожалуйста, напишите своё имя.
The knife is sharp.|Нож острый.
She climbed the stairs.|Она поднялась по лестнице.
We listen to music.|Мы слушаем музыку.
He walks to school.|Он ходит в школу пешком.
The island is beautiful.|Остров красивый.
The sign is near the door.|Табличка находится возле двери.
`);
add("A1","Время","Дни недели и расписание","On используется с днями недели; at — с точным временем; in — с месяцами и годами. В датах порядок слов зависит от варианта английского.",`
The shop opens at nine.|Магазин открывается в девять.
We meet on Monday.|Мы встречаемся в понедельник.
My birthday is in July.|Мой день рождения в июле.
The train leaves at six thirty.|Поезд отправляется в шесть тридцать.
I work from nine to five.|Я работаю с девяти до пяти.
She has a lesson on Friday.|У неё урок в пятницу.
The meeting starts in ten minutes.|Встреча начнётся через десять минут.
We are closed on Sundays.|По воскресеньям мы закрыты.
`);
add("A2","Быт","Устранение проблем дома","There is/are описывает наличие, а is/are broken — состояние. Для запроса помощи употребляйте Could you...?",`
The heating is not working.|Отопление не работает.
There is a leak under the sink.|Под раковиной протечка.
Could you send a plumber?|Можете прислать сантехника?
The light keeps flickering.|Лампа постоянно мигает.
I need to report a problem.|Мне нужно сообщить о проблеме.
The door will not close properly.|Дверь плохо закрывается.
Is the repair covered by the warranty?|Ремонт покрывается гарантией?
The technician will come tomorrow.|Мастер придёт завтра.
`);
add("A2","Грамматика","Used to и привычки в прошлом","Used to + глагол описывает прежнюю привычку или состояние, которых уже нет. Не путайте с be used to + существительное/-ing — быть привыкшим.",`
I used to live in a small town.|Раньше я жил в небольшом городе.
She used to work at night.|Раньше она работала по ночам.
Did you use to play football?|Раньше ты играл в футбол?
We did not use to travel much.|Раньше мы мало путешествовали.
I am used to cold weather.|Я привык к холодной погоде.
He is used to getting up early.|Он привык рано вставать.
It took me time to get used to it.|Мне потребовалось время, чтобы привыкнуть к этому.
I used to take the bus to work.|Раньше я ездил на работу на автобусе.
`);
add("A2","Быт","Почта и доставка","Track a parcel — отслеживать посылку; pick up — забирать; delivery address — адрес доставки.",`
I am waiting for a parcel.|Я жду посылку.
The delivery has been delayed.|Доставку задержали.
Could you check the tracking number?|Можете проверить номер отслеживания?
The package arrived damaged.|Посылка пришла повреждённой.
I would like to change the delivery address.|Я хотел бы изменить адрес доставки.
Can I pick it up tomorrow?|Могу я забрать её завтра?
The courier left a note.|Курьер оставил записку.
Please confirm receipt of the parcel.|Пожалуйста, подтвердите получение посылки.
`);
add("B1","Грамматика","Reported speech","В косвенной речи часто меняют времена, местоимения и указатели времени: She said she was tired. Если факт всё ещё верен, сдвиг времени не всегда обязателен.",`
She said she was tired.|Она сказала, что устала.
He told me he had lost his keys.|Он сказал мне, что потерял ключи.
They asked whether I was available.|Они спросили, свободен ли я.
She said she would call later.|Она сказала, что позвонит позже.
He asked me where I lived.|Он спросил меня, где я живу.
They told us the meeting had been cancelled.|Они сообщили нам, что встречу отменили.
I explained that I could not attend.|Я объяснил, что не могу присутствовать.
He said the price was too high.|Он сказал, что цена слишком высокая.
`);
add("B1","Работа","Письмо клиенту","Деловое письмо должно иметь ясную цель, вежливую просьбу и конкретный срок. Could you... часто звучит мягче, чем прямой приказ.",`
Thank you for your enquiry.|Спасибо за ваш запрос.
Please find the invoice attached.|Счёт находится во вложении.
Could you confirm the delivery date?|Можете подтвердить дату доставки?
We would appreciate your feedback.|Мы будем признательны за ваш отзыв.
I am writing to follow up on our meeting.|Пишу, чтобы уточнить итоги нашей встречи.
Please let me know if you have any questions.|Сообщите, пожалуйста, если возникнут вопросы.
We apologise for the delay.|Приносим извинения за задержку.
I look forward to hearing from you.|Буду ждать вашего ответа.
`);
add("B1","Общение","Мнение и аргументы","In my opinion выражает мнение; although вводит уступку, because — причину. Не используйте because и so одновременно в одной причинной конструкции без необходимости.",`
In my opinion, this is a good idea.|По моему мнению, это хорошая идея.
I agree with you on this point.|Я согласен с вами по этому вопросу.
I see your point, but I disagree.|Я понимаю вашу позицию, но не согласен.
Although it is expensive, it is reliable.|Хотя это дорого, это надёжно.
The plan failed because we lacked time.|План провалился, потому что нам не хватило времени.
We should consider another option.|Нам следует рассмотреть другой вариант.
There are several reasons for this.|Для этого есть несколько причин.
Could you explain your reasoning?|Можете объяснить ход ваших рассуждений?
`);
add("B2","Работа","Требования к проекту","Requirements — требования, scope — объём проекта, milestones — контрольные этапы. Формулировки должны различать обязательные и желательные функции.",`
We need to clarify the project scope.|Нам нужно уточнить объём проекта.
This feature is outside the agreed scope.|Эта функция не входит в согласованный объём работ.
The deadline depends on supplier availability.|Срок зависит от доступности поставщика.
We should define measurable milestones.|Нам следует определить измеримые контрольные этапы.
The requirements have changed since the last review.|Требования изменились после последнего рассмотрения.
We can deliver a minimum viable version first.|Сначала мы можем выпустить минимально жизнеспособную версию.
Could you prioritise these requests?|Можете расставить приоритеты этих запросов?
Let's document the acceptance criteria.|Давайте зафиксируем критерии приёмки.
`);
add("B2","Грамматика","Mixed conditionals","Смешанные условные предложения соединяют причину в прошлом и результат в настоящем: If I had left earlier, I would be there now.",`
If I had saved more, I would own a car now.|Если бы я больше накопил, сейчас у меня была бы машина.
If she had studied harder, she would have a better job.|Если бы она училась усерднее, сейчас у неё была бы работа получше.
If I were more organised, I would not have missed the deadline.|Если бы я был организованнее, я бы не пропустил срок.
If he had taken the train, he would be here by now.|Если бы он сел на поезд, он бы уже был здесь.
If we had invested earlier, we would be in a stronger position.|Если бы мы вложились раньше, сейчас наша позиция была бы сильнее.
If she spoke Spanish, she could have helped yesterday.|Если бы она знала испанский, то смогла бы помочь вчера.
If they had listened, the problem would not exist today.|Если бы они прислушались, этой проблемы сегодня бы не было.
If I had accepted the offer, I would be working abroad.|Если бы я принял предложение, сейчас я бы работал за границей.
`);
add("B2","Работа","Проверка поставщика","Due diligence — проверка надёжности, lead time — срок поставки, compliance — соблюдение требований. Уточняйте условия письменно.",`
We need to verify the supplier's references.|Нам нужно проверить рекомендации поставщика.
What is the standard lead time?|Каков стандартный срок поставки?
Could you provide a certificate of conformity?|Можете предоставить сертификат соответствия?
The quoted price excludes shipping costs.|Указанная цена не включает доставку.
We should review the warranty terms.|Нам следует изучить условия гарантии.
The contract specifies a late-delivery penalty.|В договоре предусмотрен штраф за задержку поставки.
We must assess the risk of disruption.|Нам нужно оценить риск перебоев.
Please confirm the payment terms in writing.|Подтвердите, пожалуйста, условия оплаты письменно.
`);
add("C1","Аргументация","Оговорки и степень уверенности","It appears that и arguably снижают категоричность. Hedging помогает формулировать осторожные выводы, особенно при неполных данных.",`
The evidence appears to support this conclusion.|Данные, по-видимому, подтверждают этот вывод.
Arguably, the second option is more sustainable.|Можно утверждать, что второй вариант более устойчив.
This may not necessarily be the case.|Это не обязательно так.
We cannot rule out alternative explanations.|Мы не можем исключать альтернативные объяснения.
The findings should be interpreted with caution.|Результаты следует интерпретировать осторожно.
It would be misleading to generalise from one example.|Было бы ошибкой обобщать на основании одного примера.
There is insufficient evidence to draw a firm conclusion.|Данных недостаточно для однозначного вывода.
The outcome is contingent upon several factors.|Результат зависит от нескольких факторов.
`);
add("C1","Работа","Переговоры в сложной ситуации","Косвенные предложения и уточнения помогают обсуждать конфликт без обвинений. We would be prepared to... — готовность при соблюдении условий.",`
We would be prepared to reconsider the proposal.|Мы были бы готовы пересмотреть предложение.
Our main concern is the allocation of risk.|Наша главная обеспокоенность — распределение рисков.
Could we explore a mutually acceptable solution?|Можем поискать взаимоприемлемое решение?
This condition would be difficult for us to accept.|Нам было бы трудно принять это условие.
We are not in a position to make that commitment.|Сейчас мы не можем взять на себя такое обязательство.
Let's separate the immediate issue from the long-term objectives.|Давайте отделим срочный вопрос от долгосрочных целей.
I appreciate your position, but we need additional safeguards.|Я понимаю вашу позицию, но нам нужны дополнительные гарантии.
We suggest revisiting this point after the pilot phase.|Предлагаем вернуться к этому вопросу после пилотного этапа.
`);
add("C1","Чтение","Сложные связки в аналитике","Notwithstanding, insofar as, on balance и by contrast нужны для чтения сложных текстов. Учитывайте стилистическую окраску.",`
Notwithstanding these concerns, the plan was approved.|Несмотря на эти опасения, план был утверждён.
Insofar as the data are reliable, the trend is clear.|Насколько данные надёжны, тенденция очевидна.
On balance, the benefits outweigh the costs.|В целом преимущества перевешивают затраты.
By contrast, the second study found no significant effect.|Напротив, второе исследование не выявило значимого эффекта.
The results are consistent with our initial hypothesis.|Результаты согласуются с нашей исходной гипотезой.
The argument rests on several questionable assumptions.|Аргумент основан на нескольких сомнительных предположениях.
The proposal merits further consideration.|Предложение заслуживает дальнейшего рассмотрения.
These findings have broader implications for policy.|Эти выводы имеют более широкие последствия для политики.
`);

const dialogues=[
 {title:'В кафе',level:'A1',turns:[['Could I have a coffee, please?','Можно мне кофе, пожалуйста?'],['Of course. Small or large?','Конечно. Маленький или большой?'],['A large one, please.','Большой, пожалуйста.'],['Would you like milk?','Хотите молоко?'],['Yes, just a little.','Да, совсем немного.'],['That will be four pounds.','С вас четыре фунта.']]},
 {title:'Знакомство',level:'A1',turns:[['Hi, my name is Emma.','Привет, меня зовут Эмма.'],['Nice to meet you, Emma.','Приятно познакомиться, Эмма.'],['Where are you from?','Откуда ты?'],['I am from Ukraine, but I live in Denmark.','Я из Украины, но живу в Дании.'],['How long have you lived here?','Как давно ты здесь живёшь?'],['For three years.','Три года.']]},
 {title:'В супермаркете',level:'A1',turns:[['Excuse me, where can I find milk?','Извините, где можно найти молоко?'],['It is in aisle five.','Оно в пятом проходе.'],['Do you have lactose-free milk?','У вас есть молоко без лактозы?'],['Yes, on the top shelf.','Да, на верхней полке.'],['Thank you for your help.','Спасибо за помощь.'],['You are welcome.','Пожалуйста.']]},
 {title:'В гостинице',level:'A2',turns:[['Good evening. I have a reservation.','Добрый вечер. У меня бронирование.'],['What name is it under?','На какое имя бронирование?'],['It is under Petrenko.','На фамилию Петренко.'],['May I see your passport?','Могу я увидеть ваш паспорт?'],['Of course. Is breakfast included?','Конечно. Завтрак включён?'],['Yes, from seven to ten.','Да, с семи до десяти.']]},
 {title:'Как добраться',level:'A2',turns:[['Could you tell me how to get to the station?','Не могли бы вы сказать, как пройти к станции?'],['Go straight and turn right.','Идите прямо и поверните направо.'],['Is it far from here?','Это далеко отсюда?'],['About ten minutes on foot.','Примерно десять минут пешком.'],['Thank you very much.','Большое спасибо.'],['No problem.','Не за что.']]},
 {title:'У врача',level:'A2',turns:[['What seems to be the problem?','Что вас беспокоит?'],['I have had a headache for two days.','У меня болит голова уже два дня.'],['Do you have a fever?','У вас есть температура?'],['No, but I feel dizzy.','Нет, но у меня кружится голова.'],['Let me check your blood pressure.','Давайте измерю ваше давление.'],['All right, thank you.','Хорошо, спасибо.']]},
 {title:'По телефону',level:'B1',turns:[['Hello, may I speak to Daniel?','Здравствуйте, можно поговорить с Даниэлем?'],['I am afraid he is in a meeting.','Боюсь, он на встрече.'],['Could you ask him to call me back?','Не могли бы вы попросить его перезвонить?'],['Certainly. May I take your number?','Конечно. Можно ваш номер?'],['Yes, it is 555 0182.','Да, 555 0182.'],['I will pass on the message.','Я передам сообщение.']]},
 {title:'Собеседование',level:'B1',turns:[['Tell me about your experience.','Расскажите о своём опыте.'],['I have worked in sales for five years.','Я работаю в продажах пять лет.'],['What are your main strengths?','Каковы ваши сильные стороны?'],['I am organised and good at solving problems.','Я организован и хорошо решаю проблемы.'],['When could you start?','Когда вы могли бы приступить?'],['I could start next month.','Я мог бы начать в следующем месяце.']]},
 {title:'Планирование поездки',level:'B1',turns:[['Have you booked the flights yet?','Ты уже забронировал билеты?'],['Not yet. The prices are quite high.','Ещё нет. Цены довольно высокие.'],['We could travel a week later.','Мы могли бы поехать на неделю позже.'],['That might be cheaper.','Возможно, так будет дешевле.'],['Shall I check the dates?','Мне проверить даты?'],['Yes, please do.','Да, пожалуйста.']]},
 {title:'Обсуждение проекта',level:'B2',turns:[['We need to review the project timeline.','Нам нужно пересмотреть график проекта.'],['The latest update caused a delay.','Последнее обновление вызвало задержку.'],['How significant is the impact?','Насколько существенно влияние?'],['We may need two additional days.','Возможно, нам понадобятся ещё два дня.'],['Could we prioritise the critical tasks?','Можем ли мы расставить приоритеты для критичных задач?'],['That would help us meet the deadline.','Это помогло бы уложиться в срок.']]},
 {title:'Возврат покупки',level:'B1',turns:[['I would like to return this item.','Я хотел бы вернуть этот товар.'],['May I ask what is wrong with it?','Можно спросить, что с ним не так?'],['It stopped working after two days.','Он перестал работать через два дня.'],['Do you still have the receipt?','У вас сохранился чек?'],['Yes, here it is.','Да, вот он.'],['We can offer a refund or replacement.','Мы можем предложить возврат денег или замену.']]},
 {title:'Деловые переговоры',level:'B2',turns:[['We would like to discuss the terms.','Мы хотели бы обсудить условия.'],['Which points are you concerned about?','Какие пункты вас беспокоят?'],['The delivery schedule seems unrealistic.','График поставок кажется нереалистичным.'],['We could extend it by two weeks.','Мы могли бы продлить его на две недели.'],['That sounds like a reasonable compromise.','Это похоже на разумный компромисс.'],['Let us put it in writing.','Давайте зафиксируем это письменно.']]},
 {title:'В аэропорту',level:'A2',turns:[['Where can I check in for this flight?','Где можно зарегистрироваться на этот рейс?'],['The check-in desks are over there.','Стойки регистрации находятся там.'],['Is this bag too heavy?','Эта сумка слишком тяжёлая?'],['It is two kilos over the limit.','Она на два килограмма тяжелее нормы.'],['Can I pay for the extra weight?','Могу я доплатить за перевес?'],['Yes, please use this counter.','Да, пожалуйста, обратитесь к этой стойке.']]},
 {title:'В аптеке',level:'A2',turns:[['Hello, do you have anything for a sore throat?','Здравствуйте, у вас есть что-нибудь от боли в горле?'],['Do you have a fever as well?','У вас также повышена температура?'],['No, just a sore throat.','Нет, только болит горло.'],['These lozenges may help.','Эти леденцы могут помочь.'],['How often should I take them?','Как часто мне их принимать?'],['Please follow the instructions on the package.','Пожалуйста, следуйте инструкции на упаковке.']]},
 {title:'В общественном транспорте',level:'A1',turns:[['Does this bus go to the city centre?','Этот автобус идёт в центр города?'],['Yes, it stops near the main square.','Да, он останавливается возле главной площади.'],['How much is a ticket?','Сколько стоит билет?'],['It is three pounds.','Три фунта.'],['Can I pay by card?','Можно оплатить картой?'],['Of course. Just tap your card.','Конечно. Просто приложите карту.']]},
 {title:'Разговор с соседом',level:'A2',turns:[['Hi, how are you settling in?','Привет, как обустраиваешься?'],['Quite well, thanks.','Довольно хорошо, спасибо.'],['Do you need any help?','Тебе нужна помощь?'],['Actually, could you recommend a plumber?','Вообще-то можешь посоветовать сантехника?'],['Sure, I can send you a number.','Конечно, я могу прислать номер.'],['That would be great, thank you!','Было бы здорово, спасибо!']]},
 {title:'На работе: задача',level:'B1',turns:[['Could you check this document?','Можешь проверить этот документ?'],['Sure. When do you need it?','Конечно. Когда он нужен?'],['By the end of the day, if possible.','К концу дня, если возможно.'],['I can do that after lunch.','Я могу сделать это после обеда.'],['Please let me know if you find any issues.','Дай знать, если обнаружишь какие-то проблемы.'],['I will send you my comments.','Я пришлю свои замечания.']]},
 {title:'Запись к врачу',level:'B1',turns:[['I would like to make an appointment.','Я хотел бы записаться на приём.'],['Is it urgent or can it wait?','Это срочно или может подождать?'],['It is not urgent, but I need advice.','Это не срочно, но мне нужна консультация.'],['We have a slot on Thursday morning.','У нас есть время в четверг утром.'],['Could I come in the afternoon instead?','Можно прийти вместо этого после обеда?'],['Yes, half past two is available.','Да, есть время в половине третьего.']]},
 {title:'Техническая поддержка',level:'B1',turns:[['What seems to be the issue?','В чём, похоже, проблема?'],['The application keeps crashing.','Приложение постоянно аварийно закрывается.'],['When did the problem start?','Когда началась проблема?'],['Right after the last update.','Сразу после последнего обновления.'],['Could you send us the error message?','Могли бы вы прислать сообщение об ошибке?'],['Yes, I will attach a screenshot.','Да, я приложу снимок экрана.']]},
 {title:'Обсуждение цены',level:'B2',turns:[['Could we review your latest offer?','Можем рассмотреть ваше последнее предложение?'],['Of course. Which terms concern you?','Конечно. Какие условия вас беспокоят?'],['The unit price is above our budget.','Цена за единицу выше нашего бюджета.'],['We may offer a discount for larger orders.','Мы можем предложить скидку на более крупные заказы.'],['What volume would qualify?','Какой объём соответствует условиям скидки?'],['At least five hundred units per order.','Не менее пятисот единиц в заказе.']]},
 {title:'Обратная связь сотруднику',level:'B2',turns:[['Can we discuss the project results?','Можем обсудить результаты проекта?'],['Yes, I would appreciate your feedback.','Да, я был бы благодарен за отзыв.'],['You handled the client well.','Ты хорошо поработал с клиентом.'],['Thank you. What could I improve?','Спасибо. Что мне можно улучшить?'],['The reports could be more concise.','Отчёты могли бы быть более краткими.'],['I will focus on that next time.','В следующий раз я уделю этому внимание.']]},
 {title:'Обсуждение рисков',level:'C1',turns:[['What is the main downside of this proposal?','Каков главный недостаток этого предложения?'],['It could increase our operating costs.','Это может увеличить наши операционные расходы.'],['Can we quantify that risk?','Можем количественно оценить этот риск?'],['We need more reliable data first.','Сначала нам нужны более надёжные данные.'],['Could we run a limited pilot?','Можем провести ограниченный пилотный запуск?'],['That would give us evidence before scaling.','Это даст нам данные до масштабирования.']]},
 {title:'На почте',level:'A1',turns:[['Hello, I need to send this letter.','Здравствуйте, мне нужно отправить это письмо.'],['Where would you like to send it?','Куда вы хотели бы его отправить?'],['To Manchester, please.','В Манчестер, пожалуйста.'],['Would you like first-class delivery?','Хотите отправить первым классом?'],['Yes, how much is it?','Да, сколько это стоит?'],['It is two pounds fifty.','Два фунта пятьдесят.']]},
 {title:'Покупка обуви',level:'A1',turns:[['Do you have these shoes in size forty?','У вас есть эта обувь сорокового размера?'],['Yes, here is a pair.','Да, вот пара.'],['Can I try them on?','Можно их примерить?'],['Of course. The mirror is over there.','Конечно. Зеркало вон там.'],['They fit well. I will take them.','Они хорошо сидят. Я их возьму.'],['Would you like a bag?','Вам нужен пакет?']]},
 {title:'В библиотеке',level:'A2',turns:[['I would like to borrow this book.','Я хотел бы взять эту книгу на время.'],['Do you have a library card?','У вас есть читательский билет?'],['Not yet. Can I get one today?','Ещё нет. Могу я оформить его сегодня?'],['Yes, I just need your address.','Да, мне нужен только ваш адрес.'],['How long can I keep the book?','Как долго я могу держать книгу?'],['You can return it within three weeks.','Вы можете вернуть её в течение трёх недель.']]},
 {title:'Аренда автомобиля',level:'A2',turns:[['I have booked a small car.','Я забронировал небольшой автомобиль.'],['May I see your driving licence?','Можно посмотреть ваши водительские права?'],['Yes. Is insurance included?','Да. Страховка включена?'],['Basic insurance is included in the price.','Базовая страховка включена в цену.'],['Where should I return the car?','Куда мне вернуть машину?'],['Please return it to the same car park.','Пожалуйста, верните её на ту же парковку.']]},
 {title:'Проблема с интернетом',level:'B1',turns:[['My internet connection keeps dropping.','У меня постоянно пропадает интернет-соединение.'],['Have you tried restarting the router?','Вы пробовали перезагрузить роутер?'],['Yes, but the problem came back.','Да, но проблема вернулась.'],['Does it happen on every device?','Это происходит на всех устройствах?'],['Yes, both my laptop and phone lose the connection.','Да, и ноутбук, и телефон теряют соединение.'],['We will check the line and contact you.','Мы проверим линию и свяжемся с вами.']]},
 {title:'Предложение встретиться',level:'B1',turns:[['Would you be free to meet next Tuesday?','Ты был бы свободен встретиться в следующий вторник?'],['I have another appointment in the morning.','У меня утром другая встреча.'],['How about three in the afternoon?','Как насчёт трёх часов дня?'],['That would work for me.','Мне это подходит.'],['Shall I send you a calendar invitation?','Мне отправить тебе приглашение в календаре?'],['Yes, please include the address.','Да, пожалуйста, добавь адрес.']]},
 {title:'Задержка поставки',level:'B2',turns:[['The shipment has not arrived as agreed.','Поставка не прибыла, как было согласовано.'],['We apologise for the unexpected delay.','Приносим извинения за непредвиденную задержку.'],['Could you confirm the revised delivery date?','Не могли бы вы подтвердить новую дату поставки?'],['We expect the goods to arrive on Thursday.','Мы ожидаем прибытия товара в четверг.'],['Please send the tracking details in writing.','Пожалуйста, пришлите данные отслеживания письменно.'],['Certainly. We will also update you if anything changes.','Конечно. Мы также сообщим вам, если что-то изменится.']]},
 {title:'Публичное выступление',level:'C1',turns:[['What would you say is the main takeaway?','Какой, по-вашему, главный вывод?'],['We need to distinguish correlation from causation.','Нам нужно различать корреляцию и причинно-следственную связь.'],['Could you elaborate on the limitations?','Не могли бы вы подробнее остановиться на ограничениях?'],['The sample size was too small for firm conclusions.','Выборка была слишком маленькой для однозначных выводов.'],['How could we address that in future research?','Как мы могли бы учесть это в будущих исследованиях?'],['A larger, more diverse sample would strengthen the evidence.','Более крупная и разнообразная выборка повысила бы надёжность доказательств.']]},

 {title:'В туристическом центре',level:'A2',turns:[['Do you have a map of the city?','У вас есть карта города?'],['Yes, here is a free map.','Да, вот бесплатная карта.'],['Which places would you recommend?','Какие места вы бы посоветовали?'],['The old town is worth visiting.','Стоит посетить старый город.'],['Can I get there on foot?','Я могу дойти туда пешком?'],['Yes, it is about fifteen minutes away.','Да, это примерно в пятнадцати минутах отсюда.']]},
 {title:'Обращение в техподдержку',level:'B1',turns:[['I cannot sign in to my account.','Я не могу войти в свою учётную запись.'],['Are you seeing an error message?','Вы видите сообщение об ошибке?'],['Yes, it says my password is incorrect.','Да, написано, что пароль неверный.'],['Have you tried resetting it?','Вы пробовали сбросить пароль?'],['I did, but the email never arrived.','Да, но письмо так и не пришло.'],['Let me check the email address on file.','Позвольте проверить адрес электронной почты в системе.']]},
 {title:'Видеовстреча с командой',level:'B2',turns:[['Can everyone hear me clearly?','Все хорошо меня слышат?'],['Yes, but your screen is not visible.','Да, но ваш экран не виден.'],['I will share it again now.','Сейчас я снова открою к нему доступ.'],['Thanks. Could you zoom in on the chart?','Спасибо. Можете увеличить диаграмму?'],['Of course. Is this better?','Конечно. Так лучше?'],['Yes, we can see the figures now.','Да, теперь мы видим цифры.']]},
 {title:'Уточнение условий договора',level:'C1',turns:[['There seems to be some ambiguity in clause seven.','В седьмом пункте, похоже, есть некоторая неоднозначность.'],['Which part would you like us to clarify?','Какую часть вы хотели бы уточнить?'],['The wording does not specify who bears the additional costs.','Формулировка не указывает, кто несёт дополнительные расходы.'],['We could make that responsibility explicit.','Мы могли бы указать эту ответственность прямо.'],['That would prevent potential disputes later on.','Это позволило бы избежать возможных споров в дальнейшем.'],['I will send you a revised draft for review.','Я пришлю вам исправленный проект на согласование.']]},
];

/* New dialogues without reordering previously completed scenarios. */
dialogues.push({"title": "Возврат товара по гарантии", "level": "B1", "turns": [["The device stopped charging after a week.", "Устройство перестало заряжаться через неделю."], ["Do you have the proof of purchase?", "У вас есть подтверждение покупки?"], ["Yes, I can show you the receipt.", "Да, я могу показать чек."], ["We can arrange a warranty inspection.", "Мы можем организовать гарантийную проверку."], ["How long will it take?", "Сколько времени это займёт?"], ["Usually no more than five working days.", "Обычно не более пяти рабочих дней."]]},{"title": "Изменение доставки", "level": "A2", "turns": [["I need to change my delivery address.", "Мне нужно изменить адрес доставки."], ["Has your order been shipped yet?", "Ваш заказ уже отправили?"], ["Not yet, according to the website.", "Судя по сайту, ещё нет."], ["Please enter the new address here.", "Пожалуйста, укажите здесь новый адрес."], ["Will the delivery date change?", "Изменится ли дата доставки?"], ["It should stay the same.", "Она должна остаться прежней."]]},{"title": "Обсуждение графика", "level": "B2", "turns": [["The original deadline seems unrealistic.", "Первоначальный срок кажется нереалистичным."], ["Which tasks are causing the delay?", "Какие задачи вызывают задержку?"], ["Integration testing is taking longer than expected.", "Интеграционные тесты занимают больше времени, чем ожидалось."], ["Can we reduce the scope without affecting safety?", "Можем ли мы уменьшить объём работ без ущерба безопасности?"], ["We can postpone two non-essential features.", "Мы можем отложить две необязательные функции."], ["That sounds like a sensible compromise.", "Это кажется разумным компромиссом."]]},{"title": "Объяснение научной статьи", "level": "C1", "turns": [["What is the central claim of the study?", "Каков основной тезис исследования?"], ["The authors propose a link, not a proven cause.", "Авторы предполагают связь, а не доказанную причину."], ["How strong is the supporting evidence?", "Насколько убедительны подтверждающие данные?"], ["The sample is small and the findings are preliminary.", "Выборка небольшая, а выводы предварительные."], ["Could the results have another explanation?", "Может ли у результатов быть другое объяснение?"], ["Yes, several confounding factors remain unresolved.", "Да, несколько смешивающих факторов остаются неучтёнными."]]},{"title": "Знакомство с соседями", "level": "A1", "turns": [["Hello, I have just moved in.", "Здравствуйте, я только что переехал."], ["Welcome to the building!", "Добро пожаловать в наш дом!"], ["Is there a laundry room here?", "Здесь есть прачечная?"], ["Yes, it is on the ground floor.", "Да, она на первом этаже."], ["Thank you for your help.", "Спасибо за помощь."], ["You are very welcome.", "Всегда пожалуйста."]]});
dialogues.push(...(window.ENGLISH_SPOKEN?.dialogues||[]));
const irregular=[['be','was/were','been','быть'],['become','became','become','становиться'],['begin','began','begun','начинать'],['break','broke','broken','ломать'],['bring','brought','brought','приносить'],['build','built','built','строить'],['buy','bought','bought','покупать'],['catch','caught','caught','ловить'],['choose','chose','chosen','выбирать'],['come','came','come','приходить'],['cost','cost','cost','стоить'],['cut','cut','cut','резать'],['do','did','done','делать'],['draw','drew','drawn','рисовать'],['drink','drank','drunk','пить'],['drive','drove','driven','водить'],['eat','ate','eaten','есть'],['fall','fell','fallen','падать'],['feel','felt','felt','чувствовать'],['find','found','found','находить'],['fly','flew','flown','летать'],['forget','forgot','forgotten','забывать'],['get','got','got/gotten','получать'],['give','gave','given','давать'],['go','went','gone','идти'],['grow','grew','grown','расти'],['have','had','had','иметь'],['hear','heard','heard','слышать'],['hold','held','held','держать'],['keep','kept','kept','хранить'],['know','knew','known','знать'],['leave','left','left','покидать'],['lose','lost','lost','терять'],['make','made','made','делать'],['meet','met','met','встречать'],['pay','paid','paid','платить'],['put','put','put','класть'],['read','read','read','читать'],['ride','rode','ridden','ехать верхом'],['ring','rang','rung','звонить'],['run','ran','run','бежать'],['say','said','said','сказать'],['see','saw','seen','видеть'],['sell','sold','sold','продавать'],['send','sent','sent','посылать'],['sing','sang','sung','петь'],['sit','sat','sat','сидеть'],['sleep','slept','slept','спать'],['speak','spoke','spoken','говорить'],['spend','spent','spent','тратить'],['stand','stood','stood','стоять'],['swim','swam','swum','плавать'],['take','took','taken','брать'],['teach','taught','taught','учить'],['tell','told','told','рассказывать'],['think','thought','thought','думать'],['understand','understood','understood','понимать'],['wear','wore','worn','носить'],['win','won','won','побеждать'],['write','wrote','written','писать']];
const pronunciation=[
 ['th /θ/','think, three, thanks','Поставьте кончик языка между зубами и произнесите глухой звук, без русского «с».'],
 ['th /ð/','this, they, mother','Тот же положение языка, но с голосом.'],
 ['w /w/','water, window, work','Округлите губы, не касаясь нижней губы верхними зубами.'],
 ['v /v/','very, visit, voice','Верхние зубы касаются нижней губы. Отличайте от /w/.'],
 ['r /ɹ/','red, right, around','Кончик языка не вибрирует как русский «р».'],
 ['æ /æ/','cat, bad, apple','Широкий передний гласный, между «э» и «а».'],
 ['ɪ /ɪ/','sit, ship, live','Короткий звук; отличайте ship от sheep.'],
 ['iː /iː/','see, green, sheep','Долгий звук; не заменяйте коротким /ɪ/.'],
 ['ʌ /ʌ/','cup, love, enough','Краткий центральный гласный; буква u не гарантирует этот звук.'],
 ['ə /ə/','about, banana, support','Шва — редуцированный безударный гласный.'],
 ['ŋ /ŋ/','sing, long, thinking','Носовой звук на конце без отдельного «г» в sing.'],
 ['tʃ /tʃ/','chair, choose, watch','Слитный аффрикат, похожий на «ч».'],
 ['dʒ /dʒ/','job, general, bridge','Звонкая аффриката, не равна простой «ж».'],
 ['Словесное ударение','PREsent / preSENT, REcord / reCORD','У некоторых пар существительное и глагол различаются ударением.'],
 ['Связная речь','want to → wanna, going to → gonna','Разговорные сокращения полезно распознавать на слух; для официального письма используйте полные формы.'],
];
const numbers=[['17','seventeen'],['40','forty'],['58','fifty-eight'],['100','one hundred'],['105','one hundred and five'],['250','two hundred and fifty'],['1 000','one thousand'],['1 205','one thousand two hundred and five'],['10 000','ten thousand'],['100 000','one hundred thousand'],['1 000 000','one million'],['1 500 000','one million five hundred thousand'],['08:30','eight thirty'],['19:45','seven forty-five pm'],['£12.50','twelve pounds fifty'],['$25.99','twenty-five dollars and ninety-nine cents'],['3rd','third'],['21st','twenty-first'],['2026','twenty twenty-six']];
const grammar=[
 {title:'Порядок слов',body:'Утверждение: подлежащее + сказуемое + дополнение: She reads books. Вопрос с do/does/did: Does she read books? Без подлежащего английское предложение обычно не обходится.'},
 {title:'To be',body:'Present: I am, he/she/it is, you/we/they are. Past: I/he/she/it was; you/we/they were. Для отрицаний добавьте not, для вопроса поставьте форму перед подлежащим.'},
 {title:'Артикли',body:'a/an обозначают один неопределённый исчисляемый предмет; the — конкретный. An выбирается по гласному звуку: an hour, a university. С большинством неисчисляемых слов артикль a/an не употребляется.'},
 {title:'Present Simple',body:'Факты и привычки: I work, he works. Отрицание: I do not work; she does not work. Вопрос: Do you work? Does he work? Сигналы: usually, often, every day.'},
 {title:'Present Continuous',body:'am/is/are + V-ing: I am working now. Используется для действий сейчас и временных ситуаций. Глаголы состояния know, want, believe обычно не применяются в Continuous.'},
 {title:'Past Simple',body:'Прошедшие завершённые действия: worked, went. Вопрос: Did you go? Отрицание: I did not go. Сигналы: yesterday, last year, in 2020.'},
 {title:'Future',body:'Will — решение сейчас, обещание или прогноз: I will call. Be going to — намерение/признаки: I am going to call. Present Continuous — согласованный план: We are meeting tomorrow.'},
 {title:'Present Perfect',body:'Have/has + третья форма: I have finished. Результат сейчас и жизненный опыт; часто already, yet, ever, never, since, for. Не путать с Past Simple при конкретном прошлом времени.'},
 {title:'Past Continuous / Perfect',body:'Past Continuous: was/were + -ing — процесс в прошлом. Past Perfect: had + V3 — событие раньше другого прошедшего события.'},
 {title:'Модальные глаголы',body:'Can/could — возможность/вежливый запрос, must — обязанность или логический вывод, have to — необходимость, should — совет, might — вероятность. После модальных глаголов идёт основная форма без to, кроме have to.'},
 {title:'Условные предложения',body:'First: If + Present, will + V (вероятно). Second: If + Past, would + V (нереально сейчас). Third: If + had + V3, would have + V3 (не сбылось в прошлом).'},
 {title:'Passive Voice',body:'be + V3: The letter was sent. Сохраняйте время в форме be: is made, was made, has been made, is being made.'},
 {title:'Неправильные глаголы',body:'Past Simple использует вторую форму (go → went). Perfect и passive используют третью (go → gone, write → written). См. полный справочник в этой вкладке.'},
 {title:'Gerund / Infinitive',body:'enjoy + V-ing, want + to V, decide + to V, avoid + V-ing. Значение может меняться: stop smoking — бросить курить; stop to smoke — остановиться, чтобы покурить.'},
 {title:'Предлоги времени',body:'at 9 o’clock, on Monday, in April, in 2026, for two years, since 2020. For — продолжительность; since — отправная точка.'},
 {title:'Британский и американский',body:'UK: colour, centre, travelling, lift, flat, holiday. US: color, center, traveling, elevator, apartment, vacation. Выбор акцента в настройках влияет только на голос, а не на правильность написания.'}
];
const extraIrregular=[
['arise','arose','arisen','возникать'],['beat','beat','beaten','бить; побеждать'],['bend','bent','bent','сгибать'],['bet','bet','bet','держать пари'],['bite','bit','bitten','кусать'],['blow','blew','blown','дуть'],['burn','burned/burnt','burned/burnt','жечь; гореть'],['burst','burst','burst','лопаться'],['deal','dealt','dealt','иметь дело'],['dig','dug','dug','копать'],['dream','dreamed/dreamt','dreamed/dreamt','видеть сон'],['feed','fed','fed','кормить'],['fight','fought','fought','бороться'],['freeze','froze','frozen','замерзать'],['hang','hung','hung','вешать'],['hide','hid','hidden','прятать'],['hit','hit','hit','ударять'],['hurt','hurt','hurt','причинять боль'],['lay','laid','laid','класть'],['lead','led','led','вести'],['lend','lent','lent','одалживать'],['let','let','let','позволять'],['lie','lay','lain','лежать'],['light','lit','lit','зажигать'],['mean','meant','meant','означать'],['mistake','mistook','mistaken','ошибочно принимать'],['rise','rose','risen','подниматься'],['seek','sought','sought','искать'],['set','set','set','устанавливать'],['shake','shook','shaken','трясти'],['shine','shone/shined','shone/shined','сиять'],['shoot','shot','shot','стрелять'],['shut','shut','shut','закрывать'],['sink','sank','sunk','тонуть'],['slide','slid','slid','скользить'],['smell','smelled/smelt','smelled/smelt','пахнуть'],['speed','sped/speeded','sped/speeded','ускоряться'],['spill','spilled/spilt','spilled/spilt','проливать'],['steal','stole','stolen','красть'],['stick','stuck','stuck','приклеивать; застревать'],['strike','struck','struck','ударять; бастовать'],['sweep','swept','swept','подметать'],['tear','tore','torn','рвать'],['throw','threw','thrown','бросать'],['wake','woke','woken','просыпаться'],['weep','wept','wept','плакать'],['withdraw','withdrew','withdrawn','снимать деньги; отступать'],['forbid','forbade','forbidden','запрещать']
];
for(const v of extraIrregular){if(!irregular.some(x=>x[0]===v[0]))irregular.push(v)}
irregular.sort((a,b)=>a[0].localeCompare(b[0]));
const allPairs=lessons.flatMap(l=>l.examples.map((x,i)=>({...x,id:l.id+'-'+i,level:l.level,topic:l.title})));
window.ENGLISH_COURSE=Object.freeze({lessons,dialogues,irregular,pronunciation,numbers,grammar,allPairs});
})();
