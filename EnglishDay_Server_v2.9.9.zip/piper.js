/* Optional Piper neural TTS adapter for EnglishDay.
 * Piper implementation: @jtsage/piper-tts-web 1.2.0 (MIT), lazily imported only after user's action.
 * First use needs internet to retrieve the ESM runtime and ~60 MB model (rhasspy/piper-voices).
 * Model binaries are held by the browser's Origin Private File System, not stored on this web server.
 * No voice inference service, user text is processed locally after runtime/model loading.
 */
window.ENGLISH_PIPER=(()=>{
 'use strict';
 const MODULE_URL='https://esm.sh/@jtsage/piper-tts-web@1.2.0?bundle';
 const SUPPORTED={
  'en_US-hfc_female-medium':'Английский США · женский (HFC Female)',
  'en_US-lessac-medium':'Английский США · женский (Lessac)',
  'en_GB-alan-medium':'Английский Великобритании · мужской (Alan)'
 };
 let modulePromise=null, audio=null, currentUrl=null, cancelToken=0, release=null;
 function isSecure(){return location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1';}
 function ensureAvailable(){
  if(!isSecure()||!navigator.storage?.getDirectory)throw new Error('Piper требует HTTPS и поддержку локального хранилища OPFS. В автономном HTML используйте системный голос.');
 }
 async function library(){
  ensureAvailable();
  if(!modulePromise){modulePromise=import(MODULE_URL).catch(e=>{modulePromise=null;throw new Error('Не удалось загрузить движок Piper. Проверьте интернет и блокировку CDN: '+(e?.message||e));});}
  return modulePromise;
 }
 function stop(){
  cancelToken++;
  if(audio){audio.pause();audio.removeAttribute('src');audio.load();audio=null;}
  if(currentUrl){URL.revokeObjectURL(currentUrl);currentUrl=null;}
  if(release){const resolve=release;release=null;resolve();}
 }
 async function stored(){
  const mod=await library(); const voices=await mod.stored(); return Array.isArray(voices)?voices:[];
 }
 async function install(id,progress){
  if(!Object.hasOwn(SUPPORTED,id))throw Error('Неизвестный голосовой пакет');
  const mod=await library();
  await mod.download(id,(p)=>{if(typeof progress==='function')progress(p);});
  if(!(await stored()).includes(id))throw Error('Модель не появилась в хранилище. Проверьте свободное место.');
  return true;
 }
 async function remove(id){
  if(!Object.hasOwn(SUPPORTED,id))throw Error('Неизвестный голосовой пакет');
  stop();const mod=await library(); await mod.remove(id);return true;
 }
 function pause(){if(audio&&!audio.paused){audio.pause();return true;}return false;}
 function resume(){if(audio&&audio.paused){audio.play().catch(()=>{});return true;}return false;}
 async function speak(text,{voiceId='en_US-hfc_female-medium',rate=1,onstart,onend,onerror}={}){
  if(!Object.hasOwn(SUPPORTED,voiceId))throw Error('Выберите подходящий голос Piper');
  stop();const token=cancelToken;
  try{
   const mod=await library();
   if(!((await mod.stored())||[]).includes(voiceId))throw new Error('Голосовой пакет не загружен. Откройте «Настройки» → «Загрузить голосовой пакет».');
   const wav=await mod.predict({text:String(text).slice(0,1800),voiceId});
   if(token!==cancelToken)return;
   currentUrl=URL.createObjectURL(wav);
   audio=new Audio(currentUrl);
   audio.preload='auto';
   audio.playbackRate=Math.max(.5,Math.min(1.5,Number(rate)||1));
   await new Promise((resolve,reject)=>{
    release=resolve;
    audio.onended=()=>{if(token!==cancelToken)return;stop();onend?.();resolve();};
    audio.onerror=()=>{const err=Error('Не удалось воспроизвести созданный Piper звук');release=null;stop();reject(err);};
    audio.onplay=()=>{if(token===cancelToken)onstart?.();};
    audio.play().catch(err=>{release=null;stop();reject(err);});
   });
  }catch(e){if(token===cancelToken){onerror?.(e);}throw e;}
 }
 return {supported:SUPPORTED,isSecure,stored,install,remove,speak,pause,resume,stop};
})();
