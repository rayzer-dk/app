'use strict';

function makeInstallState(isStandalone=()=>false){
 let offer=null,installed=false,busy=false;
 return {
  offer(event){offer=event;},
  installed(){installed=true;offer=null;},
  mode(){return installed||isStandalone()?'installed':busy?'busy':offer?'prompt':'manual';},
  async request(){
   if(!offer||busy)return 'manual';
   const prompt=offer;offer=null;busy=true;
   try{
    const result=await prompt.prompt();
    return (result?.outcome??(await prompt.userChoice)?.outcome)==='accepted'?'accepted':'dismissed';
   }catch{return 'manual';}
   finally{busy=false;}
  }
 };
}

function platform(nav){
 if(/Android/i.test(nav.userAgent))return 'android';
 if(/iPad|iPhone|iPod/i.test(nav.userAgent)||/Macintosh/i.test(nav.userAgent)&&nav.maxTouchPoints>1)return 'apple';
 return 'desktop';
}

async function checkRelease(current,entry,request=globalThis.fetch){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);timer?.unref?.();
 const valid=v=>typeof v==='string'&&/^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(v);
 try{
  const response=await request(new URL('release.json',entry),{cache:'no-store',credentials:'same-origin',redirect:'error',signal:controller.signal});
  if(!response.ok||!response.headers.get('content-type')?.includes('application/json'))return false;
  const {app,version}=await response.json();
  if(app!=='EnglishDay'||!valid(version)||!valid(current))return false;
  const base=current.split('.').map(Number),next=version.split('.').map(Number),i=next.findIndex((n,i)=>n!==base[i]);
  return i>=0&&next[i]>base[i]?version:null;
 }catch{return false;}finally{clearTimeout(timer);}
}

function installButton(mode,kind){
 if(mode==='installed')return '<span class="install-ready">Приложение установлено</span>';
 return '<button class="btn primary install-cta" type="button" data-pwa-prompt aria-expanded="false"'+(mode==='busy'?' disabled':'')+'>'+(mode==='busy'?'Ожидаем подтверждение…':kind==='settings'?'Установить на устройство':'Установить EnglishDay')+'</button>';
}

if(typeof module==='object')module.exports={makeInstallState,platform,checkRelease,installButton};

if(typeof window==='object')(()=>{
 const version=document.querySelector('meta[name="englishday-version"]').content;
 const standalone=window.matchMedia('(display-mode: standalone)');
 const state=makeInstallState(()=>standalone.matches||navigator.standalone===true);
 const local=location.protocol==='file:',secure=window.isSecureContext&&!local;
 const entry=new URL('./',location.href).href;
 let offline=secure?'loading':'unavailable',showHelp=false,release=null,releaseStatus='idle';
 const tips={
  android:'В Chrome откройте меню ⋮ и выберите «Установить приложение» или «Добавить на главный экран». Если страница открыта внутри другого приложения, сначала откройте её в Chrome.',
  apple:'В Safari нажмите «Поделиться», выберите «На экран Домой» и нажмите «Добавить».',
  desktop:'В Chrome или Edge откройте меню браузера и выберите установку сайта как приложения. Команда также может быть в адресной строке.'
 };
 const offlineMessage={
  ready:'Учебные материалы доступны без интернета.',
  loading:'Проверяем готовность офлайн-копии…',
  unavailable:'Офлайн-копия пока недоступна.'
 };
 const messages={
  idle:'Проверьте, есть ли новая версия.',
  checking:'Проверяем…',
  current:'У вас актуальная версия.',
  error:'Не удалось проверить. Проверьте подключение и повторите.',
  applying:'Открываем новую версию…'
 };
 function updatePanel(){
  const slot=document.querySelector('[data-pwa-update]');if(!slot)return;
  const status=slot.querySelector('[data-release-status]');
  const button=slot.querySelector('[data-release-action]');
  const message=local?'Для обновления замените этот HTML-файл новой копией.':releaseStatus==='available'?'Доступна версия '+release+'.':messages[releaseStatus];
  if(status.textContent!==message)status.textContent=message;
  button.hidden=local;
  button.setAttribute('aria-disabled',String(['checking','applying'].includes(releaseStatus)));
  button.textContent=releaseStatus==='available'?'Обновить до '+release:'Проверить обновление';
 }
 function refresh(){
  const mode=state.mode();
  for(const slot of document.querySelectorAll('[data-pwa-install]')){
   const kind=slot.dataset.pwaInstall,key=[mode,kind,offline,showHelp].join(':');
   if(slot.dataset.pwaState===key)continue;
   slot.dataset.pwaState=key;
   if(!secure){
    slot.hidden=kind!=='settings';
    slot.innerHTML=kind==='settings'?'<p class="small-note">'+(local?'Вы открыли автономный HTML-файл. Для установки откройте EnglishDay на сайте по HTTPS.':'Для установки откройте этот адрес по HTTPS.')+'</p>':'';
    continue;
   }
   slot.hidden=false;
   const id='install-help-'+kind,focused=slot.contains(document.activeElement);
   slot.innerHTML=installButton(mode,kind)+(mode==='installed'?'':'<p class="install-help" id="'+id+'" tabindex="-1" '+(showHelp?'':'hidden')+'>'+tips[platform(navigator)]+'</p>')+
    (kind==='settings'?'<p class="small-note" role="status">'+offlineMessage[offline]+'</p>':'');
   const trigger=slot.querySelector('[data-pwa-prompt]');
   if(trigger){trigger.setAttribute('aria-controls',id);trigger.setAttribute('aria-expanded',String(showHelp));}
   if(focused&&trigger&&!trigger.disabled)trigger.focus({preventScroll:true});
  }
  updatePanel();
 }
 window.ENGLISH_PWA={refresh};
 window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();state.offer(event);refresh();});
 window.addEventListener('appinstalled',()=>{state.installed();showHelp=false;refresh();});
 standalone.addEventListener?.('change',refresh);
 document.addEventListener('click',async event=>{
  const trigger=event.target.closest?.('[data-pwa-prompt]');
  if(trigger){
   const kind=trigger.closest('[data-pwa-install]').dataset.pwaInstall;
   if(state.mode()==='manual')showHelp=!showHelp;
   else{
    const result=state.request();showHelp=false;refresh();
    showHelp=(await result)!=='accepted'&&state.mode()!=='installed';
   }
   refresh();
   if(showHelp)document.querySelector('#install-help-'+kind)?.focus();
   return;
  }
  if(!event.target.closest?.('[data-release-action]')||local||['checking','applying'].includes(releaseStatus))return;
  if(releaseStatus==='available'){
   releaseStatus='applying';updatePanel();
   const next=new URL(entry);next.searchParams.set('v',release);next.hash=location.hash;location.assign(next.href);return;
  }
  releaseStatus='checking';updatePanel();
  release=await checkRelease(version,entry);
  releaseStatus=release===false?'error':release?'available':'current';
  updatePanel();
 });
 async function checkOffline(missing='loading'){
  try{
   const response=await window.caches?.match(new URL('vendor/offline-'+version+'.txt',entry).href,{ignoreSearch:true});
   offline=response?.ok?'ready':missing;
  }catch{offline='unavailable';}
  refresh();
 }
 function unavailable(){offline='unavailable';refresh();}
 if(secure&&'serviceWorker' in navigator){
  const workers=navigator.serviceWorker;
  workers.addEventListener('controllerchange',()=>void checkOffline());
  workers.register('./service-worker.js',{updateViaCache:'none'}).then(reg=>{
   const watch=()=>{
    const worker=reg.installing;
    worker?.addEventListener('statechange',()=>{
     if(worker.state==='redundant')void checkOffline('unavailable');
    });
   };
   watch();
   reg.addEventListener('updatefound',watch);
   return workers.ready;
  }).then(()=>checkOffline()).catch(unavailable);
 }else unavailable();
})();
