importScripts('./vendor/workbox-7.4.0.js');
const {clientsClaim,setCacheNameDetails,PrecacheController,PrecacheRoute,registerRoute}=OfflineWorkbox;
const release='2.9.9',scope=self.registration.scope;
const home=new URL(scope);
setCacheNameDetails({prefix:'englishday-workbox',suffix:scope});
const precache=new PrecacheController({plugins:[{
 async cacheWillUpdate({response,request}){
  if(!response.ok||response.redirected)return null;
  return new URL(request.url).pathname!==home.pathname||await appPage(response,release)?response:null;
 }
}]});
precache.precache([{"url":"./","revision":"aeee990ff96aa6997b7a8251"},{"url":"vendor/offline-2.9.9.txt","revision":"13363936849fa27c3d7a1246","integrity":"sha256-EzY5NoSfonw9ehJGOxQ2SxESE8lFKLUSC91XJR2ULTM="},{"url":"app.js?v=2.9.9","revision":"a709dd94ddcb31e15be1ab24","integrity":"sha256-pwndlN3LMeFb4askHHjaACQw3W53aAHT7nlG3j1hGug="},{"url":"brand.webp?v=2.9.9","revision":"62724de8e3596ca2ec853f09","integrity":"sha256-YnJN6ONZbKLshT8JJgM5na4/FQpP5WyerP/WIMwKGSs="},{"url":"cloud.js?v=2.9.9","revision":"ca2eb657acfd09a3c5d681e1","integrity":"sha256-yi62V6z9CaPF1oHhPAv3ZWaPHGPAzlJ6Zj/U8zVpChc="},{"url":"course.js?v=2.9.9","revision":"cc53b5d89533697ad51482b5","integrity":"sha256-zFO12JUzaXrVFIK1OkSuL5W85Iflr7cavRq7m95v7mc="},{"url":"dialogues-240.js?v=2.9.9","revision":"caabdf743c0ba59977132ca8","integrity":"sha256-yqvfdDwLpZl3EyyoqvBH3Iigh4et14rU9D5/ovPXDn8="},{"url":"exam-data.js?v=2.9.9","revision":"97feb94796d6e676a8c5c2ae","integrity":"sha256-l/65R5bW5naoxcKudTXIVTzhXuynbHKJTSlMGtdLVlE="},{"url":"favicon.png?v=2.9.9","revision":"91dba082bb973c0e55b133cc","integrity":"sha256-kduggruXPA5VsTPMkp+C+d/Fh/gSxzZZZqoa2TYmoII="},{"url":"grammar.js?v=2.9.9","revision":"aa48a18c7265f34f14301dcb","integrity":"sha256-qkihjHJl808UMB3LwM+idL5iwd1m6IDhGV6D9Eq6yu4="},{"url":"icon-192.png?v=2.9.9","revision":"db5f1a69892af7b15239a9a6","integrity":"sha256-218aaYkq97FSOammyIGHzZd5tlOsX2CammKPmfJWJ54="},{"url":"icon-512-maskable.png","revision":"07363c8ff3be4b3f652eb4c1","integrity":"sha256-BzY8j/O+Sz9lLrTBu5i21AbGUA+KRYVAAip2QR3sZ0U="},{"url":"icon-512.png","revision":"5e4aea6e956e0f0bb1246d18","integrity":"sha256-XkrqbpVuDwuxJG0Y/cQcivTieZ2AxC+Vo4eMHmlz99g="},{"url":"icons.js?v=2.9.9","revision":"303a0177407ef61f0345df1e","integrity":"sha256-MDoBd0B+9h8DRd8eWKITL2U9brnhE7DP8WdycgMkz28="},{"url":"long-readings.js?v=2.9.9","revision":"266131f1e1122cca853b833e","integrity":"sha256-JmEx8eESLMqFO4M+X4Pc2lD8t3bhbsfxzThjFwfAMcw="},{"url":"manifest.webmanifest?v=2.9.9","revision":"6e230642926307ffadb367a4","integrity":"sha256-biMGQpJjB/+ts2ekO5JOzLBJ20Ibj6gMIqgfls0JO0M="},{"url":"piper.js?v=2.9.9","revision":"99ae6d0f2683b1d74b5cb8ce","integrity":"sha256-ma5tDyaDsddLXLjOGIrSU8t4NOprWrv/3KdkmA/CIro="},{"url":"pwa.js?v=2.9.9","revision":"1bfdf05e3b7f0ee72de15ae8","integrity":"sha256-G/3wXjt/Duct4VroefEyApBJbC80uUdLmLW6KHKTVys="},{"url":"reading.js?v=2.9.9","revision":"078db94cf30310ae79a3da8f","integrity":"sha256-B425TPMDEK55o9qPNkzS6IJFzlYQzUVkJ7r3Sjf5xvY="},{"url":"readings-240.js?v=2.9.9","revision":"d036594b353103e45c624bac","integrity":"sha256-0DZZSzUxA+RcYkusm0DY1jqEfl3nuoU/c7HKOMJyESg="},{"url":"reference.js?v=2.9.9","revision":"948ce5b10fc16e53d3f11d19","integrity":"sha256-lIzlsQ/BblPT8R0Zv2k8jYInh84SV9b20td9fSJW0Jk="},{"url":"spoken.js?v=2.9.9","revision":"a28591434b5ffc3ec1a45e58","integrity":"sha256-ooWRQ0tf/D7BpF5YbnTeEwOtMPwd8jgeRlrdkbG835Q="},{"url":"style.css?v=2.9.9","revision":"9530d501c6882d206d18e676","integrity":"sha256-lTDVAcaILSBtGOZ2hhJUOEIomP4hYdOttJgjKhsid00="},{"url":"vocabulary-240.js?v=2.9.9","revision":"407adf5d26080c706e434c83","integrity":"sha256-QHrfXSYIDHBuQ0yDjH7BGn4PEPsnIeoRvz7AMAFNcJY="},{"url":"vocabulary-250.js?v=2.9.9","revision":"5e03a5e894ceb5f9a16ff11a","integrity":"sha256-XgOl6JTOtfmhb/EaS8SFT5kDC66YUNefWlxYMzCPH9c="},{"url":"workplace.js?v=2.9.9","revision":"3bde78114e38d79031323f1d","integrity":"sha256-O954EU4415AxMj8dVqZN0zktaZMtt7rBuv0ndhHZoeg="},{"url":"icon-512.png?v=2.9.9","revision":"5e4aea6e956e0f0bb1246d18","integrity":"sha256-XkrqbpVuDwuxJG0Y/cQcivTieZ2AxC+Vo4eMHmlz99g="},{"url":"icon-512-maskable.png?v=2.9.9","revision":"07363c8ff3be4b3f652eb4c1","integrity":"sha256-BzY8j/O+Sz9lLrTBu5i21AbGUA+KRYVAAip2QR3sZ0U="}]);
async function appPage(response,expected){
 if(!response?.ok||response.redirected||!/^text\/html\b/i.test(response.headers.get('content-type')||''))return false;
 const version=/<meta name="englishday-version" content="(\d+\.\d+\.\d+)">/.exec(await response.clone().text())?.[1];
 return Boolean(version)&&(!expected||version===expected);
}
registerRoute(({request,url,sameOrigin})=>sameOrigin&&request.mode==='navigate'&&(url.pathname===home.pathname||url.pathname===home.pathname+'index.html'),
 async ({request,url})=>{
  // Only explicit update links consult the network. Regular sessions boot the installed release.
  const requested=url.searchParams.get('v');
  if(/^\d+\.\d+\.\d+$/.test(requested||'')&&requested!==release){
   const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),5000);
   try{
    const target=new URL(scope);target.searchParams.set('v',requested);
    const latest=await fetch(target,{cache:'no-cache',credentials:'same-origin',signal:abort.signal});
    if(await appPage(latest,requested))return latest;
   }catch{}finally{clearTimeout(timer);}
  }
  return await precache.matchPrecache(scope)||fetch(request);
 });
registerRoute(new PrecacheRoute(precache,{directoryIndex:null,cleanURLs:false}));
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
clientsClaim();
