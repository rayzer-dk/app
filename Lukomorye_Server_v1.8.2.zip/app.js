/* Лукоморье — встроенные оригиналы + личная офлайн-библиотека; расширенные
   произведения загружаются из первоисточника только по явному действию. */
(()=>{'use strict';
const ICON_PATHS={"book":"<path d=\"M3 19.2V5.5C3 4.1 4 3.2 5.5 3.2c2.5 0 4.4.8 6.5 2.1 2.1-1.3 4-2.1 6.5-2.1 1.5 0 2.5.9 2.5 2.3v13.7c-3-.4-5.9.2-9 2-3.1-1.8-6-2.4-9-2Z\"/><path d=\"M12 5.3v15.9\"/>","home":"<path d=\"m3 10 9-7 9 7v10H3z\"/><path d=\"M9 20v-6h6v6\"/>","heart":"<path d=\"M20.8 8c0 4.4-8.8 11-8.8 11S3.2 12.4 3.2 8A4.8 4.8 0 0 1 12 5.5 4.8 4.8 0 0 1 20.8 8Z\"/>","settings":"<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"m19.6 12 1.1-2-2-3.5-2.3.1-1.2-.7L14 3.7h-4L8.8 6l-1.2.7-2.3-.1-2 3.5 1.1 2-1.1 2 2 3.5 2.3-.1 1.2.7L10 20.3h4l1.2-2.2 1.2-.7 2.3.1 2-3.5-1.1-2Z\"/>","search":"<circle cx=\"10.8\" cy=\"10.8\" r=\"6.8\"/><path d=\"m16 16 5 5\"/>","chevron-right":"<path d=\"m9 6 6 6-6 6\"/>","chevron":"<path d=\"m15 18-6-6 6-6\"/>","play":"<path d=\"m8 5 11 7-11 7z\"/>","pause":"<path d=\"M7 5h3v14H7zm7 0h3v14h-3z\"/>","stop":"<rect x=\"5\" y=\"5\" width=\"14\" height=\"14\" rx=\"2\"/>","volume":"<path d=\"M11 5 6.7 9H3v6h3.7l4.3 4zM15 9a4 4 0 0 1 0 6m2.8-9a8 8 0 0 1 0 12\"/>","edit":"<path d=\"M12 20h9\"/><path d=\"m16 4 4 4-11 11-5 1 1-5L16 4Z\"/>","bookmark":"<path d=\"M6 3.5h12a1 1 0 0 1 1 1V21l-7-4.5L5 21V4.5a1 1 0 0 1 1-1Z\"/>","plus":"<path d=\"M12 4v16M4 12h16\"/>","check":"<path d=\"m4 12 5 5L20 6\"/>","trash":"<path d=\"M4 7h16M9 7V4h6v3m-9 0 1 13h10l1-13M10 11v6m4-6v6\"/>","download":"<path d=\"M12 3v13m-5-5 5 5 5-5M4 18v3h16v-3\"/>","upload":"<path d=\"M12 19V6m-5 5 5-5 5 5M4 5V3h16v2\"/>","sun":"<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4\"/>","moon":"<path d=\"M20.7 14.4A8.7 8.7 0 0 1 9.6 3.3a8.7 8.7 0 1 0 11.1 11.1Z\"/>","x":"<path d=\"M5 5 19 19M19 5 5 19\"/>","external":"<path d=\"M14 4h6v6m0-6-9 9\"/><path d=\"M20 13v7H4V4h7\"/>","copy":"<rect x=\"8\" y=\"8\" width=\"12\" height=\"12\" rx=\"2\"/><path d=\"M16 8V4H4v12h4\"/>","info":"<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 11v6M12 7v.1\"/>","menu":"<path d=\"M4 6h16M4 12h16M4 18h16\"/>"};
ICON_PATHS.sliders='<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2" fill="currentColor" stroke="none"/><circle cx="16" cy="17" r="2" fill="currentColor" stroke="none"/>';
ICON_PATHS.share='<path d="M12 16V3m-4 4 4-4 4 4M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>';
ICON_PATHS.refresh='<path d="M20 10a8 8 0 0 0-13.7-4.6L4 8m0-5v5h5m-5 6a8 8 0 0 0 13.7 4.6L20 16m0 5v-5h-5"/>';
ICON_PATHS['help-circle']='<circle cx="12" cy="12" r="9"/><path d="M9.2 9a3 3 0 1 1 5.2 2.1c-1.3 1.1-2.4 1.7-2.4 3"/><circle cx="12" cy="17.7" r=".7" fill="currentColor" stroke="none"/>';
Object.assign(ICON_PATHS,{
 'library':'<path d="m3 7 5-2 5 2 5-2 3 1v13l-5-1-4 1-4-1-5 1V7Z"/><path d="M8 5v13m5-11v12m5-14v13"/>',
 'layers':'<path d="m12 2 9 5-9 5-9-5 9-5Zm-9 10 9 5 9-5M3 17l9 5 9-5"/>',
 'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
 'book-open':'<path d="M12 6c-2.8-2.4-6.1-2.7-9-2v14c3-.6 6.2-.2 9 2 2.8-2.2 6-2.6 9-2V4c-2.9-.7-6.2-.4-9 2Z"/><path d="M12 6v14"/>',
 'book-text':'<path d="M4 4h16v17H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Zm0 13h16M8 8h8m-8 4h6"/>',
 'globe':'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18M12 3c5 5 5 13 0 18"/>',
 'feather':'<path d="M20.5 3.5c-2.4-2.4-8.3-1.8-12 2-4.4 4.5-3.1 10.3-3.1 10.3s5.8 1.3 10.3-3.1c3.8-3.7 4.4-9.6 4.8-9.2ZM3 21l11-11M9 15l6 0"/>',
 'compass':'<circle cx="12" cy="12" r="9"/><path d="m15.8 8.2-2 5.6-5.6 2 2-5.6 5.6-2Z"/>',
 'check-circle':'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
 'panel-left':'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
 'list':'<path d="M9 6h12M9 12h12M9 18h12M4 6h.1M4 12h.1M4 18h.1"/>',
 'arrow-left':'<path d="m12 5-7 7 7 7M5 12h15"/>',
 'arrow-right':'<path d="m12 5 7 7-7 7M19 12H4"/>',
 'arrow-up-right':'<path d="M7 17 17 7M8 7h9v9"/>',
 'type':'<path d="m4 19 6-14h4l6 14M7 13h10M4 5h16"/>',
 'maximize':'<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3M21 16v3a2 2 0 0 1-2 2h-3"/>',
 'sparkles':'<path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3ZM19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/>',
 'check-check':'<path d="m3 12 4 4 6-7m0 6 3 3 6-8"/>',
 'sliders':'<path d="M4 7h7m5 0h4M4 17h4m5 0h7"/><circle cx="13" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
 'bookmark-check':'<path d="M6 3.5h12a1 1 0 0 1 1 1V21l-7-4.5L5 21V4.5a1 1 0 0 1 1-1Z"/><path d="m9 10 2 2 4-4"/>'
});
ICON_PATHS.minimize='<path d="M8 3v5H3m13 13v-5h5M3 16h5v5m13-13h-5V3"/>';
const icon=(name,size=18)=>`<svg class="lucide-icon" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICON_PATHS[name]||ICON_PATHS.book}</svg>`;
const categoryIcon={'Русские народные':'book-open','Сказки писателей':'feather','Сказки мира':'globe','Басни':'book-text','Детские рассказы':'book','Приключения':'compass','Поучительные сказки':'book-text','Мои книги':'library'};
function hydrateIcons(){document.querySelectorAll('[data-icon]').forEach(node=>{const name=node.dataset.icon;if(!node.querySelector('svg'))node.innerHTML=icon(name)})}

const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const APP_VERSION='1.8.2';
const BOOKS=window.LUKO_CATALOG||[];
const EMBEDDED=window.LUKO_OFFLINE_TEXTS||{};
const embeddedIds=new Set(Object.keys(EMBEDDED));
const fileEdition=window.LUKO_STANDALONE===true||location.protocol==='file:';
const catalogById=new Map(BOOKS.map(book=>[book.id,book]));
const catalogIds=new Set(catalogById.keys());
const categories=['Русские народные','Сказки писателей','Приключения','Детские рассказы','Поучительные сказки','Сказки мира','Басни','Мои книги'];
const visual={
 'Русские народные':['#e9eae0','#54715d'], 'Сказки писателей':['#f0e1d4','#a56e4b'], 'Сказки мира':['#e3e9f3','#6478a4'],
 'Басни':['#f3e7cb','#a6874b'], 'Детские рассказы':['#e6ecdf','#71945b'], 'Приключения':['#e9e5ef','#8571ac'], 'Мои книги':['#dcebed','#4e9290']};
const defaultSettings={font:22,line:'1.85',theme:'light',speed:120,paper:'auto',wide:false,paperBg:'#f7edda',paperText:'#38291b',fontFamily:'serif'};
const safeSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){console.warn('Local save unavailable:',e)}};
const sessionTexts=new Map();
const savedWords=new Map();
const embeddedWords=new Map();
const readLocal=(k,fallback)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):fallback}catch{return fallback}};
let settings=Object.assign({},defaultSettings,readLocal('luko-settings',{}));
let progress=validProgress(readLocal('luko-progress',{}));
let favorites=new Set(validFavorites(readLocal('luko-favorites',[])));
function validBookId(id){return typeof id==='string'&&(catalogIds.has(id)||/^local-[a-z0-9-]{1,90}$/i.test(id))}
function validFavorites(items){return Array.isArray(items)?items.filter(validBookId):[]}
function validProgress(items){
 if(!items||typeof items!=='object'||Array.isArray(items))return {};
 const records=Object.entries(items).filter(([id,p])=>validBookId(id)&&p&&typeof p==='object'&&!Array.isArray(p));
 return Object.fromEntries(records.map(([id,p])=>[id,{
  done:p.done===true,
  percent:p.done===true?100:Math.max(0,Math.min(100,Number(p.percent)||0)),
  index:Number.isSafeInteger(p.index)&&p.index>=0?p.index:0,
  updated:Number.isFinite(p.updated)&&p.updated>0?p.updated:0,
  words:Number.isSafeInteger(p.words)&&p.words>0?p.words:undefined,
  textRevision:Number.isSafeInteger(p.textRevision)?p.textRevision:0,
 }]));
}
let books=[...BOOKS],cachedIds=new Set(embeddedIds),db=null,view='all',pageLimit=24,current=null,currentDoc=null,searchText='',timeFilter='all',ageFilter='all',sortBy='popular',countryFilter='all',lastVisible=[];
let bulkDownloading=false,stopBulk=false,scrollTimer=0,toastTimer=0,loadingToken=0,deferredInstall=null,ttsActive=false,ttsParagraph=0,ttsUtterance=null,importedBooks=[];
let readerOrder=[],homeAfterReader=false;
const downloads=new Map();
const storedFailures=readLocal('luko-download-errors',[]);
const downloadFailures=new Map(
 Array.isArray(storedFailures)?storedFailures.filter(item=>Array.isArray(item)&&catalogIds.has(item[0])&&typeof item[1]==='string'):[]
);
function saveDownloadFailures(){safeSet('luko-download-errors',JSON.stringify([...downloadFailures]))}
function forgetDownloadFailure(id){
 if(downloadFailures.delete(id))saveDownloadFailures();
}
function recordDownloadFailure(book,error){
 const message=error?.name==='TypeError'?'Не удалось подключиться к источнику.':String(error?.message||error);
 downloadFailures.set(book.id,message.slice(0,250));
 saveDownloadFailures();
}
function failedBooks(list=BOOKS){
 return list.filter(book=>!cachedIds.has(book.id)&&downloadFailures.has(book.id))
  .map(book=>({id:book.id,title:book.title,error:downloadFailures.get(book.id)}));
}
function downloadErrorReport(){
 const failed=failedBooks();
 if(failed.length)downloadJson('lukomorye-errors.json',{generated:new Date().toISOString(),failed});
}
function toast(s){const el=$('#toast');el.textContent=s;el.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),3300)}
function saveSettings(){safeSet('luko-settings',JSON.stringify(settings));applySettings()}
function saveProgress(){safeSet('luko-progress',JSON.stringify(progress))}
function setFav(id){favorites.has(id)?favorites.delete(id):favorites.add(id);safeSet('luko-favorites',JSON.stringify([...favorites]));render();if(current?.id===id)updateReaderFav()}
function safeColor(v,fallback){return typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v)?v.toLowerCase():fallback}
function colorLum(hex){const ch=hex.slice(1).match(/../g).map(x=>parseInt(x,16)/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4);return .2126*ch[0]+.7152*ch[1]+.0722*ch[2]}
function contrast(a,b){const x=colorLum(a),y=colorLum(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05)}
function applySettings(){
 settings.font=Math.min(32,Math.max(17,Number(settings.font)||22));
 if(!['1.6','1.85','2.1'].includes(String(settings.line)))settings.line='1.85';
 if(!['light','sepia','dark'].includes(settings.theme))settings.theme='light';
 if(!['auto','light','sepia','dark','custom'].includes(settings.paper))settings.paper='auto';
 if(!['serif','georgia','sans'].includes(settings.fontFamily))settings.fontFamily='serif';
 settings.paperBg=safeColor(settings.paperBg,'#f7edda');settings.paperText=safeColor(settings.paperText,'#38291b');
 settings.wide=settings.wide===true;
 settings.speed=[95,120,150,180].includes(Number(settings.speed))?Number(settings.speed):defaultSettings.speed;
 document.body.dataset.theme=settings.theme;
 const themeIcon=$('#theme-toggle');if(themeIcon){themeIcon.innerHTML=icon(settings.theme==='dark'?'sun':'moon');themeIcon.setAttribute('aria-label',settings.theme==='dark'?'Включить светлую тему':'Переключить тему');}
 document.documentElement.style.setProperty('--fs',settings.font+'px');
 document.documentElement.style.setProperty('--lh',settings.line);
 const reader=$('#reader');reader.dataset.paper=settings.paper;reader.classList.toggle('wide-reading',settings.wide);
 reader.style.setProperty('--reading-font',settings.fontFamily==='sans'?"Manrope,Arial,sans-serif":settings.fontFamily==='georgia'?"Georgia,'Times New Roman',serif":"'PT Serif',Georgia,serif");
 if(settings.paper==='custom'){
  const value=contrast(settings.paperBg,settings.paperText);
  const ink=value<4.5?(contrast(settings.paperBg,'#17211b')>contrast(settings.paperBg,'#ffffff')?'#17211b':'#ffffff'):settings.paperText;
  reader.style.setProperty('--reading-bg',settings.paperBg);reader.style.setProperty('--reading-ink',ink);reader.style.setProperty('--aside',settings.paperBg);
  $('#contrast-note').textContent=value<4.5?'Недостаточный контраст: цвет текста скорректирован для чтения.':'Контраст текста: '+value.toFixed(1)+':1';
 }else{reader.style.removeProperty('--reading-bg');reader.style.removeProperty('--reading-ink');reader.style.removeProperty('--aside');}
 $('#font-size').value=settings.font;$('#font-out').textContent=settings.font;$('#quick-font-out').textContent=settings.font;$$('[data-quick-paper]').forEach(el=>el.classList.toggle('active',el.dataset.quickPaper===(settings.paper==='auto'?settings.theme:settings.paper)));$('#line-height').value=settings.line;$('#reading-speed').value=settings.speed;
 $('#paper-style').value=settings.paper;$('#paper-bg').value=settings.paperBg;$('#paper-text').value=settings.paperText;
 $('#reader-wide').checked=settings.wide;$('#reader-font').value=settings.fontFamily;
 $('#custom-colors').classList.toggle('hidden',settings.paper!=='custom');
 $$('[data-theme-option]').forEach(el=>el.classList.toggle('active',el.dataset.themeOption===settings.theme));
}
/* Keep the visible paragraph at the same place during layout changes. */
function keepReaderAnchor(fn){
 const sc=$('#reader-scroll');if($('#reader').classList.contains('hidden')||!currentDoc){fn();return}
 const nodes=$$('[data-para]',$('#reading-text'));const viewport=sc.getBoundingClientRect();
 let selected=nodes.find(n=>n.getBoundingClientRect().bottom>viewport.top+16);
 const delta=selected?selected.getBoundingClientRect().top-viewport.top:0;
 fn();requestAnimationFrame(()=>{if(!selected||!selected.isConnected)return;
  const prior=sc.style.scrollBehavior;sc.style.scrollBehavior='auto';
  sc.scrollTop+=selected.getBoundingClientRect().top-sc.getBoundingClientRect().top-delta;
  requestAnimationFrame(()=>{sc.style.scrollBehavior=prior;readingScroll()});});
}
let immersive=false;
async function setImmersive(on,requestNative=true){
 if($('#reader').classList.contains('hidden'))return;
 const reader=$('#reader');
 if(on)closeQuickPanel();
 if(immersive===on)return;
 keepReaderAnchor(()=>{immersive=on;reader.classList.toggle('immersive',on);$('#reader-immersive-enter').setAttribute('aria-pressed',String(on));$('#reader-immersive-exit').tabIndex=on?0:-1;$('#reader-aside').classList.remove('open');});
 if(on){
  if(requestNative&&typeof reader.requestFullscreen==='function'){
   try{await reader.requestFullscreen({navigationUI:'hide'})}catch(e){/* CSS fullscreen still works on devices without the API. */}
  }
 }else{
  if(document.fullscreenElement===reader){try{await document.exitFullscreen()}catch(e){/* Exit control keeps CSS fallback. */}}
 }
}

function dbOpen(){return new Promise((resolve,reject)=>{if(!('indexedDB' in window))return reject(new Error('IndexedDB недоступна'));const r=indexedDB.open('lukomorye-library',2);r.onupgradeneeded=()=>{const x=r.result;['texts','custom'].forEach(name=>{if(!x.objectStoreNames.contains(name))x.createObjectStore(name,{keyPath:'id'});});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function dbRead(store,query){
 return new Promise((resolve,reject)=>{
  if(!db){resolve(undefined);return;}
  const request=query(db.transaction(store).objectStore(store));
  request.onsuccess=()=>resolve(request.result);
  request.onerror=()=>reject(request.error);
 });
}
async function dbGetText(id){return sessionTexts.get(id)||await dbRead('texts',store=>store.get(id))}
async function dbAll(store){return await dbRead(store,items=>items.getAll())||[]}
function saveBookText(doc,book){
 return new Promise((resolve,reject)=>{
  if(!db){reject(new Error('Локальное хранилище недоступно'));return;}
  const tx=db.transaction(book?['texts','custom']:['texts'],'readwrite');
  tx.objectStore('texts').put(doc);
  if(book)tx.objectStore('custom').put(book);
  tx.oncomplete=()=>{rememberWords(doc,book);resolve();};
  tx.onabort=()=>reject(tx.error||new Error('Не удалось сохранить книгу'));
 });
}
function rememberBook(book){
 const index=importedBooks.findIndex(item=>item.id===book.id);
 if(index<0){importedBooks.push(book);books.push(book);return;}
 importedBooks[index]=book;
 books[books.findIndex(item=>item.id===book.id)]=book;
}
function getInfo(book){return progress[book.id]||{percent:0,done:false,index:0,updated:0}}
function readingSpeed(){
 const speed=Number(settings.speed);
 return Number.isFinite(speed)&&speed>0?speed:defaultSettings.speed;
}
function readingMinutes(words){return Math.max(1,Math.ceil(words/readingSpeed()))}
function rememberWords(doc,book=catalogById.get(doc.id)){
 savedWords.set(doc.id,book?prepareReadingText(doc,book).words:doc.words);
}
function getWords(book){
 const embedded=EMBEDDED[book.id];
 if(savedWords.has(book.id)&&!book.textRevision)return savedWords.get(book.id);
 if(embedded&&!embeddedWords.has(book.id))embeddedWords.set(book.id,prepareReadingText(embedded,book).words);
 return embeddedWords.get(book.id)||progress[book.id]?.words;
}
function getMinutes(book){
 const words=getWords(book);
 return words?readingMinutes(words):Math.max(1,Math.ceil((book.minutes||10)*defaultSettings.speed/readingSpeed()));
}
function formatDuration(minutes){
 if(minutes<60)return `${minutes} мин`;
 const hours=Math.floor(minutes/60),rest=minutes%60;
 return rest?`${hours} ч ${rest} мин`:`${hours} ч`;
}
function displayMinutes(book){return (getWords(book)?'':'≈ ')+formatDuration(getMinutes(book))}
function fmtAuthor(a){return a.length>37?a.slice(0,35)+'…':a}
function countWords(s){return (s.trim().match(/[\p{L}\p{N}]+(?:[-’][\p{L}\p{N}]+)*/gu)||[]).length}
function esc(s){return String(s).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
function sourceLink(page){
 return 'https://ru.wikisource.org/wiki/'+page.replaceAll(' ','_').split('/').map(encodeURIComponent).join('/');
}
function trustedBookSource(url){
 return typeof url==='string'&&(/^https:\/\/tolstoy\.ru\/online\/90\/(?:21|22)\/(?:#[\w-]+)?$/.test(url)||['https://feb-web.ru/feb/byliny/texts/rf1/rf1-0473.htm?cmd=p','https://feb-web.ru/feb/skazki/texts/af0/af3/af3-155-.htm?cmd=p'].includes(url))?url:'';
}
function bookSource(book,doc){
 return book.sourceType==='local'?'':trustedBookSource(doc?.sourceUrl)||sourceLink(doc?.page||book.page);
}
function heading(label){$('#crumb-current').textContent=label;$('#list-title').textContent=label}
function navTo(v,recordHistory=true){
 if(recordHistory&&v!==view){
  const state={lukoView:v,lukoDepth:(history.state?.lukoDepth||0)+1};
  try{history.pushState(state,'');}catch{/* Local-file browsers can restrict history. */}
 }
 view=v;updateLibraryBack();pageLimit=24;$('#sidebar').classList.remove('mobile-open');$('#mobile-scrim').classList.add('hidden');$$('[data-nav]').forEach(el=>el.classList.toggle('active',el.dataset.nav===v));$$('[data-genre]').forEach(el=>el.classList.toggle('active',el.dataset.genre===v));if(v==='all')heading('Книжная полка');else heading(v==='continue'?'Продолжить чтение':v==='favorites'?'Избранное':v==='done'?'Прочитанные произведения':v==='offline'?'Доступно без интернета':v);render();window.scrollTo({top:0,behavior:'smooth'})}
function updateLibraryBack(){$('#top-back').disabled=!history.state?.lukoDepth&&view==='all'}
function bookCountry(book){
 return book.country||(['Русские народные','Сказки писателей','Детские рассказы','Приключения','Басни'].includes(book.category)?'Русские':'');
}
function inCollection(book,name){return book.category===name||book.collections?.includes(name)}
function inShelf(book){
 const status=getInfo(book);
 if(view==='continue')return !status.done&&Boolean(status.updated);
 if(view==='done')return status.done;
 if(view==='favorites')return favorites.has(book.id);
 if(view==='offline')return cachedIds.has(book.id);
 return view==='all'||inCollection(book,view);
}
const ageRanges={'under-6':[0,5],'6-7':[6,7],'8-9':[8,9],'10-plus':[10,Infinity]};
const timeRanges={short:[1,5],medium:[6,15],long:[16,30],verylong:[31,60],epic:[61,Infinity]};
const titleOrder=new Intl.Collator('ru',{numeric:true,sensitivity:'base'});
const searchKey=value=>value.toLocaleLowerCase('ru').replaceAll('ё','е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
function inRange(value,range){return !range||(value>=range[0]&&value<=range[1])}
const searchIndex=new WeakMap();
function indexBook(book){
 let index=searchIndex.get(book);
 if(index)return index;
 const title=searchKey(book.title);
 const aliases=(book.aliases||[]).map(searchKey);
 const names=[title,...aliases];
 index={title,aliases,names,words:[...new Set(names.join(' ').split(' '))],
  metadata:searchKey([book.author,book.category,book.description,bookCountry(book),...(book.keywords||[]),...(book.collections||[])].join(' '))};
 searchIndex.set(book,index);
 return index;
}
function closeWord(term,word){
 if(term.length<4)return false;
 const limit=term.length>=7?2:1;
 if(Math.abs(term.length-word.length)>limit)return false;
 let previous=Array.from({length:word.length+1},(_,i)=>i);
 let beforePrevious;
 for(let i=1;i<=term.length;i++){
  const row=[i];
  for(let j=1;j<=word.length;j++){
   const cost=term[i-1]===word[j-1]?0:1;
   row[j]=Math.min(previous[j]+1,row[j-1]+1,previous[j-1]+cost);
   if(i>1&&j>1&&term[i-1]===word[j-2]&&term[i-2]===word[j-1])row[j]=Math.min(row[j],beforePrevious[j-2]+1);
  }
  beforePrevious=previous;
  previous=row;
 }
 return previous[word.length]<=limit;
}
function searchRank(book,query,terms){
 const index=indexBook(book);
 if(index.title===query)return 0;
 if(index.aliases.includes(query))return 1;
 if(index.names.some(name=>name.includes(query)))return 2;
 if(terms.every(term=>index.words.some(word=>word.includes(term))))return 3;
 if(terms.every(term=>index.words.some(word=>word.includes(term)||closeWord(term,word))))return 4;
 if(terms.every(term=>index.metadata.includes(term)||index.words.some(word=>word.includes(term))))return 5;
 return -1;
}
function sortBooks(a,b){
 const title=()=>titleOrder.compare(a.title,b.title);
 if(sortBy==='az')return title();
 if(sortBy==='time-asc')return getMinutes(a)-getMinutes(b)||title();
 if(sortBy==='time-desc')return getMinutes(b)-getMinutes(a)||title();
 if(sortBy==='progress')return getInfo(b).percent-getInfo(a).percent||title();
 if(view==='continue')return getInfo(b).updated-getInfo(a).updated;
 return 0;
}
let searchRanks=new Map();
function filtered(){
 const query=searchKey(searchText);
 const terms=query.split(' ');
 searchRanks=new Map();
 const matches=books.filter(book=>{
  if(!inShelf(book))return false;
  if(countryFilter!=='all'&&bookCountry(book)!==countryFilter)return false;
  if(!inRange(Number.parseInt(book.age,10),ageRanges[ageFilter]))return false;
  if(!inRange(getMinutes(book),timeRanges[timeFilter]))return false;
  if(!query)return true;
  const rank=searchRank(book,query,terms);
  if(rank<0)return false;
  searchRanks.set(book.id,rank);
  return true;
 });
 return matches.sort((a,b)=>(query?searchRanks.get(a.id)-searchRanks.get(b.id):0)||sortBooks(a,b));
}
function searchRow(book){
 const id=esc(book.id),title=esc(book.title);
 const selected=favorites.has(book.id);
 const available=cachedIds.has(book.id);
 return `<article class="search-row">
  <button type="button" class="search-open" data-open="${id}" aria-label="Открыть ${title}"><strong>${title}</strong><small>${esc(book.author||'')}</small></button>
  <span class="search-detail">${esc(book.age||'Без возраста')} · ${displayMinutes(book)}${available?' <span class="search-offline" title="Доступно офлайн" aria-label="Доступно офлайн">'+icon('check-circle',14)+'</span>':''}</span>
  <button type="button" class="icon-btn search-favorite ${selected?'selected':''}" data-fav="${id}" aria-label="${selected?'Убрать из избранного':'Добавить в избранное'}">${icon('heart',17)}</button>
  ${!available&&book.sourceType!=='local'?`<button type="button" class="icon-btn search-download" data-download="${id}" aria-label="Скачать текст" title="Скачать текст">${icon('download',16)}</button>`:''}
 </article>`;
}
function renderSearchRows(list){
 let exactShown=false,relatedShown=false;
 return list.map(book=>{
  const exact=searchRanks.get(book.id)<2;
  let heading='';
  if(exact&&!exactShown){heading='<h3 class="search-group">Точные совпадения</h3>';exactShown=true;}
  if(!exact&&!relatedShown){heading='<h3 class="search-group">Похожие результаты</h3>';relatedShown=true;}
  return heading+searchRow(book);
 }).join('');
}
function hasFilters(){
 return Boolean(searchText.trim()||countryFilter!=='all'||timeFilter!=='all'||ageFilter!=='all');
}
function card(b){const p=getInfo(b);const [bg,fg]=visual[b.category]||visual['Мои книги'];const percent=p.done?100:Math.round(p.percent||0);let status=p.done?'Прочитано':p.percent>0?`${percent}% прочитано`:cachedIds.has(b.id)?(embeddedIds.has(b.id)?'Встроено офлайн':'Сохранено офлайн'):'Нужна загрузка';
 const label=b.author?.startsWith('А. Н. Афанасьев')?'Народная сказка':b.author||'Книга';return `<article class="book-card" style="--card-bg:${bg};--card-fg:${fg}"><div class="card-top"><div class="card-badges"><span class="small-badge">${esc(b.age||'Без возраста')}</span>${b.intense?'<span class="small-badge">Серьёзные сцены</span>':''}</div>${cachedIds.has(b.id)?`<span class="card-offline-mark" title="${embeddedIds.has(b.id)?'Полный текст встроен в приложение':'Полный текст сохранён на этом устройстве'}" aria-label="${embeddedIds.has(b.id)?'Встроена офлайн':'Сохранено в памяти устройства'}">${icon('check-circle',13)} <span>${embeddedIds.has(b.id)?'Встроено':'В памяти'}</span></span>`:''}<span class="book-emblem" aria-hidden="true">${icon(categoryIcon[b.category]||'book-open',32)}</span><button class="card-fav ${favorites.has(b.id)?'selected':''}" data-fav="${esc(b.id)}" aria-label="${favorites.has(b.id)?'Убрать из избранного':'Добавить в избранное'}">${icon('heart',16)}</button></div><div class="card-body"><span class="card-author" title="${esc(label)}">${esc(fmtAuthor(label))}</span><h3 class="card-title" title="${esc(b.title)}">${esc(b.title)}</h3><p class="card-desc">${esc(b.description||'Полный классический текст без сокращений.')}</p><div class="card-footer"><span class="duration-label" data-minutes="${getMinutes(b)}" title="Оценка при ${readingSpeed()} словах в минуту">${icon('clock',14)} ${displayMinutes(b)}</span><span class="card-state ${p.done?'done':''}">${p.done?icon('check',12):''}${status}</span></div><div class="card-progress"><i style="width:${percent}%"></i></div>${!cachedIds.has(b.id)&&b.sourceType!=='local'?`<button type="button" class="card-download" data-download="${esc(b.id)}" title="Скачать полный текст"><span>${icon('download',14)}</span> Скачать текст</button>`:''}</div><button type="button" class="card-open-overlay" data-open="${esc(b.id)}" aria-label="Открыть ${esc(b.title)}"></button></article>`}
function workCount(count){
 const units=count%10, teens=count%100>=11&&count%100<=14;
 const noun=!teens&&units===1?'произведение':!teens&&units>=2&&units<=4?'произведения':'произведений';
 return `${count} ${noun}`;
}
function render(){fillCountryFilter();renderCategoryTabs();$('#all-count').textContent=books.length;$('#stat-all').textContent=books.length;$('#stat-read').textContent=books.filter(b=>getInfo(b).done).length;$('#stat-current').textContent=books.filter(b=>!getInfo(b).done&&getInfo(b).percent>0).length;$('#stat-offline').textContent=cachedIds.size;const summary=$('.source-mini');if(summary)summary.textContent=`${cachedIds.size} текстов офлайн · ${books.length} в каталоге`;
 const rec=books.filter(b=>getInfo(b).updated&&!getInfo(b).done).sort((a,b)=>getInfo(b).updated-getInfo(a).updated).slice(0,4);$('#recent-section').classList.toggle('hidden',!(view==='all'&&!hasFilters()&&rec.length));$('#recent-books').innerHTML=rec.map(card).join('');
 lastVisible=filtered();$('#result-count').textContent=workCount(lastVisible.length);
 const filteredBooks=lastVisible.slice(0,pageLimit);
 const results=$('#books');
 const searching=Boolean(searchKey(searchText));
 results.classList.toggle('search-results',searching);
 results.innerHTML=searching?renderSearchRows(filteredBooks):filteredBooks.map(card).join('');$('#more-wrap').classList.toggle('hidden',lastVisible.length<=pageLimit);$('#empty').classList.toggle('hidden',lastVisible.length>0);
 $('#clear-search').classList.toggle('hidden',!searchText);let pills=[];if(countryFilter!=='all')pills.push([countryFilter,'country']);if(searchText.trim())pills.push(['Поиск: '+searchText.trim(),'search']);if(timeFilter!=='all')pills.push([$('#time-filter').selectedOptions[0].textContent,'time']);if(ageFilter!=='all')pills.push([$('#age-filter').selectedOptions[0].textContent,'age']);$('#active-filters').innerHTML=pills.map(([t,k])=>`<span class="pill">${esc(t)}<button data-remove="${k}" aria-label="Сбросить фильтр: ${esc(t)}">×</button></span>`).join('');updateOfflineStatus();}
function fillCountryFilter(){
 const list=books.filter(inShelf);
 const available=[...new Set(list.map(bookCountry).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ru'));
 if(!available.includes(countryFilter))countryFilter='all';
 const select=$('#country-filter');
 select.innerHTML='<option value="all">Все страны</option>'+available.map(country=>`<option value="${esc(country)}">${esc(country)}</option>`).join('');
 select.classList.toggle('hidden',!available.length);
 select.value=countryFilter;
}
function renderGenres(){$('#genres').innerHTML=categories.filter(c=>c==='Мои книги'?importedBooks.length:true).map(c=>`<button class="nav-item ${view===c?'active':''}" data-genre="${esc(c)}"><span class="nav-ico">${icon(categoryIcon[c])}</span><span>${esc(c)}</span><span class="nav-count">${books.filter(book=>inCollection(book,c)).length}</span></button>`).join('')}
function renderCategoryTabs(){const tabs=$('#category-tabs');const scroll=tabs.scrollLeft;const selected=view==='all'?'all':view;const entries=[['all','Все'],...categories.filter(c=>c!=='Мои книги'||importedBooks.length).map(c=>[c,c])];tabs.innerHTML=entries.map(([k,label])=>`<button type="button" class="category-tab ${selected===k?'active':''}" data-tab="${esc(k)}" aria-pressed="${selected===k}">${icon(k==='all'?'library':categoryIcon[k],16)}<span>${esc(label)}</span><small>${k==='all'?books.length:books.filter(book=>inCollection(book,k)).length}</small></button>`).join('');tabs.scrollLeft=scroll;}

function updateProgress(patch){if(!current)return;const old=getInfo(current);progress[current.id]={...old,...patch,updated:Date.now()};saveProgress();updateProgressUI()}
function updateProgressUI(){if(!current)return;const p=getInfo(current),percent=p.done?100:Math.min(100,Math.max(0,Math.round(p.percent||0)));$('#reader-progress-bar').style.width=percent+'%';$('#reader-aside-track').style.width=percent+'%';$('#reader-aside-percent').textContent=percent+'%';$('#read-percent').textContent=percent+'%';const remaining=Math.max(0,Math.round((currentDoc?.minutes||getMinutes(current))*(100-percent)/100));$('#read-remaining').textContent=`Осталось около ${formatDuration(remaining)}`;$('#reader-header-status').textContent=p.done?'Прочитано':`${percent}% книги`;$('#footer-done').innerHTML=icon('check',14)+(p.done?' Уже прочитано':' Прочитано');$('#mark-done').classList.toggle('hidden',!!p.done);$('#mark-unread').classList.toggle('hidden',!p.done)}
function updateReaderFav(){const on=favorites.has(current?.id);$('#reader-favorite').innerHTML=icon('heart');$('#reader-favorite').classList.toggle('selected',on);$('#reader-favorite').setAttribute('aria-label',on?'Убрать из избранного':'Добавить в избранное')}
function closeReader(fromHistory=false){
 if(!current)return;
 flushReadingPosition();closeQuickPanel();loadingToken++;stopSpeech();
 if(immersive)setImmersive(false);
 $('#reader').classList.add('hidden');document.body.style.overflow='';
 current=null;currentDoc=null;readerOrder=[];render();
 if(!fromHistory&&history.state?.lukoReader)history.back();
}
function updateBookNavigation(){
 const index=readerOrder.indexOf(current.id);
 $('#prev-book').disabled=index<=0;
 $('#finish-prev-book').disabled=$('#prev-book').disabled;
 $('#reader-next-book').disabled=index<0||index>=readerOrder.length-1;
 $('#next-book').disabled=$('#reader-next-book').disabled;
}
function showHome(){
 searchText='';timeFilter='all';ageFilter='all';countryFilter='all';sortBy='popular';
 $('#search').value='';
 for(const field of ['time','age','country','sort'])$(`#${field}-filter`).value=field==='sort'?'popular':'all';
 navTo('all');
}
async function openBook(id,recordHistory=true,allowNetwork=true){
 const b=books.find(x=>x.id===id);
 if(!b)return;
 flushReadingPosition();closeQuickPanel();
 if(!current)readerOrder=(lastVisible.some(book=>book.id===id)?lastVisible:books).map(book=>book.id);
 if(recordHistory&&history.state?.lukoReader!==id){
  const state={...history.state,lukoReader:id};
  try{
   if(history.state?.lukoReader)history.replaceState(state,'');
   else history.pushState(state,'');
  }catch{/* Reading also works in browsers that restrict history on local files. */}
 }
 stopSpeech();current=b;currentDoc=null;updateBookNavigation();const token=++loadingToken;document.body.style.overflow='hidden';$('#reader').classList.remove('hidden');$('#reader-scroll').scrollTop=0;$('#reader-aside').classList.remove('open');$('#reader-title').textContent=b.title;$('#reader-short-title').textContent=b.title;$('#reader-toc-title').textContent=b.title;$('#reader-category').textContent=b.category;$('#reader-author').textContent=b.author||'';$('#reader-age').textContent=b.age||'Без возраста';$('#reader-duration').textContent=`Около ${formatDuration(getMinutes(b))} чтения`;$('#reader-edition').textContent=b.sourceType==='local'?'Личная библиотека':'Классический полный текст';$('#reader-alert').classList.toggle('hidden',!b.intense);$('#reader-alert').textContent=b.intense?'В оригинальном произведении могут встречаться страшные, грустные или жестокие эпизоды. Текст не смягчён и не сокращён.':'';
 $('#reading-finish').classList.add('hidden');$('#reading-text').innerHTML='<div class="reader-loading"><div class="spinner"></div> Открываем полный текст…</div>';$('#toc-items').innerHTML='';const url=bookSource(b,EMBEDDED[b.id]);$('#reader-source').href=url||'#';$('#reader-source-side').href=url||'#';$('#reader-source').classList.toggle('hidden',!url);$('#reader-aside-source').classList.toggle('hidden',!url);updateReaderFav();updateProgressUI();
 try{
 let doc=await dbGetText(b.id).catch(error=>{
  if(b.sourceType==='local')throw error;
  console.warn('Не удалось прочитать локальную копию',error);
 });
 doc=b.textRevision&&EMBEDDED[b.id]?EMBEDDED[b.id]:doc||EMBEDDED[b.id];
 if(!doc){
  if(b.sourceType==='local')throw new Error('Файл книги отсутствует в памяти браузера');
  if(!allowNetwork)throw new Error('Для получения полного текста выберите книгу в каталоге и нажмите «Скачать текст».');
  if(!navigator.onLine)throw new Error('Эта книга ещё не сохранена на устройстве. Подключитесь к интернету для загрузки.');
  const result=await loadFromSource(b);
  doc=result.doc;
  if(token!==loadingToken)return;
  if(!result.saved)toast('Текст открыт. Сохранить его для офлайн-чтения не удалось.');
 }
 if(token!==loadingToken)return;
 doc=prepareReadingText(doc,b);
 currentDoc=doc;if(b.sourceType!=='local'){$('#reader-source').href=bookSource(b,doc);$('#reader-source-side').href=bookSource(b,doc)}const minutes=readingMinutes(doc.words);currentDoc.minutes=minutes;const previous=getInfo(b);
 const position=b.textRevision&&previous.textRevision!==b.textRevision?0:previous.index;
 progress[b.id]={...previous,index:position,words:doc.words,textRevision:b.textRevision||0,updated:Date.now()};saveProgress();
 renderText(doc);$('#reader-duration').textContent=`${formatDuration(minutes)} чтения · ${doc.words.toLocaleString('ru')} слов`;$('#reader-aside-time').textContent=`${formatDuration(minutes)} · ${doc.words.toLocaleString('ru')} слов`;$('#reader-edition').textContent=doc.edition||b.reference||(b.sourceType==='local'?'Личная библиотека':'Классический оригинал');$('#reading-finish').classList.remove('hidden');
 requestAnimationFrame(()=>{if(token!==loadingToken)return;const p=getInfo(b);const nodes=$$('[data-para]',$('#reading-text'));const dest=p.index&&nodes.find(node=>Number(node.dataset.para)>=p.index);if(dest){const sc=$('#reader-scroll'),rect=dest.getBoundingClientRect(),parent=sc.getBoundingClientRect();sc.scrollTop+=rect.top-parent.top-25}else if(p.percent>1){const sc=$('#reader-scroll');sc.scrollTop=(sc.scrollHeight-sc.clientHeight)*(p.percent/100)}updateProgressUI()});
 }catch(e){if(token!==loadingToken)return;console.warn(e);$('#reading-text').innerHTML=`<div class="loading-error"><h3>Не удалось загрузить произведение</h3><p>${esc(e.message||'Нет подключения к источнику.')}</p>${url?`<a href="${esc(url)}" target="_blank" rel="noopener">Открыть источник ${icon('arrow-up-right',14)}</a>`:''}</div>`;$('#reading-finish').classList.add('hidden')}
}
function prepareReadingText(doc,book){
 const collection=/^Народные русские сказки \(Афанасьев\)\//;
 if(book.sourceType==='local'||(!collection.test(book.page)&&!collection.test(doc.page)))return doc;
 let hasProse=false,numberWords=0;
 // Keep source block indices for saved positions, including older offline copies.
 const blocks=doc.blocks.map(block=>{
  if(/^h[234]$/.test(block.tag)&&/^(?:№\s*)?\d+(?:\s*[-–—]\s*\d+)?\.?$/.test(block.text.trim())){
   numberWords+=countWords(block.text);
   return {...block,text:hasProse?'Другой вариант':''};
  }
  if(['p','verse','blockquote'].includes(block.tag))hasProse=true;
  return block;
 });
 return numberWords?{...doc,blocks,words:Math.max(1,doc.words-numberWords)}:doc;
}
function renderText(doc){
 const container=$('#reading-text');container.replaceChildren();const frag=document.createDocumentFragment();
 const anchors=[],visible=[];
 doc.blocks.forEach((block,index)=>{
  if(!block.text)return;
  visible.push(index);
  const tag=['p','h2','h3','h4','blockquote'].includes(block.tag)?block.tag:block.tag==='verse'?'div':'p';
  const el=document.createElement(tag);if(block.tag==='verse')el.className='verse';el.textContent=block.text;el.dataset.para=String(index);
  if(block.tag.match(/^h/)){el.id='part-'+index;anchors.push({label:block.text.length>55?block.text.slice(0,52)+'…':block.text,index});}
  frag.appendChild(el);
 });
 container.appendChild(frag);
 if(!anchors.length){
  const points=[0,.25,.50,.75].filter(x=>x===0||visible.length>15);
  points.forEach((v,i)=>anchors.push({label:['Начало','Четверть книги','Середина','Последняя четверть'][i],index:visible[Math.floor(visible.length*v)]}));
 }else anchors.unshift({label:'Начало',index:visible[0]});
 $('#toc-items').innerHTML=anchors.map((a,i)=>`<button data-go="${a.index}" class="${i===0?'active':''}">${esc(a.label)}</button>`).join('');
}
function sourceBlocks(html){const template=document.createElement('template');template.innerHTML=html;const root=template.content.querySelector('.mw-parser-output')||template.content;if(!root)throw new Error('Не удалось прочитать разметку первоисточника');
 root.querySelectorAll('script,style,sup,figure,img,form,nav,#headertemplate,.ws-header,.header-container,.ws-noexport,.mw-editsection,.metadata,.catlinks,.reference,.references,.reflist,.toc,.navbox,.infobox,.printfooter,.sistersitebox,.mw-empty-elt,.portal,.sisitemark,.noprint').forEach(n=>n.remove());
 root.querySelectorAll('table').forEach(table=>{
  if(!table.matches('.poetry')&&!table.querySelector('table.poetry'))table.remove();
 });
 const list=root.querySelectorAll('h2,h3,h4,p,div.poem,blockquote,pre,dl,ul,ol');let stopped=false,blocks=[];
 const navText=[...root.querySelectorAll('ul,ol')].reduce((sum,n)=>sum+(n.textContent||'').length,0);const proseText=[...root.querySelectorAll('p,div.poem,blockquote,pre')].reduce((sum,n)=>sum+(n.textContent||'').length,0);
 if(navText>proseText*1.5&&navText>600)throw new Error('На этой странице список произведений, а не полный текст книги.');for(const n of list){if(n.closest('.ws-header,.mw-collapsible,.mw-collapsible-content,.mw-parser-output > .mw-empty-elt'))continue;
 if(n.parentElement?.closest('.poem,blockquote,ul,ol,dl'))continue;
 const type=n.tagName.toLowerCase();const raw=(n.classList?.contains('poem')?'verse':type);const label=n.textContent.replace(/\s+/g,' ').trim();if(/^h[234]$/.test(type)&&/^(?:Содержание|Оглавление)$/i.test(label))continue;if(/^h[234]$/.test(type)&&/^(Примечания|Примечание|Литература|Источники|Ссылки|См\. также|Комментарии|Библиография)(\s|$)/i.test(label)){stopped=true;break}
 if(stopped)break;const clone=n.cloneNode(true);clone.querySelectorAll('sup,small.reference,.mw-editsection,.reference').forEach(x=>x.remove());clone.querySelectorAll('br').forEach(x=>x.replaceWith(document.createTextNode('\n')));let text=clone.textContent.replace(/\u00a0/g,' ').replace(/[\t ]+\n/g,'\n').replace(/\n[\t ]+/g,'\n').replace(/[ ]{3,}/g,' ').trim();
 if(!text||text==='[править]'||/^(Эта страница|Это произведение перешло|Текст доступен по лицензии)/.test(text))continue;
 if(raw!=='verse'&&raw!=='pre'&&text.length>80000)continue;
 blocks.push({tag:raw==='pre'?'verse':raw,text});}
 // The collection and book headers are link templates, not primary prose; skip short metadata before first genuine paragraph.
 while(blocks.length>1&&/^(Народные русские сказки|Источник:|Автор:|Перевод:|Дата создания:)/.test(blocks[0].text))blocks.shift();
 return blocks;
}
async function fetchApi(page,signal){const url='https://ru.wikisource.org/w/api.php?action=parse&prop=text&redirects=1&page='+encodeURIComponent(page)+'&format=json&formatversion=2&origin=*';const r=await fetch(url,{signal,mode:'cors',credentials:'omit'});if(r.status===429){
 const error=new Error('Викитека временно ограничивает запросы. Попробуйте позже.');
 error.name='SourceRateLimit';
 throw error;
}if(!r.ok)throw new Error(r.status>=500?'Источник временно недоступен.':'Источник вернул HTTP '+r.status+'.');
 const x=await r.json();
 if(x.error?.code==='missingtitle')throw new Error('Страница в Викитеке отсутствует.');
 if(x.error)throw new Error('Викитека не вернула текст произведения.');if(!x.parse?.text)throw new Error('Источник не вернул полный текст');return x.parse;}
function loadFromSource(book){
 if(downloads.has(book.id))return downloads.get(book.id);
 const request=(async()=>{
  const doc=sessionTexts.get(book.id)||await fetchWork(book);
  try{
   await saveBookText(doc);
   cachedIds.add(book.id);
   forgetDownloadFailure(book.id);
   sessionTexts.delete(book.id);
   return {doc,saved:true};
  }catch(error){
   sessionTexts.set(book.id,doc);
   return {doc,saved:false,error};
  }
 })().finally(()=>downloads.delete(book.id));
 downloads.set(book.id,request);
 return request;
}
async function fetchWork(b){const ac=new AbortController();const timeout=setTimeout(()=>ac.abort(),25000);try{
 const source=await fetchApi(b.page,ac.signal);
 const page=source.title||b.page;
 let blocks=sourceBlocks(source.text);
 // Wikisource headers are metadata, not part of the book. Keep later chapter headings intact.
 let seenBody=false;blocks=blocks.filter(block=>{if(['p','verse','blockquote'].includes(block.tag)&&block.text.length>=40)seenBody=true;
  if(seenBody)return true;
  if(!/^h[234]$/.test(block.tag))return true;
  const label=block.text.toLowerCase().replace(/ё/g,'е').replace(/[^а-яa-z0-9]+/g,' ').trim();
  const title=b.title.toLowerCase().replace(/ё/g,'е').replace(/[^а-яa-z0-9]+/g,' ').trim();
  const author=(b.author||'').toLowerCase().replace(/ё/g,'е');
  return !(label===title||title.includes(label)&&label.length>5||label.includes(title)&&title.length>5||author.includes(label)&&label.length>7||/^(братья гримм|ганс христиан андерсен|народные сказки)$/.test(label));
 });
 let words=blocks.reduce((sum,x)=>sum+countWords(x.text),0);if(words<32){throw new Error('На найденной странице находится оглавление, а не полный текст. Откройте оригинал по ссылке.')}
 const proseChars=blocks.filter(x=>x.tag==='p'||x.tag==='verse'||x.tag==='blockquote').reduce((sum,x)=>sum+x.text.length,0);if(proseChars<150||blocks.filter(x=>['ul','ol','dl'].includes(x.tag)).length>blocks.length*.5)throw new Error('Источник похож на оглавление, а не на самостоятельное произведение.');if(blocks.some(x=>x.text.includes('Источник — https://ru.wikisource.org'))&&proseChars<1000)throw new Error('Текст не найден, ссылка ведёт на справочную страницу.');return {id:b.id,page,blocks,words,downloadedAt:Date.now()};
 }catch(e){if(e.name==='AbortError')throw new Error('Источник слишком долго отвечает. Попробуйте ещё раз.');throw e}finally{clearTimeout(timeout)}}
function readingScroll(){
 if(!currentDoc)return;
 clearTimeout(scrollTimer);
 scrollTimer=setTimeout(flushReadingPosition,140);
}
function flushReadingPosition(){
 if(!scrollTimer)return;
 clearTimeout(scrollTimer);
 scrollTimer=0;
 if(!currentDoc||getInfo(current).done)return;
 const sc=$('#reader-scroll'),max=sc.scrollHeight-sc.clientHeight;
 const percent=max>0?Math.min(100,Math.max(0,Math.round(sc.scrollTop/max*1000)/10)):0;
 const paragraphs=$$('[data-para]',$('#reading-text'));
 const y=sc.getBoundingClientRect().top+85;
 let index=0;
 for(const paragraph of paragraphs){
  if(paragraph.getBoundingClientRect().top>y)break;
  index=Number(paragraph.dataset.para);
 }
 const saved=getInfo(current);
 if(percent!==saved.percent||index!==saved.index)updateProgress({percent,index});
}
function jumpPara(idx){const node=$(`[data-para="${idx}"]`,$('#reading-text'));if(!node)return;$('#reader-aside').classList.remove('open');const sc=$('#reader-scroll');sc.scrollTo({top:sc.scrollTop+node.getBoundingClientRect().top-sc.getBoundingClientRect().top-30,behavior:'smooth'})}
function markDone(flag){if(!current||!currentDoc)return;updateProgress(flag?{done:true,percent:100,index:currentDoc.blocks.length-1}:{done:false,percent:0,index:0});toast(flag?'Отмечено как прочитанное':'Отметка снята');if(!flag)$('#reader-scroll').scrollTop=0}
function stopSpeech(){ttsActive=false;ttsUtterance=null;$$('.tts-speaking').forEach(x=>x.classList.remove('tts-speaking'));if('speechSynthesis'in window)window.speechSynthesis.cancel();$('#listen-btn').innerHTML=icon('play')+' <span>Слушать</span>'}
function speakNext(){if(!ttsActive||!currentDoc)return;const b=currentDoc.blocks;while(ttsParagraph<b.length&&!b[ttsParagraph].text)ttsParagraph++;if(ttsParagraph>=b.length){stopSpeech();return}const content=b[ttsParagraph].text;const u=new SpeechSynthesisUtterance(content);u.lang='ru-RU';u.rate=.94;ttsUtterance=u;$$('.tts-speaking').forEach(x=>x.classList.remove('tts-speaking'));const n=$(`[data-para="${ttsParagraph}"]`,$('#reading-text'));n?.classList.add('tts-speaking');n?.scrollIntoView({block:'center',behavior:'smooth'});u.onend=()=>{if(ttsUtterance===u){ttsParagraph++;speakNext()}};u.onerror=()=>{if(ttsUtterance!==u)return;stopSpeech();toast('Озвучивание недоступно на этом устройстве')};window.speechSynthesis.speak(u)}
function toggleSpeech(){if(!currentDoc){toast('Сначала загрузите книгу');return}if(!('speechSynthesis' in window)){toast('Озвучивание не поддерживается');return}if(ttsActive){stopSpeech();return}ttsActive=true;ttsParagraph=Math.min(currentDoc.blocks.length-1,getInfo(current).index||0);$('#listen-btn').innerHTML=icon('stop')+' <span>Остановить</span>';speakNext()}
async function importBooks(files){let ok=0,bad=0;for(const f of Array.from(files)){try{if(!/\.(txt|fb2)$/i.test(f.name))throw new Error('Только TXT или FB2');if(f.size>15*1024*1024)throw new Error('Файл слишком большой');const s=await f.text();let title=f.name.replace(/\.(txt|fb2)$/i,'').replace(/_/g,' '),author='Из личной коллекции',content='';if(/\.fb2$/i.test(f.name)){const xml=new DOMParser().parseFromString(s,'application/xml');if(xml.querySelector('parsererror'))throw new Error('Неверный FB2');title=xml.querySelector('description title-info book-title')?.textContent?.trim()||title;const info=xml.querySelector('description title-info author');if(info)author=['first-name','middle-name','last-name'].map(x=>info.querySelector(x)?.textContent||'').filter(Boolean).join(' ')||author;
 const body=xml.querySelector('FictionBook > body')||xml.querySelector('body');if(!body)throw new Error('Нет текста');content=Array.from(body.querySelectorAll('p,subtitle,stanza')).filter(el=>!el.closest('stanza')||el.tagName.toLowerCase()==='stanza').map(x=>x.textContent.trim()).filter(Boolean).join('\n\n');}else content=s;
 const words=countWords(content);if(!words)throw new Error('Файл не содержит текста');const blocks=content.split(/\n\s*\n+/).map(t=>({tag:'p',text:t.trim()})).filter(x=>x.text);const id='local-'+Date.now()+'-'+Math.random().toString(36).slice(2,8);const b={id,title,author,category:'Мои книги',minutes:Math.max(1,Math.ceil(words/settings.speed)),description:'Книга, добавленная из файла '+f.name,sourceType:'local',reference:'Файл: '+f.name};await saveBookText({id,page:'',blocks,words,downloadedAt:Date.now()},b);rememberBook(b);cachedIds.add(id);ok++}catch(e){bad++;console.warn('Import failed:',f.name,e)}}$('#book-import').value='';$('#import-status').textContent=`Добавлено: ${ok}. Не удалось: ${bad}.`;renderGenres();render();toast(`Добавлено книг: ${ok}`)}
function downloadJson(filename,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function exportCurrentTxt(){
 if(!current||!currentDoc?.blocks?.length){toast('Сначала откройте сохранённый текст книги');return;}
 const safeName=(current.title||'Книга').replace(/[\/:*?"<>|\x00-\x1F]/g,'').trim().slice(0,95)||'Книга';
 const parts=[current.title,current.author||'',current.reference||'',bookSource(current,currentDoc)].filter(Boolean);
 const body=currentDoc.blocks.map(b=>(b.text||'').trim()).filter(Boolean).join('\r\n\r\n');
 const content='\uFEFF'+parts.join('\r\n')+'\r\n\r\n'+body+'\r\n';
 const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));
 const anchor=document.createElement('a');anchor.href=url;anchor.download=safeName+'.txt';anchor.click();
 setTimeout(()=>URL.revokeObjectURL(url),1200);
 toast('Книга экспортирована в TXT.');
}

let singleDownloads=new Set();
function updateQuickStatus(note=''){
 const saved=lastVisible.filter(book=>cachedIds.has(book.id)).length;
 const pending=lastVisible.filter(book=>!cachedIds.has(book.id)&&book.sourceType!=='local');
 const label=$('#offline-quick-summary');
 if(label)label.textContent=note||`В подборке ${workCount(lastVisible.length)}, доступно офлайн ${saved}, осталось загрузить ${pending.length}.`+
  (pending.length&&!db?' Хранилище браузера недоступно.':'');
 $('#offline-quick').classList.toggle('hidden',!lastVisible.length&&!bulkDownloading);
 const button=$('#quick-download');if(button){
  button.disabled=bulkDownloading||!pending.length||!db||!navigator.onLine;
  button.querySelector('span:last-child').textContent=bulkDownloading?'Загружаем…':!pending.length?'Всё сохранено':!navigator.onLine?'Нет интернета':'Загрузить подборку';
 }
 $('#quick-stop')?.classList.toggle('hidden',!bulkDownloading);
 const errors=failedBooks(lastVisible);
 const details=$('#quick-errors');
 details.classList.toggle('hidden',bulkDownloading||!errors.length);
 $('#quick-errors-summary').textContent=`Не скачались: ${errors.length}`;
 $('#quick-errors-list').innerHTML=errors.map(({title,error})=>`<li><strong>${esc(title)}</strong><span>${esc(error)}</span></li>`).join('');
 if(!errors.length)details.open=false;
}
async function downloadSingle(id){
 if(singleDownloads.has(id)||bulkDownloading)return;
 if(!db){toast('Сохранение недоступно в этом браузере. Откройте приложение на HTTPS-сайте.');return;}
 const b=books.find(x=>x.id===id);if(!b||cachedIds.has(id)||b.sourceType==='local')return;
 if(!navigator.onLine){toast('Нет соединения. Выберите сохранённые книги.');return;}
 singleDownloads.add(id);
 const nodes=$$(`[data-download="${CSS.escape(id)}"]`);
 nodes.forEach(n=>{n.disabled=true;if(!n.classList.contains('search-download'))n.innerHTML=icon('download',14)+' Загрузка…';});
 try{const result=await loadFromSource(b);if(!result.saved)throw result.error;render();toast('«'+b.title+'» сохранена — можно читать без интернета.');}
 catch(e){recordDownloadFailure(b,e);console.warn('Download:',b.title,e);toast(`Не удалось загрузить: ${b.title}. ${downloadFailures.get(id)}`);}
 finally{singleDownloads.delete(id);$$(`[data-download="${CSS.escape(id)}"]`).forEach(n=>{n.disabled=false;if(!n.classList.contains('search-download'))n.innerHTML=icon('download',14)+' Скачать текст';});updateOfflineStatus()}
}
async function downloadList(source,caption){
 if(bulkDownloading){toast('Уже идёт загрузка');return;}
 if(!navigator.onLine){toast('Нет интернета. Офлайн-книги доступны для чтения.');return;}
 if(!db){toast('Для сохранения требуется доступное локальное хранилище IndexedDB.');return;}
 const remaining=source.filter(b=>!cachedIds.has(b.id)&&b.sourceType!=='local');
 if(!remaining.length){toast('В этом разделе все книги уже сохранены.');return;}
 if(remaining.length>40&&!confirm(`Загрузить ${remaining.length} полных текстов из Викитеки: ${caption}? Загрузка идёт последовательно, можно остановить. Некоторые источники могут быть недоступны.`))return;
 bulkDownloading=true;stopBulk=false;updateOfflineStatus();$('#offline-quick-progress').classList.remove('hidden');
 let ok=0,done=0,failures=0,pauseReason='';
 const paint=()=>{
  const note=`${caption}: проверено ${done}/${remaining.length}, сохранено ${ok}, ошибок ${failures}`;
  $('#offline-quick-progress-label').textContent=note;
  $('#offline-quick-track-fill').style.width=Math.round(100*done/remaining.length)+'%';
  updateOfflineStatus(note);
 };
 paint();
 try{for(const b of remaining){
   if(!navigator.onLine)pauseReason='Соединение прервано. Уже загруженные книги сохранены.';
   if(stopBulk||pauseReason)break;
   if(cachedIds.has(b.id)){done++;paint();continue;}
   try{const result=await loadFromSource(b);if(!result.saved)throw result.error;ok++;}
   catch(err){
    failures++;recordDownloadFailure(b,err);
    console.warn('Source download:',b.title,err);
    if(err.name==='SourceRateLimit'){stopBulk=true;pauseReason=err.message;}
   }
   done++;paint();
   if(done%3===0)render();
   if(done<remaining.length&&!stopBulk)await new Promise(r=>setTimeout(r,380));
  }}finally{
   bulkDownloading=false;stopBulk=false;render();
   $('#offline-quick-progress-label').textContent=`Готово: ${ok} новых книг, ошибок ${failures}${done<remaining.length?', загрузка прервана':''}.`;
   updateOfflineStatus();
   if(failures&&!$('#quick-errors').classList.contains('hidden'))$('#quick-errors').open=true;
   toast(pauseReason||`Готово: ${ok} книг сохранено офлайн. Ошибок: ${failures}.`);
  }
}
async function offlineDownload(){return downloadList([...lastVisible],'Выбранные произведения')}
async function offlineDownloadAll(){return downloadList(BOOKS,'Вся библиотека')}
function updateOfflineStatus(note=''){
 const el=$('#offline-status');if(!el)return;
 const catalog=BOOKS;
 const total=catalog.length,have=catalog.filter(b=>cachedIds.has(b.id)).length;
 el.textContent=`Готово без интернета: ${have} из ${total} произведений. Встроено: ${embeddedIds.size}.`+(note?' '+note:'');
 const button=$('#download-all');
 if(button){button.disabled=bulkDownloading||have===total||!db||!navigator.onLine;button.textContent=bulkDownloading?'Загрузка…':have===total?'Всё сохранено':'Загрузить все остальные';}
 $('#download-view').disabled=bulkDownloading||!db||!navigator.onLine||!lastVisible.some(book=>!cachedIds.has(book.id)&&book.sourceType!=='local');
 const report=$('#offline-error-report');
 const failures=failedBooks().length;
 report.classList.toggle('hidden',!failures||bulkDownloading);
 report.textContent=`Ошибки загрузки (${failures})`;
 const cancel=$('#cancel-download');if(cancel)cancel.classList.toggle('hidden',!bulkDownloading);
 updateQuickStatus(note);
}
async function exportOfflineTexts(){
 try{
 const local=await dbAll('texts');const map=new Map(local.filter(x=>x?.id&&Array.isArray(x.blocks)).map(x=>[x.id,x]));
 Object.entries(EMBEDDED).forEach(([id,doc])=>{if(!map.has(id)||catalogById.get(id)?.textRevision)map.set(id,doc);});
 const own=await dbAll('custom');
 downloadJson('lukomorye-books-offline.json',{app:'Lukomorye',type:'offline-library',version:1,exported:new Date().toISOString(),texts:[...map.values()],custom:own});
 toast(`Сохранено произведений: ${map.size}.`);
 }catch(e){toast('Не удалось экспортировать библиотеку');console.error(e)}
}
function normalizeCustomBook(book){
 if(!book||!validBookId(book.id)||!book.id.startsWith('local-')||typeof book.title!=='string'||!book.title.trim())return null;
 return {
  id:book.id,title:book.title.trim().slice(0,400),
  author:typeof book.author==='string'?book.author.slice(0,300):'Из личной коллекции',
  category:'Мои книги',sourceType:'local',
  minutes:Number.isFinite(book.minutes)&&book.minutes>0?book.minutes:1,
  description:typeof book.description==='string'?book.description.slice(0,1200):'Личная библиотека',
  reference:typeof book.reference==='string'?book.reference.slice(0,400):'',
 };
}
function normalizeBookText(doc){
 if(!doc||!validBookId(doc.id)||!Array.isArray(doc.blocks)||!doc.blocks.length||doc.blocks.length>15000)return null;
 const blocks=[];
 for(const block of doc.blocks){
  if(typeof block?.text!=='string'||!block.text.trim()||block.text.length>15*1024*1024)return null;
  const tag=['p','h2','h3','h4','blockquote','verse'].includes(block.tag)?block.tag:'p';
  blocks.push({tag,text:block.text});
 }
 const words=blocks.reduce((sum,block)=>sum+countWords(block.text),0);
 if(!words)return null;
 return {id:doc.id,blocks,words,page:typeof doc.page==='string'?doc.page.slice(0,600):'',
  edition:typeof doc.edition==='string'?doc.edition.slice(0,400):'',sourceUrl:trustedBookSource(doc.sourceUrl),downloadedAt:Date.now()};
}
async function importOfflineTexts(file){
 if(!file)return;
 let count=0,skipped=0;
 try{
  const data=JSON.parse(await file.text());
  if(data?.app!=='Lukomorye'||data.type!=='offline-library'||!Array.isArray(data.texts)||data.texts.length>1000)throw new Error('Неверный формат');
  const custom=new Map();
  for(const item of Array.isArray(data.custom)?data.custom:[]){
   const book=normalizeCustomBook(item);
   if(book)custom.set(book.id,book);
  }
  for(const item of data.texts){
   if(embeddedIds.has(item?.id)&&!item.downloadedAt)continue;
   const doc=normalizeBookText(item);
   const book=custom.get(doc?.id)||importedBooks.find(item=>item.id===doc?.id);
   if(!doc||(!catalogIds.has(doc.id)&&!book)){skipped++;continue;}
   await saveBookText(doc,book);
   sessionTexts.delete(doc.id);
   if(book)rememberBook(book);
   cachedIds.add(doc.id);
   forgetDownloadFailure(doc.id);
   count++;
  }
  toast(`Импортировано офлайн-текстов: ${count}. Пропущено: ${skipped}.`);
 }catch(e){console.error(e);toast(`Импорт прерван. Сохранено текстов: ${count}.`);}
 finally{$('#import-offline').value='';renderGenres();render();}
}
function moveBook(step){
 if(!current)return;
 const id=readerOrder[readerOrder.indexOf(current.id)+step];
 if(id)openBook(id);
}
function changeFontStep(delta){const next=Math.min(32,Math.max(17,Number(settings.font)+delta));keepReaderAnchor(()=>{settings.font=next;saveSettings()});}
function closeQuickPanel(){$('#reader-quick-panel').classList.add('hidden');$('#reader-settings').setAttribute('aria-expanded','false')}
function toggleQuickPanel(){const panel=$('#reader-quick-panel');const show=panel.classList.contains('hidden');panel.classList.toggle('hidden',!show);$('#reader-settings').setAttribute('aria-expanded',String(show));}
function isPwaInstalled(){return Boolean(window.matchMedia?.('(display-mode: standalone)').matches||navigator.standalone===true)}
function isWebHost(){return !fileEdition&&(location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1')}
function updateInstallStatus(){
 const status=$('#app-install-status');
 if(!isWebHost()){status.textContent='Автономный файл уже готов к чтению.';return;}
 const worker=navigator.serviceWorker;
 status.textContent=worker?.controller?.scriptURL===new URL('./sw.js',location.href).href?'Приложение и встроенные книги готовы к работе без сети.':
  worker?'При первом открытии браузер сохраняет приложение и встроенные книги.':'Этот браузер не поддерживает автономную установку PWA.';
}
async function prepareOfflineApp(){
 if(!isWebHost()||!('serviceWorker' in navigator))return;
 const worker=navigator.serviceWorker;
 worker.addEventListener('controllerchange',updateInstallStatus);
 try{
  const scope=new URL('./',location.href).href;
  const existing=await worker.getRegistration(scope);
  if(existing?.scope!==scope)await worker.register('./sw.js',{scope:'./',updateViaCache:'none'});
 }catch(error){
  $('#app-install-status').textContent='Сохранить приложение для работы без сети пока не удалось.';
  console.warn('PWA offline unavailable',error);
 }
}
async function requestAppInstall(){
 if(isPwaInstalled()){toast('Приложение уже установлено');return;}
 if(deferredInstall){
  const prompt=deferredInstall;deferredInstall=null;
  try{await prompt.prompt();const choice=await prompt.userChoice;
   if(choice?.outcome==='accepted')toast('Установка запущена');else toast('Установка не выполнена');
  }catch(e){toast('Не удалось открыть окно установки: используйте меню браузера');}
  updateInstallStatus();return;
 }
 if(!isWebHost()){toast('Установка PWA из локального HTML недоступна. Разместите ZIP на HTTPS-сайте.');return;}
 toast(/iPad|iPhone|iPod/.test(navigator.userAgent)?'Safari → Поделиться → На экран Домой.':'Откройте меню браузера → Установить приложение (или Добавить на главный экран).');
 updateInstallStatus();
}
function focusCatalogSearch(){
 const input=$('#search');
 input.scrollIntoView({block:'center',behavior:'instant'});
 input.focus({preventScroll:true});
}
function wire(){
 $('#header-search').addEventListener('click',focusCatalogSearch);
 $('#search').addEventListener('keydown',event=>{
  if(event.key!=='Enter')return;
  event.preventDefault();
  event.currentTarget.blur();
  $('#books').scrollIntoView({block:'start',behavior:'smooth'});
 });
 $('#nav').addEventListener('click',e=>{const n=e.target.closest('[data-nav]');if(n)navTo(n.dataset.nav)});$('#category-tabs').addEventListener('click',e=>{const n=e.target.closest('[data-tab]');if(n)navTo(n.dataset.tab)});$('#genres').addEventListener('click',e=>{const n=e.target.closest('[data-genre]');if(n)navTo(n.dataset.genre)});$$('[data-nav-action]').forEach(el=>el.addEventListener('click',()=>navTo(el.dataset.navAction)));$('#home-brand').addEventListener('click',e=>{e.preventDefault();showHome()});$('#top-home').addEventListener('click',showHome);
 $('#top-back').addEventListener('click',()=>history.state?.lukoDepth?history.back():showHome());
 $('#reader-home').addEventListener('click',()=>{
  if(history.state?.lukoReader){homeAfterReader=true;closeReader();}
  else{closeReader();showHome();}
 });$('#hero-all').addEventListener('click',()=>{navTo('all');$('#books').scrollIntoView({behavior:'smooth'})});$('#hero-continue').addEventListener('click',()=>{const last=books.filter(b=>getInfo(b).updated&&!getInfo(b).done).sort((a,b)=>getInfo(b).updated-getInfo(a).updated)[0];if(last)openBook(last.id);else navTo('all')});
 document.addEventListener('click',e=>{const down=e.target.closest('[data-download]');if(down){e.preventDefault();downloadSingle(down.dataset.download);return}const fav=e.target.closest('[data-fav]');if(fav){setFav(fav.dataset.fav);return}const go=e.target.closest('[data-open]');if(go){openBook(go.dataset.open);return}const remove=e.target.closest('[data-remove]');if(remove){const k=remove.dataset.remove;if(k==='search'){searchText='';$('#search').value=''}if(k==='time'){timeFilter='all';$('#time-filter').value='all'}if(k==='age'){ageFilter='all';$('#age-filter').value='all'}if(k==='country'){countryFilter='all';$('#country-filter').value='all'}pageLimit=24;render()}});
 $('#search').addEventListener('input',e=>{searchText=e.target.value;pageLimit=24;render()});$('#clear-search').addEventListener('click',()=>{$('#search').value='';searchText='';pageLimit=24;render()});$('#time-filter').addEventListener('change',e=>{timeFilter=e.target.value;pageLimit=24;render()});$('#country-filter').addEventListener('change',e=>{countryFilter=e.target.value;pageLimit=24;render()});$('#age-filter').addEventListener('change',e=>{ageFilter=e.target.value;pageLimit=24;render()});$('#sort-filter').addEventListener('change',e=>{sortBy=e.target.value;pageLimit=24;render()});$('#load-more').addEventListener('click',()=>{pageLimit+=24;render()});$('#reset-filters').addEventListener('click',()=>{searchText='';timeFilter='all';ageFilter='all';$('#search').value='';$('#time-filter').value='all';$('#age-filter').value='all';countryFilter='all';$('#country-filter').value='all';sortBy='popular';$('#sort-filter').value='popular';pageLimit=24;render()});
 $('#menu-toggle').addEventListener('click',()=>{$('#sidebar').classList.add('mobile-open');$('#mobile-scrim').classList.remove('hidden')});$('#mobile-scrim').addEventListener('click',()=>{$('#sidebar').classList.remove('mobile-open');$('#mobile-scrim').classList.add('hidden')});
 $('#reader-immersive-enter').addEventListener('click',()=>setImmersive(true));$('#reader-immersive-exit').addEventListener('click',()=>setImmersive(false));document.addEventListener('fullscreenchange',()=>{if(immersive&&document.fullscreenElement!==$('#reader'))setImmersive(false,false)});$('#reader-back').addEventListener('click',()=>closeReader());$('#reader-scroll').addEventListener('scroll',readingScroll,{passive:true});$('#reader-favorite').addEventListener('click',()=>current&&setFav(current.id));$('#toc-toggle').addEventListener('click',()=>$('#reader-aside').classList.toggle('open'));$('#toc-close').addEventListener('click',()=>$('#reader-aside').classList.remove('open'));$('#toc-items').addEventListener('click',e=>{const b=e.target.closest('[data-go]');if(b){jumpPara(Number(b.dataset.go));$$('[data-go]').forEach(n=>n.classList.toggle('active',n===b))}});$('#listen-btn').addEventListener('click',toggleSpeech);$('#mark-done').addEventListener('click',()=>markDone(true));$('#mark-unread').addEventListener('click',()=>markDone(false));$('#footer-done').addEventListener('click',()=>markDone(!getInfo(current).done));$('#save-position').addEventListener('click',()=>{if(!currentDoc){toast('Сначала загрузите книгу');return}readingScroll();flushReadingPosition();toast('Место чтения сохранено')});$('#next-book').addEventListener('click',()=>moveBook(1));
 $('#prev-book').addEventListener('click',()=>moveBook(-1));
 $('#finish-prev-book').addEventListener('click',()=>moveBook(-1));
 $('#reader-next-book').addEventListener('click',()=>moveBook(1));
 window.addEventListener('popstate',e=>{
  const id=e.state?.lukoReader;
  if(homeAfterReader){homeAfterReader=false;showHome();return;}
  const destination=e.state?.lukoView||'all';
  if(!id)closeReader(true);
  if(destination!==view)navTo(destination,false);
  else updateLibraryBack();
  if(id&&id!==current?.id)openBook(id,false);
 });
 const openSettings=()=>{
  $('#sidebar').classList.remove('mobile-open');
  $('#mobile-scrim').classList.add('hidden');
  $('#settings-dialog').showModal();
 };
 $('#settings-immersive').addEventListener('click',()=>{if($('#reader').classList.contains('hidden')){toast('Сначала откройте книгу');return}$('#settings-dialog').close();setImmersive(true)});
 $('#paper-style').addEventListener('change',e=>{keepReaderAnchor(()=>{settings.paper=e.target.value;saveSettings()})});
 $('#paper-bg').addEventListener('input',e=>{settings.paperBg=e.target.value;saveSettings()});
 $('#paper-text').addEventListener('input',e=>{settings.paperText=e.target.value;saveSettings()});
 $('#reader-wide').addEventListener('change',e=>{keepReaderAnchor(()=>{settings.wide=e.target.checked;saveSettings()})});
 $('#reader-font').addEventListener('change',e=>{keepReaderAnchor(()=>{settings.fontFamily=e.target.value;saveSettings()})});
$('#open-settings').addEventListener('click',openSettings);
 $('#reader-settings').addEventListener('click',toggleQuickPanel);
 $('#quick-close').addEventListener('click',closeQuickPanel);
 $('#quick-minus').addEventListener('click',()=>changeFontStep(-1));
 $('#quick-plus').addEventListener('click',()=>changeFontStep(1));
 $('#font-minus').addEventListener('click',()=>changeFontStep(-1));
 $('#font-plus').addEventListener('click',()=>changeFontStep(1));
 $('#quick-full-settings').addEventListener('click',()=>{closeQuickPanel();openSettings()});
 $$('[data-quick-paper]').forEach(btn=>btn.addEventListener('click',()=>keepReaderAnchor(()=>{settings.paper=btn.dataset.quickPaper;saveSettings()})));
 document.addEventListener('pointerdown',e=>{if(!e.target.closest('#reader-quick-panel,#reader-settings'))closeQuickPanel()});$('#font-size').addEventListener('input',e=>{keepReaderAnchor(()=>{settings.font=Number(e.target.value);saveSettings()})});$('#line-height').addEventListener('change',e=>{keepReaderAnchor(()=>{settings.line=e.target.value;saveSettings()})});$('#reading-speed').addEventListener('change',e=>{settings.speed=Number(e.target.value);saveSettings();render();
 if(currentDoc){
  currentDoc.minutes=readingMinutes(currentDoc.words);
  const detail=`${formatDuration(currentDoc.minutes)} · ${currentDoc.words.toLocaleString('ru')} слов`;
  $('#reader-duration').textContent=detail;$('#reader-aside-time').textContent=detail;updateProgressUI();
 }});$('#theme-toggle').addEventListener('click',()=>{settings.theme=settings.theme==='light'?'sepia':settings.theme==='sepia'?'dark':'light';saveSettings()});$$('[data-theme-option]').forEach(b=>b.addEventListener('click',()=>{settings.theme=b.dataset.themeOption;saveSettings()}));$('#download-view').addEventListener('click',offlineDownload);
 $('#download-all').addEventListener('click',offlineDownloadAll);
 window.addEventListener('online',()=>updateOfflineStatus());
 window.addEventListener('offline',()=>updateOfflineStatus());
 $('#quick-download').addEventListener('click',()=>downloadList([...lastVisible],'Выбранный раздел'));
 $('#quick-stop').addEventListener('click',()=>{stopBulk=true;toast('Останавливаем после текущего произведения')});
 $('#cancel-download').addEventListener('click',()=>{stopBulk=true;toast('Загрузка будет остановлена после текущей книги')});
 $('#offline-error-report').addEventListener('click',downloadErrorReport);
 $('#quick-error-report').addEventListener('click',downloadErrorReport);
 $('#export-offline').addEventListener('click',exportOfflineTexts);
 $('#import-offline').addEventListener('change',e=>importOfflineTexts(e.target.files?.[0]));
 $('#export-progress').addEventListener('click',()=>{downloadJson('lukomorye-progress.json',{version:2,created:new Date().toISOString(),progress,favorites:[...favorites],settings});toast('Резервная копия прогресса сохранена')});$('#import-progress').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;const data=JSON.parse(await file.text());if(!data.progress||typeof data.progress!=='object'||Array.isArray(data.progress))throw new Error('Неизвестный формат');progress={...progress,...validProgress(data.progress)};favorites=new Set([...favorites,...validFavorites(data.favorites)]);if(data.settings&&typeof data.settings==='object'&&!Array.isArray(data.settings)){settings={...settings,...Object.fromEntries(Object.keys(defaultSettings).filter(key=>Object.hasOwn(data.settings,key)).map(key=>[key,data.settings[key]]))};applySettings();safeSet('luko-settings',JSON.stringify(settings));}safeSet('luko-favorites',JSON.stringify([...favorites]));saveProgress();render();toast('Прогресс восстановлен')}catch{toast('Не удалось восстановить файл прогресса')}finally{e.target.value=''}});
 $('#import-formats-help').addEventListener('click',()=>$('#formats-dialog').showModal());
 $('#offline-formats-help').addEventListener('click',()=>$('#formats-dialog').showModal());
 $('#export-reader-txt').addEventListener('click',exportCurrentTxt);
 $('#settings-install').addEventListener('click',requestAppInstall);
 $('#import-open').addEventListener('click',()=>{$('#import-dialog').showModal()});$('#book-import').addEventListener('change',e=>importBooks(e.target.files));$('#dropzone').addEventListener('dragover',e=>e.preventDefault());$('#dropzone').addEventListener('drop',e=>{e.preventDefault();importBooks(e.dataTransfer.files)});
 $('#sources-info').addEventListener('click',()=>window.open('https://ru.wikisource.org/wiki/Народные_русские_сказки_(Афанасьев)','_blank','noopener'));
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#reader').classList.contains('hidden')&&!$('#settings-dialog').open&&!$('#import-dialog').open){if(immersive){e.preventDefault();setImmersive(false)}else closeReader();}if(e.key==='/'&&$('#reader').classList.contains('hidden')&&!/input|textarea/i.test(document.activeElement.tagName)){e.preventDefault();$('#search').focus()}});
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;$('#install-btn').classList.remove('hidden');updateInstallStatus()});$('#install-btn').addEventListener('click',requestAppInstall);window.addEventListener('appinstalled',()=>{deferredInstall=null;$('#install-btn').classList.add('hidden');updateInstallStatus()});
}
async function init(){
 hydrateIcons();applySettings();updateInstallStatus();
 $('#installed-version').textContent='Установлена версия '+APP_VERSION;
 const updateButton=$('#check-app-update');
 const updateStatus=$('#app-update-status');
 if(fileEdition){
  updateButton.classList.add('hidden');
  updateStatus.textContent='Для обновления автономного файла нужен новый архив.';
 }else{
  window.LUKO_UPDATE.bind(updateButton,updateStatus,{currentVersion:APP_VERSION});
 }
 if(fileEdition){
  $('.sidebar-sub').textContent='Тексты из архива доступны без интернета';
  $('#settings-install').classList.add('hidden');
 }
 try{
  db=await dbOpen();
  const [custom,texts]=await Promise.all([dbAll('custom'),dbAll('texts')]);
  const saved=new Set(texts.filter(doc=>Array.isArray(doc?.blocks)&&doc.blocks.length&&Number.isFinite(doc.words)).map(doc=>doc.id));
  importedBooks=custom.map(normalizeCustomBook).filter(book=>book&&saved.has(book.id));
  books.push(...importedBooks);
  for(const doc of texts)if(saved.has(doc.id))rememberWords(doc);
  cachedIds=new Set([...embeddedIds,...books.filter(book=>saved.has(book.id)).map(book=>book.id)]);
 }catch(e){console.warn('No persistent library',e);toast('Хранилище недоступно: сохранение книг может не работать');}
 try{
 for(const id of downloadFailures.keys())if(cachedIds.has(id))downloadFailures.delete(id);
 if(Array.isArray(storedFailures)&&storedFailures.length!==downloadFailures.size)saveDownloadFailures();
 const state=history.state||{};
 if(!state.lukoView)history.replaceState({...state,lukoView:'all',lukoDepth:0},'');
 }catch{/* Reading remains available without browser history. */}
 wire();renderGenres();
 if(history.state?.lukoView&&history.state.lukoView!=='all')navTo(history.state.lukoView,false);
 else{updateLibraryBack();render();}
 if(history.state?.lukoReader)openBook(history.state.lukoReader,false,false);
 prepareOfflineApp();
}
init();
})();
