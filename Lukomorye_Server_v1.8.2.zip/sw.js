'use strict';

const scope = self.registration.scope;
const prefix = 'lukomorye-shell:' + scope + ':';
const cacheName = prefix + '1.8.2-f8265e016d4d9a1a';
const releaseVersion = cacheName.slice(prefix.length).split('-')[0];
const assets = new Map(Object.entries({
  "offline-shell.txt": "sha256-aRG3dN284mTTN5LPFdbscEpwxck+Ev3jt80DQOnxqfE=",
  "styles.css": "sha256-JnDLHt8Xc8zYmU8Qdc/Afk7tcm+zfwiF6MP0BNW3MDI=",
  "catalog.js": "sha256-Fh64JUicPL/nYY75T1FnLvkLsejwlylHwzTA/fobwf8=",
  "offline_docs.js": "sha256-MPdm8A5lDvfBebJkupnGUwu3k2+nM8LNa1dbA39BEWk=",
  "update.js": "sha256-uCqIr7dy+Mp0KRi5L084rfNoRCm/rTzOh+pNY8E81V0=",
  "app.js": "sha256-6JL98vcYcwKcD1P2Xh2ANthOdMl+YT/Eb+8R75GqE/0=",
  "manifest.webmanifest": "sha256-IyvIvDMzEKueN2dBEj/WItW3UG5W0g8puJPf8s/DOrU=",
  "icons/icon-128.png": "sha256-mw9aoeiIc7tF9fhbzPRNQ2Ey7PBMnVSwd4bfjq5x83E=",
  "icons/icon-180.png": "sha256-ejAygwEvNUA4dRqWANwHvsIMHzEwLtYfhXyID5g9FrA=",
  "icons/icon-192.png": "sha256-PDR0zqAwsUbxEOSZ+cwhmZDDZnPMpNAd6vcWjl6B9VY=",
  "icons/icon-32.png": "sha256-rPaZZ+aCHvx0aJXNTj5geyxYvNw/73ekkUqYyHrp2Mg=",
  "icons/icon-512.png": "sha256-UPi/AUY+gHh+icFOtn8iH7t3eArwy1jCqtWOCLiKgQ4=",
  "icons/icon-maskable-512.png": "sha256-UOan44HGBAD2JzkwNJGzZfBv8CQHv5zpU/VAqfI0C9U="
}).map(([file, integrity]) =>
  [new URL(file, scope).href, integrity]
));
const entry = new URL('./', scope).href;
const entryFile = new URL('index.html', scope).href;
const offlineShell = new URL('offline-shell.txt', scope).href;

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    try {
      const cache = await caches.open(cacheName);
      await cache.addAll(Array.from(assets, ([url, integrity]) => new Request(url, { cache: 'reload', integrity })));
      const shell = await cache.match(offlineShell);
      // The hosting platform may append a per-request script to HTML responses.
      await cache.put(entry, new Response(await shell.text(), {
        headers: { 'Content-Type': 'text/html; charset=utf-8' },
      }));
      // Older clients cannot request activation themselves. The full shell is ready before takeover.
      await self.skipWaiting();
    } catch (error) {
      await caches.delete(cacheName);
      throw error;
    }
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith(prefix) && key !== cacheName)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  if (event.data?.type === 'ACTIVATE_UPDATE') event.waitUntil(self.skipWaiting());
  if (event.data?.type === 'LUKO_VERSION') {
    event.ports[0]?.postMessage({ type: 'LUKO_VERSION', version: releaseVersion });
  }
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  url.search = '';
  const isEntry = request.mode === 'navigate' && (url.href === entry || url.href === entryFile);
  const cacheKey = isEntry ? entry : url.href;
  if (!isEntry && !assets.has(cacheKey)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    return await cache.match(cacheKey) || Response.error();
  })());
});
