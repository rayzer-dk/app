'use strict';

(() => {
  const releasePattern = /^\d{1,6}\.\d{1,6}\.\d{1,6}$/;
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  function compareVersions(a, b) {
    const left = a.split('.').map(Number);
    const right = b.split('.').map(Number);
    return left[0] - right[0] || left[1] - right[1] || left[2] - right[2];
  }

  function workerVersion(worker) {
    if (!worker) return Promise.resolve(null);
    return new Promise(resolve => {
      const channel = new MessageChannel();
      let timer;
      function finish(value) {
        clearTimeout(timer);
        channel.port1.close();
        resolve(value);
      }
      channel.port1.onmessage = ({ data }) => {
        finish(data?.type === 'LUKO_VERSION' && releasePattern.test(data.version) ? data.version : null);
      };
      timer = setTimeout(() => finish(null), 800);
      try {
        worker.postMessage({ type: 'LUKO_VERSION' }, [channel.port2]);
      } catch {
        channel.port2.close();
        finish(null);
      }
    });
  }

  async function serverVersion(scope) {
    const url = new URL('version.json', scope);
    url.searchParams.set('check', Date.now());
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 12000);
    try {
      const response = await fetch(url, { cache: 'no-store', signal: abort.signal });
      if (!response.ok) throw new Error('Сервер не вернул сведения о версии.');
      const { version } = await response.json();
      if (!releasePattern.test(version)) throw new Error('Сервер вернул неверный номер версии.');
      return version;
    } finally {
      clearTimeout(timer);
    }
  }

  async function waitForRelease(registration, expected) {
    const versions = new WeakMap();
    function check(worker) {
      if (!versions.has(worker)) versions.set(worker, workerVersion(worker));
      return versions.get(worker);
    }
    const deadline = Date.now() + 55000;
    while (Date.now() < deadline) {
      const active = registration.active;
      if (active?.state === 'activated') {
        const version = await check(active);
        if (version && compareVersions(version, expected) >= 0) return version;
      }
      const waiting = registration.waiting;
      if (waiting) {
        const version = await check(waiting);
        if (version && compareVersions(version, expected) >= 0) {
          waiting.postMessage({ type: 'ACTIVATE_UPDATE' });
        }
      }
      if (!navigator.onLine) throw new Error('Соединение пропало во время установки.');
      await delay(250);
    }
    throw new Error('Установка кеша заняла слишком много времени. Повторите попытку при стабильном соединении.');
  }

  async function install(currentVersion, setStatus) {
    if (!navigator.onLine) throw new Error('Для проверки обновлений подключитесь к интернету.');
    if (!navigator.serviceWorker) throw new Error('Этот браузер не поддерживает обновления PWA.');
    const scope = new URL('./', location.href);
    setStatus('Проверяем обновления…');
    const latest = await serverVersion(scope);
    const target = currentVersion && compareVersions(currentVersion, latest) > 0 ? currentVersion : latest;
    const workerApi = navigator.serviceWorker;
    const existing = await workerApi.getRegistration(scope.href);
    let registration = existing?.scope === scope.href ? existing : null;
    if (registration?.active?.state === 'activated') {
      const version = await workerVersion(registration.active);
      if (version && compareVersions(version, target) >= 0) return { version, scope };
    }

    setStatus('Загружаем версию ' + target + ' и готовим её для работы без сети…');
    if (registration) {
      await registration.update();
    } else {
      registration = await workerApi.register('./sw.js', { scope: './', updateViaCache: 'none' });
    }
    const version = await waitForRelease(registration, target);
    return { version, scope };
  }

  window.LUKO_UPDATE = {
    bind(button, status, { currentVersion = '', recovery = false } = {}) {
      button.addEventListener('click', async () => {
        button.disabled = true;
        try {
          const { version, scope } = await install(currentVersion, message => { status.textContent = message; });
          if (recovery || currentVersion !== version) {
            status.textContent = 'Версия ' + version + ' готова. Открываем библиотеку…';
            if (recovery) location.replace(scope.href);
            else location.reload();
            return;
          }
          status.textContent = 'Установлена актуальная версия ' + version + '.';
        } catch (error) {
          const detail = error?.name === 'AbortError' ? 'Сервер не ответил вовремя.' : error?.message;
          status.textContent = 'Обновление пока не завершено. ' + (detail || 'Повторите попытку позже.');
          button.disabled = false;
          return;
        }
        button.disabled = false;
      });
    }
  };

  const recoveryButton = document.querySelector('#recovery-update');
  if (recoveryButton) {
    window.LUKO_UPDATE.bind(recoveryButton, document.querySelector('#recovery-status'), { recovery: true });
  }
})();
