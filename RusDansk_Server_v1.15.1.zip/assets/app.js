/* RusDansk — all dictionary data is bundled. */
'use strict';
(()=>{
const $=id=>document.getElementById(id);
const seed=Array.isArray(window.RUSDANSK_SEED)?window.RUSDANSK_SEED:[];
const extra=window.RUSDANSK_EXTRA||{kaikki:[],tatoeba:[],forms:{},meta:{}}; const COREXT=window.RUSDANSK_COREXT||{forms:{},meta:{}};
const extraMeta=extra.meta||{};
const CATEGORIES=['Все','Общение','Люди','Покупки','Еда и напитки','Транспорт и город','Дом и быт','Здоровье','Работа и документы','Природа и погода','Время','Числа','Глаголы','Прилагательные','Дополнительные фразы','Примеры Tatoeba','Дополненные слова','Мои слова'];
const VIEWS={translate:'Переводчик',phrases:'Разговорник',favorites:'Избранное',dictionaries:'Словари',settings:'Настройки'};
const norm=v=>String(v??'').normalize('NFKC').toLocaleLowerCase('ru').replaceAll('ё','е').replace(/[“”„«»]/g,'"').replace(/\s+/g,' ').trim();
const clean=v=>norm(v).replace(/([а-я])\u0301/g,'$1').replace(/[.!?…,:;]+$/g,'').trim();
const lookup = (table, key) => table && Object.hasOwn(table, key) ? table[key] : undefined;
const formatCount=v=>Number(v).toLocaleString('ru-RU');
function load(key,fallback){try{const s=localStorage.getItem('rusdansk:'+key);return s===null?fallback:JSON.parse(s)}catch{return fallback}}
function store(key,data){try{localStorage.setItem('rusdansk:'+key,JSON.stringify(data));return true}catch{return false}}
const DIRECTIONS=['ru-da','da-ru','ru-en','en-ru','da-en','en-da'];
const personal = load('personal', null);
const state={direction:DIRECTIONS.includes(load('direction','ru-da'))?load('direction','ru-da'):'ru-da',theme:load('theme','light'),custom:personal?.custom ?? load('custom',[]),favorites:personal?.favorites ?? load('favorites',[]),packs:window.RUSDANSK_PACKS||{'ru-da':[],'da-ru':[]},view:'translate',category:'Все',phraseLimit:24,resultLimit:8,translation:null,selectedVariant:null,sourceFilter:load('sourceFilter','all')};
if(!Array.isArray(state.custom))state.custom=[];
if(!Array.isArray(state.favorites))state.favorites=[];
function savePersonal(custom, favorites) {
  if (!store('personal', { custom, favorites })) return false;
  state.custom = custom;
  state.favorites = favorites;
  return true;
}
let allItems={'ru-da':[],'da-ru':[],'ru-en':[],'en-ru':[],'da-en':[],'en-da':[]},exact={'ru-da':new Map(),'da-ru':new Map(),'ru-en':new Map(),'en-ru':new Map(),'da-en':new Map(),'en-da':new Map()},toastTimer=null,typingTimer=null;
function icon(name){const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','ico');svg.setAttribute('aria-hidden','true');const use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href','#i-'+name);svg.append(use);return svg}
function buttonIcon(name,label,fn,classes='tool-icon'){const el=document.createElement('button');el.type='button';el.className=classes;el.setAttribute('aria-label',label);el.title=label;el.append(icon(name));el.addEventListener('click',fn);return el}
function toast(message){$('toastText').textContent=message;$('toast').classList.add('is-visible');if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('is-visible'),2450)}
function setTheme(value){state.theme=value==='dark'?'dark':'light';document.body.classList.toggle('theme-dark',state.theme==='dark');store('theme',state.theme);const next=state.theme==='dark'?'sun':'moon';for(const id of ['themeButton','themeSetting']){const b=$(id);if(!b)continue;const u=b.querySelector('use');if(u)u.setAttribute('href','#i-'+next)}}
function item(ru,da,cat,source,dir){let from=dir==='ru-da'?ru:da,to=dir==='ru-da'?da:ru;return {ru,da,from,to,cat,source,dir,id:norm(ru)+'\u001f'+norm(da)}}
function importedItem(from,to,dir){const ru=dir==='ru-da'?from:to,da=dir==='ru-da'?to:from;return item(ru,da,'WikDict','pack',dir)}
const MULTI=window.RUSDANSK_MULTI||{pairs:{},meta:{}};
const multiIndex={};for(const dir of ['ru-en','en-ru','da-en','en-da'])multiIndex[dir]=new Map((MULTI.pairs[dir]||[]).map(row=>[clean(row[0]),row]));
function genericItem(from,to,cat,source,dir){return {from,to,cat,source,dir,id:dir+'\u001f'+norm(from)+'\u001f'+norm(to)};}
function multiRows(value,dir){const group=multiIndex[dir]?.get(clean(value));if(!group)return [];return group[1].map(([to,source])=>genericItem(group[0],to,'Словарь',source,dir));}
function searchMulti(value,dir,max=120){const q=clean(value);if(!q)return [];const result=[],arr=MULTI.pairs[dir]||[];const ex=multiIndex[dir]?.get(q);if(ex){for(const [to,source] of ex[1])result.push(genericItem(ex[0],to,'Словарь',source,dir))}for(const [head,values] of arr){if(result.length>=max)break;if(clean(head)===q||!clean(head).startsWith(q))continue;for(const [to,source] of values.slice(0,3)){result.push(genericItem(head,to,'Словарь',source,dir));if(result.length>=max)break}}return result;}
function bridgeRows(value,dir){if(!['ru-da','da-ru'].includes(dir))return [];const q=clean(value);if(!q||q.includes(' ')||q.length>65)return [];const baseDir=dir==='ru-da'?'ru-en':'da-en',outDir=dir==='ru-da'?'en-da':'en-ru';const lemmas=dir==='da-ru'?[...(Array.isArray(lookup(extra.forms, q))?extra.forms[q]:(lookup(extra.forms, q)?[extra.forms[q]]:[])),...(Array.isArray(lookup(COREXT.forms, q))?COREXT.forms[q]:(lookup(COREXT.forms, q)?[COREXT.forms[q]]:[]))]:(lookup(MULTI.forms?.['ru-en'], q)||[]);const words=[q,...(Array.isArray(lemmas)?lemmas:lemmas?[lemmas]:[])];const ewords=[];for(const w of words.slice(0,4)){const lex=multiRows(w,baseDir);for(const entry of lex.slice(0,5))ewords.push(entry.to);if(dir==='da-ru'&&lookup(extra.glosses, w))for(const gloss of lookup(extra.glosses, w).slice(0,2))if(/^[A-Za-z -]{2,32}$/.test(gloss))ewords.push(gloss)}const seen=new Set(),rows=[];for(const en of ewords.slice(0,8)){for(const entry of multiRows(en,outDir).slice(0,3)){if(seen.has(clean(entry.to)))continue;seen.add(clean(entry.to));const row=genericItem(value,entry.to,'Перевод через английский','bridge',dir);row.via=en;rows.push(row);if(rows.length>=8)return rows;}}return rows;}
function activeFilters(){return ['ru-da','da-ru'].includes(state.direction)?['all','pack','reverse','kaikki','tatoeba','cor','corext','curated','base','custom','bridge']:(['ru-en','en-ru'].includes(state.direction)?['all','freedict','koreader']:['all','wik-en',...(state.direction==='da-en'?['cor','corext']:[])]);}
function sourceKind(row){return ['pack','reverse','kaikki','tatoeba','cor','corext','curated','custom','freedict','koreader','wik-en','bridge'].includes(row.source)?row.source:'base'}
function sourceTitle(kind){const ru=state.direction==='ru-da';return kind==='pack'?'WikDict '+(ru?'RU → DA':'DA → RU'):kind==='reverse'?'WikDict · обратный поиск':kind==='kaikki'?'Kaikki · Викисловарь':kind==='tatoeba'?'Tatoeba · предложения':kind==='cor'?'COR · словоформы':kind==='corext'?'COR.EXT · словоформы':kind==='curated'?'Дополненные слова':kind==='freedict'?'FreeDict':kind==='koreader'?'KOReader':kind==='wik-en'?'WikDict EN ↔ DA':kind==='bridge'?'Через английский (приблизительно)':kind==='base'?'Разговорник':kind==='custom'?'Мои слова':'Все источники'}
function sourceAllowed(row){return state.sourceFilter==='all'||sourceKind(row)===state.sourceFilter}
function renderSourceFilters(){const box=$('sourceFilters');if(!box)return;box.replaceChildren();for(const kind of activeFilters()){const button=document.createElement('button');button.type='button';button.className='source-filter'+(state.sourceFilter===kind?' is-selected':'');button.textContent=sourceTitle(kind);button.setAttribute('aria-pressed',String(state.sourceFilter===kind));button.addEventListener('click',()=>{state.sourceFilter=kind;state.selectedVariant=null;state.resultLimit=8;store('sourceFilter',kind);renderSourceFilters();runTranslation()});box.append(button)}}
function morphologyRows(value,dir){
 const q=clean(value);
 let lemmas=[];
 if(dir.startsWith('da-')){
  const original=lookup(extra.forms, q),extension=lookup(COREXT.forms, q);
  const known=Array.isArray(original)?original:(original?[original]:[]);
  const more=Array.isArray(extension)?extension:(extension?[extension]:[]);
  lemmas=[...new Set([...known,...more])];
 }
 if(dir==='ru-en'||dir==='en-ru'){
  const direct=lookup(MULTI.forms?.[dir], q);if(direct)lemmas.push(direct);
  if(dir==='en-ru'&&q.length>4){
   // Restricted orthographic fallback for common English verb and noun inflections.
   if(q.endsWith('ies'))lemmas.push(q.slice(0,-3)+'y');
   if(q.endsWith('es'))lemmas.push(q.slice(0,-2),q.slice(0,-1));
   if(q.endsWith('s'))lemmas.push(q.slice(0,-1));
   if(q.endsWith('ing'))lemmas.push(q.slice(0,-3),q.slice(0,-3)+'e');
   if(q.endsWith('ed'))lemmas.push(q.slice(0,-2),q.slice(0,-1));
  }
 }
 if(!lemmas.length)return [];
 const result=[],used=new Set();
 for(const lemma of [...new Set(lemmas)].slice(0,7)){
  const pool=[...(exact[dir]?.get(clean(lemma))||[]),...multiRows(lemma,dir)];
  for(const original of pool){if(['tatoeba','custom'].includes(original.source))continue;
   const provider=dir.startsWith('da-') ? ((lookup(extra.forms, q)&&(Array.isArray(extra.forms[q])?extra.forms[q].includes(lemma):extra.forms[q]===lemma))?'cor':'corext') : original.source;
   const key = provider + '\u001f' + clean(original.to);
   if (used.has(key)) continue;
   used.add(key);
   const row=genericItem(value,original.to,'Словоформы',provider,dir);row.lemma=lemma;result.push(row);
   if(result.length>=15)return result;}
 }
 return result;
}
function displaySource(row){return sourceTitle(sourceKind(row))+(row.lemma?' · '+row.lemma:'')}
function getExactVariants(value,dir){const direct=[...(exact[dir]?.get(clean(value))||[]),...multiRows(value,dir),...morphologyRows(value,dir)];const pool=[...direct,...((dir==='ru-da'||dir==='da-ru')&&(direct.length<8||state.sourceFilter==='bridge')?bridgeRows(value,dir):[])].filter(sourceAllowed);const result=[],index=new Map();for(const row of pool){const key=clean(row.to);let group=index.get(key);if(!group){group={row,sources:[]};index.set(key,group);result.push(group)}const source=displaySource(row);if(!group.sources.includes(source))group.sources.push(source)}return result}
function renderVariants(value){const panel=$('variantsPanel'),list=$('variantsList');if(!panel||!list)return;list.replaceChildren();const variants=value?getExactVariants(value,state.direction):[];panel.hidden=variants.length<2;if(panel.hidden)return;$('variantsCount').textContent=String(variants.length);for(const group of variants.slice(0,20)){const b=document.createElement('button');b.type='button';b.className='variant-option'+(state.translation?.row&&clean(group.row.to)===clean(state.translation.row.to)?' is-selected':'');const headline=document.createElement('strong');headline.textContent=group.row.to;const meta=document.createElement('small');meta.textContent=group.sources.join(' · ');b.append(headline,meta);b.addEventListener('click',()=>{state.selectedVariant=clean(group.row.to);runTranslation()});list.append(b)}if(variants.length>20){const extra=document.createElement('span');extra.className='muted-text';extra.textContent='Показаны первые 20 вариантов';list.append(extra)}}
function rebuild(){const base={'ru-da':[],'da-ru':[]};for(const [ru,da,cat] of seed){base['ru-da'].push(item(ru,da,cat,'base','ru-da'));base['da-ru'].push(item(ru,da,cat,'base','da-ru'))}for(const pair of state.custom){if(!Array.isArray(pair)||!pair[0]||!pair[1])continue;base['ru-da'].unshift(item(pair[0],pair[1],'Мои слова','custom','ru-da'));base['da-ru'].unshift(item(pair[0],pair[1],'Мои слова','custom','da-ru'))}for(const dir of ['ru-da','da-ru']){for(const pair of state.packs[dir]){if(Array.isArray(pair)&&pair[0]&&pair[1])base[dir].push(importedItem(pair[0],pair[1],dir))}}
// Each source dictionary also provides reverse lookup for lexical pairs not present in the opposite volume.
// Primary directional dictionary matches remain first, so reverse matches do not displace their senses.
for(const dir of ['ru-da','da-ru']){
 const opposite=dir==='ru-da'?'da-ru':'ru-da';
 for(const pair of state.packs[opposite]){
  if(!Array.isArray(pair)||!pair[0]||!pair[1])continue;
  const row=importedItem(pair[1],pair[0],dir);
  row.source='reverse';
  base[dir].push(row);
 }
}
// Added source datasets are bilingual Russian-Danish pairs and can be searched either way.
for(const [ru,da] of extra.kaikki||[]){if(!ru||!da)continue;for(const dir of ['ru-da','da-ru'])base[dir].push(item(ru,da,'Kaikki','kaikki',dir))}
for(const [ru,da] of extra.curated||[]){if(!ru||!da)continue;for(const dir of ['ru-da','da-ru'])base[dir].push(item(ru,da,'Дополненные слова','curated',dir))}
for(const [ru,da] of extra.tatoeba||[]){if(!ru||!da)continue;for(const dir of ['ru-da','da-ru'])base[dir].push(item(ru,da,'Примеры Tatoeba','tatoeba',dir))}
for(const dir of ['ru-en','en-ru','da-en','en-da'])base[dir]=[];
allItems=base;exact={'ru-da':new Map(),'da-ru':new Map(),'ru-en':new Map(),'en-ru':new Map(),'da-en':new Map(),'en-da':new Map()};for(const dir of ['ru-da','da-ru']){for(const row of allItems[dir]){const key=clean(row.from);if(!key)continue;let list=exact[dir].get(key);if(!list){list=[];exact[dir].set(key,list)}if(list.length<100)list.push(row)}}updateStatistics()}
function updateStatistics(){const importedRu=window.RUSDANSK_PACK_META['ru-da'].articles,importedDa=window.RUSDANSK_PACK_META['da-ru'].articles;const newTotal=Object.values(MULTI.meta?.packed_pairs||{}).reduce((n,v)=>n+(v||0),0);$('totalWords').textContent=formatCount(seed.length+state.custom.length+importedRu+importedDa+(extraMeta.kaikki_ru_pairs||0)+(extraMeta.tatoeba_pairs||0)+(extraMeta.curated_pairs||0)+newTotal);$('baseStat').textContent=formatCount(seed.length);$('ruPackStat').textContent=formatCount(importedRu);$('daPackStat').textContent=formatCount(importedDa);for(const [id,n] of [['settingsRuPackStat',importedRu],['settingsDaPackStat',importedDa]]){const el=$(id);if(el)el.textContent=formatCount(n)}for(const [id,count] of [['kaikkiPackStat',extraMeta.kaikki_ru_pairs],['tatoebaPackStat',extraMeta.tatoeba_pairs],['formsPackStat',extraMeta.form_lookup_entries],['curatedPackStat',extraMeta.curated_pairs],['glossPackStat',extraMeta.english_gloss_lemmas]]){const el=$(id);if(el)el.textContent=formatCount(count||0)}$('favNavCount').textContent=formatCount(state.favorites.length);$('favNavCount').hidden=!state.favorites.length;$('customWordCount').textContent=state.custom.length?'Своих записей: '+formatCount(state.custom.length):'Нет собственных записей';const el=$('multiDictionaryStats');if(el){el.replaceChildren();for(const [dir,ids] of Object.entries({'en-ru':['freedict-en-ru','koreader-en-ru'],'ru-en':['freedict-ru-en','koreader-ru-en'],'en-da':['wikdict-en-da'],'da-en':['wikdict-da-en']})){const box=document.createElement('div');const name=document.createElement('small');name.textContent=dir.toUpperCase().replace('-',' → ');const val=document.createElement('strong');val.textContent=formatCount((MULTI.meta?.packed_pairs?.[dir]||0));box.append(name,val);el.append(box)}}}
function setView(v,recordHistory=true){
 if(!Object.hasOwn(VIEWS,v))return;
 if(recordHistory&&v!==state.view){
  try{history.pushState({rusDanskView:v,rusDanskDepth:(history.state?.rusDanskDepth||0)+1},'');}catch{}
 }
 state.view=v;
 $('appBackButton').disabled=!history.state?.rusDanskDepth&&v==='translate';document.querySelectorAll('.view').forEach(x=>x.classList.toggle('is-visible',x.id==='view-'+v));document.querySelectorAll('[data-view]').forEach(x=>{x.classList.toggle('is-active',x.dataset.view===v);if(x.dataset.view===v)x.setAttribute('aria-current','page');else x.removeAttribute('aria-current')});$('currentView').textContent=VIEWS[v];if(v==='favorites')renderFavorites();if(v==='phrases')renderPhrases();if(v==='dictionaries')renderCustom();window.scrollTo({top:0,behavior:'instant'})}
function getFavorite(id){return state.favorites.find(x=>x.id===id)}
function favItem(row) {
  const existing = getFavorite(row.id);
  const favorites = existing
    ? state.favorites.filter(entry => entry.id !== row.id)
    : [{id:row.id,ru:row.ru,da:row.da,from:row.from,to:row.to,dir:row.dir,source:row.source,cat:row.cat}, ...state.favorites];
  if (!savePersonal(state.custom, favorites)) {
    toast('Не удалось сохранить избранное в браузере');
    return;
  }
  toast(existing ? 'Удалено из избранного' : 'Добавлено в избранное');
  updateStatistics();
  updateFavoriteUI();
  if (state.view === 'favorites') renderFavorites();
}
function updateFavoriteUI(){for(const b of document.querySelectorAll('[data-fav-id]')){const active=!!getFavorite(b.dataset.favId);b.classList.toggle('is-saved',active);b.setAttribute('aria-label',active?'Удалить из избранного':'Добавить в избранное');b.title=active?'Удалить из избранного':'Добавить в избранное'}if(state.translation&&state.translation.row){const active=!!getFavorite(state.translation.row.id);$('favoriteTranslation').classList.toggle('is-saved',active)}}
let activeSpeech;
let speechStartTimer;

function speak(text, lang) {
  text = text?.trim();
  if (!text) return;
  const synth = window.speechSynthesis;
  if (window.RusDanskPiper?.play(text, lang, toast)) {
    activeSpeech = undefined;
    clearTimeout(speechStartTimer);
    synth?.cancel();
    return;
  }
  if (!synth || typeof SpeechSynthesisUtterance !== 'function') {
    toast('Этот браузер не поддерживает системный голос');
    return;
  }
  activeSpeech = undefined;
  clearTimeout(speechStartTimer);
  if (synth.speaking || synth.pending || synth.paused) synth.cancel();
  if (synth.paused) synth.resume();

  const language = lang.toLowerCase();
  const languagePart = language.split('-')[0];
  const voices = synth.getVoices().filter(voice => {
    const locale = voice.lang.toLowerCase().replaceAll('_', '-');
    return locale.split('-')[0] === languagePart;
  });
  const availableVoices = navigator.onLine === false ? voices.filter(voice => voice.localService) : voices;
  const voice = availableVoices.find(entry => entry.localService && entry.lang.toLowerCase() === language) ||
    availableVoices.find(entry => entry.localService) ||
    availableVoices.find(entry => entry.lang.toLowerCase() === language) ||
    availableVoices[0];

  function play(selectedVoice) {
    const speech = new SpeechSynthesisUtterance(text);
    speech.lang = selectedVoice?.lang || lang;
    if (selectedVoice) speech.voice = selectedVoice;
    speech.rate = .88;
    activeSpeech = speech;
    let started = false;

    function finish() {
      if (activeSpeech !== speech) return false;
      clearTimeout(speechStartTimer);
      activeSpeech = undefined;
      return true;
    }

    speech.onstart = () => {
      if (activeSpeech !== speech) return;
      started = true;
      clearTimeout(speechStartTimer);
    };
    speech.onend = finish;
    speech.onerror = ({error}) => {
      if (!finish() || error === 'interrupted' || error === 'canceled') return;
      const voiceError = ['voice-unavailable', 'language-unavailable', 'synthesis-unavailable'].includes(error);
      if (!started && selectedVoice && voiceError) {
        play();
        return;
      }
      if (voiceError || error === 'network' || error === 'synthesis-failed') {
        toast('Откройте настройки синтеза речи и проверьте голос нужного языка');
      } else if (error === 'audio-hardware' || error === 'audio-busy') {
        toast('Проверьте громкость мультимедиа и устройство вывода звука');
      } else {
        toast('Системный голос не запустился. Попробуйте ещё раз');
      }
    };
    speechStartTimer = setTimeout(() => {
      if (!finish()) return;
      synth.cancel();
      toast('Системный голос не ответил. Проверьте настройки синтеза речи');
    }, 10000);
    try {
      synth.speak(speech);
    } catch {
      if (finish()) toast('Браузер не смог запустить системный голос');
    }
  }

  play(voice);
}
function getLang(dir,source){const lang=(dir.split('-')[source?0:1]||'ru');return {'ru':'ru-RU','da':'da-DK','en':'en-US'}[lang]||'ru-RU'}
async function copyToClipboard(value){if(!value)return;try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(value);else{const box=document.createElement('textarea');box.value=value;box.style.cssText='position:fixed;left:-9999px;top:-9999px';document.body.append(box);box.select();const ok=document.execCommand('copy');box.remove();if(!ok)throw Error('blocked')}toast('Перевод скопирован')}catch{toast('Копирование заблокировано: выделите текст вручную')}}
function card(row,opts={}){const el=document.createElement('article');el.className='result-card';const body=document.createElement('div');body.className='result-body';const title=document.createElement('div');title.className='result-term';title.textContent=row.from;const def=document.createElement('div');def.className='result-trans';def.textContent=row.to;const cat=document.createElement('div');cat.className='result-cat';cat.textContent=Array.isArray(row.matchedSources)&&row.matchedSources.length?row.matchedSources.join(' · '):(['pack','reverse','kaikki','tatoeba','cor','corext','curated','freedict','koreader','wik-en','bridge'].includes(sourceKind(row))?displaySource(row):row.cat);body.append(title,def,cat);if(opts.clickable){body.style.cursor='pointer';body.title='Использовать в переводчике';body.addEventListener('click',()=>usePhrase(row))}const tools=document.createElement('div');tools.className='result-tools';const star=buttonIcon('star','Добавить в избранное',()=>favItem(row));star.dataset.favId=row.id;star.classList.toggle('is-saved',!!getFavorite(row.id));tools.append(star,buttonIcon('volume','Произнести перевод',()=>speak(row.to,getLang(row.dir,false))));if(opts.custom){tools.append(buttonIcon('trash','Удалить своё слово',()=>removeCustom(row.ru,row.da)))}el.append(body,tools);return el}
function showEmpty(node,title,detail){node.replaceChildren();const box=document.createElement('div');box.className='empty-state';const ic=document.createElement('div');ic.className='empty-icon';ic.append(icon('search'));const h=document.createElement('h3');h.textContent=title;const p=document.createElement('p');p.textContent=detail;box.append(ic,h,p);node.append(box)}
function matching(q,dir,rows,dedupe=true){const needle=clean(q);if(!needle)return rows.slice(0,60);const found=[];for(const [i,x] of rows.entries()){const f=clean(x.from),to=clean(x.to);let rank=f===needle?0:f.startsWith(needle)?1:f.split(/[\s\-]+/).some(w=>w.startsWith(needle))?2:f.includes(needle)?3:to.includes(needle)?5:99;if(rank!==99)found.push({x,i,rank})}found.sort((a,b)=>a.rank-b.rank||a.i-b.i);const unique=new Set(),ret=[];for(const {x} of found){const k=clean(x.from)+'\u001f'+clean(x.to);if(dedupe&&unique.has(k))continue;unique.add(k);ret.push(x)}return ret}
function renderSearch(){const q=$('sourceText').value.trim();const entries=allItems[state.direction].filter(sourceAllowed);let raw;if(!q)raw=entries.filter(x=>['Общение','Дополнительные фразы'].includes(x.cat)).slice(0,36);else raw=[...morphologyRows(q,state.direction).filter(sourceAllowed),...(multiIndex[state.direction]?searchMulti(q,state.direction,120).filter(sourceAllowed):matching(q,state.direction,entries,false)),...((state.direction==='ru-da'||state.direction==='da-ru')?bridgeRows(q,state.direction).filter(sourceAllowed):[])];const merged=new Map();for(const row of raw){const key=clean(row.from)+'\u001f'+clean(row.to);let result=merged.get(key);if(!result){result={...row,matchedSources:[]};merged.set(key,result)}const source=displaySource(row);if(!result.matchedSources.includes(source))result.matchedSources.push(source)}const found=[...merged.values()],shown=found.slice(0,state.resultLimit);$('searchCount').textContent=formatCount(found.length);const box=$('searchResults');box.replaceChildren();if(!shown.length)showEmpty(box,'Совпадений пока нет','Попробуйте другой запрос или выберите «Все источники».');else shown.forEach(row=>box.append(card(row,{clickable:true})));$('moreSearch').hidden=found.length<=state.resultLimit}
function renderCategories(){const node=$('categoryChips');node.replaceChildren();for(const cat of CATEGORIES){const chip=document.createElement('button');chip.type='button';chip.textContent=cat;chip.className='category-chip'+(state.category===cat?' is-selected':'');chip.addEventListener('click',()=>{state.category=cat;state.phraseLimit=24;renderCategories();renderPhrases()});node.append(chip)}}
function renderPhrases(){const q=$('phraseSearch').value.trim();const langPair=state.direction==='ru-da'||state.direction==='da-ru';let rows=langPair?allItems[state.direction].filter(x=>['base','custom','tatoeba','curated'].includes(x.source)):[];if(state.category!=='Все')rows=rows.filter(x=>x.cat===state.category);if(q)rows=matching(q,state.direction,rows);const results=$('phrasesList');results.replaceChildren();$('phraseHeading').textContent=state.category==='Все'?'Все выражения':state.category;$('phraseCount').textContent=formatCount(rows.length)+' записей';if(!rows.length)showEmpty(results,langPair?'Не найдено':'Русско-датский разговорник','Для разговорника переключитесь на русский ↔ датский. Остальные языковые пары доступны в переводчике.');else rows.slice(0,state.phraseLimit).forEach(x=>results.append(card(x,{clickable:true})));$('morePhrases').hidden=rows.length<=state.phraseLimit}
function renderFavorites(){const box=$('favoritesList');box.replaceChildren();$('favoritesCount').textContent=formatCount(state.favorites.length)+' записей';if(!state.favorites.length){showEmpty(box,'Ваш список пока пуст','Нажмите на звёздочку рядом со словом или переводом — оно появится здесь.');return}for(const f of state.favorites){const dir=DIRECTIONS.includes(f.dir)?f.dir:state.direction;const row=f.from&&f.to?genericItem(f.from,f.to,f.cat||'Избранное',f.source||'custom',dir):item(f.ru,f.da,f.cat||'Избранное','favorite',dir==='ru-da'||dir==='da-ru'?dir:'ru-da');row.id=f.id;box.append(card(row,{clickable:true}))}}
function renderCustom(){const box=$('customWords');box.replaceChildren();for(const pair of state.custom.slice(0,80)){if(!Array.isArray(pair))continue;box.append(card(item(pair[0],pair[1],'Мои слова','custom',state.direction==='da-ru'?'da-ru':'ru-da'),{clickable:true,custom:true}))}if(state.custom.length>80){const p=document.createElement('p');p.className='muted-text';p.textContent='Показаны первые 80 записей. Для полного списка скачайте TSV.';box.append(p)}}
function usePhrase(row) {
  if (state.direction !== row.dir || !sourceAllowed(row)) {
    state.direction = row.dir;
    state.sourceFilter = 'all';
    store('direction', state.direction);
    store('sourceFilter', state.sourceFilter);
    updateDirection();
  }
  $('sourceText').value = row.from;
  state.resultLimit = 8;
  state.selectedVariant = clean(row.to);
  setView('translate');
  runTranslation();
  $('sourceText').focus();
}
function updateDirection(){const [src,dst]=state.direction.split('-');const langs={ru:'Русский',da:'Датский',en:'Английский'},codes={ru:'России',da:'Дании',en:'Великобритании'};renderSourceFilters();$('sourceLanguage').textContent=langs[src];$('targetLanguage').textContent=langs[dst];$('sourceFlag').className='flag flag-'+src;$('targetFlag').className='flag flag-'+dst;$('sourceFlag').setAttribute('aria-label','Флаг '+codes[src]);$('targetFlag').setAttribute('aria-label','Флаг '+codes[dst]);$('sourceText').placeholder='Введите слово или фразу на '+({ru:'русском',en:'английском',da:'датском'}[src])+'…';const pair=src+'-'+dst;const normalized=pair==='da-ru'?'ru-da':pair==='en-ru'?'ru-en':pair==='en-da'?'da-en':pair;$('pairSelect').value=normalized;const examples={ru:['привет','дом','замечательный','спасибо'],da:['hej','hus','vidunderlige','tak'],en:['hello','house','wonderful','thank you']}[src];const box=$('exampleChips');box.replaceChildren();for(const phrase of examples){const b=document.createElement('button');b.type='button';b.className='example-chip';b.textContent=phrase;b.addEventListener('click',()=>{$('sourceText').value=phrase;state.selectedVariant=null;runTranslation()});box.append(b)}renderSearch();renderPhrases()}
function exactHit(value,dir){const variants=getExactVariants(value,dir);if(!variants.length)return null;return (variants.find(x=>clean(x.row.to)===state.selectedVariant)||variants[0]).row}
function segmented(value,dir){const text=value.trim();const tokens=text.match(/[\p{L}\p{N}]+(?:['’\-][\p{L}\p{N}]+)*/gu)||[];if(tokens.length<2||tokens.length>65)return null;const pieces=[];let i=0;while(i<tokens.length){let found=null,size=0;for(let n=Math.min(9,tokens.length-i);n>=1;n--){const chunk=tokens.slice(i,i+n).join(' ');const maybe=exactHit(chunk,dir);if(maybe){found=maybe;size=n;break}}if(!found)return null;pieces.push(found.to);i+=size}if(pieces.length===1)return null;return {text:pieces.join(' '),quality:'approx',row:null}}
function getEnglishHint(value,dir){
 if(dir!=='da-ru'||state.sourceFilter!=='all')return null;
 const q=clean(value);if(!q||q.includes(' ')||q.length>60)return null;
 const lemmas=lookup(extra.forms, q),additional=lookup(COREXT.forms, q);
 const candidates=[q,...(Array.isArray(lemmas)?lemmas:lemmas?[lemmas]:[]),...(Array.isArray(additional)?additional:additional?[additional]:[])];
 for(const lemma of candidates){
  const gloss=lookup(extra.glosses, lemma);if(!gloss||!gloss.length)continue;
  return {text:'Англ.: '+gloss.join('; '),quality:'hint',row:null,lemma};
 }
 return null;
}
function translate(value,dir){const input=value.trim();if(!input)return null;const row=exactHit(input,dir);if(row)return {text:row.to,quality:row.source==='bridge'?'indirect':'exact',row};if(input.includes('\n')){const lines=input.split(/\n/);const outputs=[];for(const ln of lines){if(!ln.trim()){outputs.push('');continue}const t=translate(ln,dir);if(!t)return null;outputs.push(t.text)}return {text:outputs.join('\n'),quality:'approx',row:null}}return segmented(input,dir)||getEnglishHint(input,dir)}
function runTranslation(){const raw=$('sourceText').value;const val=raw.trim();$('textCount').textContent=raw.length+' / 2000';state.translation=translate(val,state.direction);const target=$('translationOutput');const quality=$('translationType');const outcome=state.translation;target.classList.remove('is-placeholder','is-missing');quality.hidden=true;quality.classList.remove('approx');$('favoriteTranslation').classList.remove('is-saved');$('copyTranslation').disabled=!outcome;$('speakTranslation').disabled=!outcome;$('favoriteTranslation').disabled=!outcome||!outcome.row;if(!val){target.textContent='Здесь появится перевод вашего текста';target.classList.add('is-placeholder');$('translationStatus').textContent='Готов к работе';$('translateHint').textContent='Перевод выполняется без подключения к интернету.'}else if(outcome){target.textContent=outcome.text;if(outcome.quality==='hint'){quality.hidden=false;quality.textContent='только английское значение';quality.classList.add('approx');$('translationStatus').textContent='Русский перевод отсутствует';$('translateHint').textContent='Словоформа: '+(outcome.lemma||val)+'. Это значение из английского Wiktionary, а не перевод на русский.'}else if(outcome.quality==='indirect'){quality.hidden=false;quality.textContent='через английский · приблизительно';quality.classList.add('approx');$('translationStatus').textContent=displaySource(outcome.row);$('translateHint').textContent='Косвенный словарный перевод через английский «'+(outcome.row.via||'')+'». Проверьте значение и контекст.'}else if(outcome.quality==='exact'){quality.hidden=false;quality.textContent=outcome.row.lemma?'распознана словоформа':'точное совпадение';$('translationStatus').textContent=displaySource(outcome.row);$('translateHint').textContent=outcome.row.lemma?'Перевод взят из начальной формы «'+outcome.row.lemma+'». Род, число и грамматические формы могут отличаться.':'Найдено точное словарное совпадение. Контекст может менять смысл.'}else{quality.hidden=false;quality.textContent='приблизительно';quality.classList.add('approx');$('translationStatus').textContent='Составлено из известных выражений';$('translateHint').textContent='Приблизительный перевод: порядок слов и грамматика могут быть неверными.'}if(outcome.row)$('favoriteTranslation').classList.toggle('is-saved',!!getFavorite(outcome.row.id))}else{target.textContent='В словарях не найден перевод всего текста. Попробуйте отдельное слово или короткую фразу.';target.classList.add('is-missing');$('translationStatus').textContent='Перевод не найден';$('translateHint').textContent='Неизвестные фразы не переводятся автоматически. Это не нейросетевая модель.'}renderVariants(val);renderSearch()}
function downloadFile(name,contents,type='text/plain;charset=utf-8'){const blob=new Blob([contents],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),8000)}
function exportTsv(rows,name){const lines=['ru\tda',...rows.map(x=>x.map(t=>String(t).replace(/\t/g,' ').replace(/\n/g,' ')).join('\t'))];downloadFile(name,'\uFEFF'+lines.join('\n')+'\n','text/tab-separated-values;charset=utf-8')}
function removeCustom(ru,da){if(!confirm('Удалить эту запись из личного словаря?'))return;const custom=state.custom.filter(x=>!(norm(x[0])===norm(ru)&&norm(x[1])===norm(da)));
if (!savePersonal(custom, state.favorites)) { toast('Не удалось удалить запись'); return; }
rebuild();renderCustom();runTranslation();toast('Запись удалена')}
function addCustom(){const ru=$('customRu').value.trim(),da=$('customDa').value.trim();if(!ru||!da){toast('Введите слово или фразу на обоих языках');return}if(ru.length>200||da.length>300){toast('Для одной записи слишком длинный текст');return}if(state.custom.some(x=>norm(x[0])===norm(ru)&&norm(x[1])===norm(da))){toast('Такая запись уже есть');return}if (!savePersonal([[ru, da], ...state.custom], state.favorites)) {
  toast('Не удалось сохранить запись в браузере');
  return;
}$('customRu').value='';$('customDa').value='';rebuild();renderCustom();runTranslation();toast('Перевод добавлен в словарь')}
function backup(){const data={app:'RusDansk Portable',version:1,exported:new Date().toISOString(),direction:state.direction,theme:state.theme,favorites:state.favorites,custom:state.custom};downloadFile('RusDansk_backup.json',JSON.stringify(data,null,2),'application/json;charset=utf-8');toast('Резервная копия сохранена')}
async function restore(file) {
  try {
    const json = JSON.parse(await file.text());
    if (json?.app !== 'RusDansk Portable' || !Array.isArray(json.custom) || !Array.isArray(json.favorites)) {
      throw Error('Это не резервная копия RusDansk');
    }
    const custom = json.custom.filter(row => Array.isArray(row) &&
      typeof row[0] === 'string' && row[0].trim() && row[0].length < 500 &&
      typeof row[1] === 'string' && row[1].trim() && row[1].length < 750)
      .map(([ru, da]) => [ru, da]);
    const favorites = json.favorites.filter(row => row && typeof row.id === 'string' && (
      (DIRECTIONS.includes(row.dir) && typeof row.from === 'string' && row.from &&
        typeof row.to === 'string' && row.to) ||
      (typeof row.ru === 'string' && row.ru && typeof row.da === 'string' && row.da)
    ));
    if (custom.length !== json.custom.length || favorites.length !== json.favorites.length) {
      throw Error('Файл содержит повреждённые записи');
    }
    if (!savePersonal(custom, favorites)) throw Error('Данные не поместились в хранилище браузера');
    state.direction = DIRECTIONS.includes(json.direction) ? json.direction : 'ru-da';
    state.sourceFilter = 'all';
    state.selectedVariant = null;
    store('direction', state.direction);
    store('sourceFilter', state.sourceFilter);
    setTheme(json.theme);
    rebuild();
    updateDirection();
    renderFavorites();
    renderCustom();
    runTranslation();
    toast('Данные восстановлены');
  } catch (error) {
    toast('Ошибка восстановления: ' + error.message);
  }
}

function setCompact(enabled,persist=true){
 state.compact=!!enabled;
 document.body.classList.toggle('compact-mode',state.compact);
 if(persist)store('compact',state.compact);
 const label=$('compactModeLabel');if(label)label.textContent=state.compact?'Выключить компактный вид':'Включить компактный вид';
 const btn=$('compactModeButton');if(btn)btn.setAttribute('aria-pressed',String(state.compact));
}
function openCompactWindow(){
 if(window.innerWidth<721){toast('Для телефона используйте обычный адаптивный режим');return}
 const url=new URL(location.href);url.searchParams.set('compact','1');
 const child=window.open(url.href,'RusDansk_compact','popup=yes,width=860,height=780,resizable=yes,scrollbars=yes');
 if(child){try{child.focus()}catch(e){};toast('Открыто компактное окно; его размер можно менять')}
 else{setCompact(true);toast('Браузер заблокировал новое окно. Включён компактный вид.')}
}
function bind(){
 $('testSystemVoice').addEventListener('click', () => {
   const locale = window.RusDanskPiper?.language;
   const language = locale ? getLang('ru-' + locale, false) : getLang(state.direction, false);
   const sample = {'ru-RU':'Привет! Это проверка системного голоса.', 'da-DK':'Hej! Dette er en test af stemmen.', 'en-US':'Hello! This is a test of the system voice.'};
   speak(sample[language], language);
 });
 $('appHomeButton').addEventListener('click',()=>setView('translate'));
 $('appBackButton').addEventListener('click',()=>{if(history.state?.rusDanskDepth)history.back();else setView('translate');});
 window.addEventListener('popstate',()=>setView(history.state?.rusDanskView||'translate',false));
 const openWindow=$('openCompactButton');if(openWindow)openWindow.addEventListener('click',openCompactWindow);$('compactWindowButton').addEventListener('click',openCompactWindow);$('compactModeButton').addEventListener('click',()=>setCompact(!state.compact));$('settingsOpenDictionaries').addEventListener('click',()=>setView('dictionaries'));document.querySelectorAll('[data-view]').forEach(x=>x.addEventListener('click',()=>setView(x.dataset.view)));$('themeButton').addEventListener('click',()=>setTheme(state.theme==='dark'?'light':'dark'));$('themeSetting').addEventListener('click',()=>{setTheme(state.theme==='dark'?'light':'dark');toast('Тема переключена')});$('pairSelect').addEventListener('change',event=>{state.direction=event.target.value;state.sourceFilter='all';state.selectedVariant=null;state.resultLimit=8;store('direction',state.direction);store('sourceFilter',state.sourceFilter);$('sourceText').value='';updateDirection();runTranslation();});$('swapButton').addEventListener('click',()=>{const old=state.translation;const prev=$('sourceText').value;state.selectedVariant=null;state.direction=state.direction.split('-').reverse().join('-');store('direction',state.direction);state.sourceFilter='all';store('sourceFilter','all');$('sourceText').value=old&&old.text?old.text:prev;state.resultLimit=8;updateDirection();runTranslation()});$('sourceText').addEventListener('input',()=>{state.selectedVariant=null;clearTimeout(typingTimer);typingTimer=setTimeout(()=>{state.resultLimit=8;runTranslation()},130)});$('sourceText').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();runTranslation()}});$('translateButton').addEventListener('click',runTranslation);$('clearButton').addEventListener('click',()=>{$('sourceText').value='';runTranslation();$('sourceText').focus()});$('speakSourceButton').addEventListener('click',()=>speak($('sourceText').value,getLang(state.direction,true)));$('copyTranslation').addEventListener('click',()=>copyToClipboard(state.translation?.text));$('speakTranslation').addEventListener('click',()=>speak(state.translation?.text,state.translation?.quality==='hint'?'en-US':getLang(state.direction,false)));$('favoriteTranslation').addEventListener('click',()=>{if(state.translation?.row)favItem(state.translation.row)});$('openPhrases').addEventListener('click',()=>setView('phrases'));$('moreSearch').addEventListener('click',()=>{state.resultLimit+=12;renderSearch()});$('phraseSearch').addEventListener('input',()=>{state.phraseLimit=24;renderPhrases()});$('morePhrases').addEventListener('click',()=>{state.phraseLimit+=24;renderPhrases()});$('addCustom').addEventListener('click',addCustom);for(const id of ['customRu','customDa'])$(id).addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addCustom()}});$('exportCustom').addEventListener('click',()=>exportTsv(state.custom,'RusDansk_my_words.tsv'));$('exportBackup').addEventListener('click',backup);$('restoreBackup').addEventListener('click',()=>$('backupFile').click());$('backupFile').addEventListener('change',async e=>{if(e.target.files[0])await restore(e.target.files[0]);e.target.value=''});}async function init(){
  state.compact=load('compact',false);if(!activeFilters().includes(state.sourceFilter))state.sourceFilter='all';
  setCompact(new URLSearchParams(location.search).get('compact')==='1'||state.compact,false);
  setTheme(state.theme);
  window.speechSynthesis?.getVoices();
  try{if(!history.state?.rusDanskView)history.replaceState({rusDanskView:'translate',rusDanskDepth:0},'');}catch{}
  bind();setView(history.state?.rusDanskView||'translate',false);rebuild();renderCategories();updateDirection();runTranslation();
  const storage=$('storageHint');
  if(storage)storage.textContent='Все словари встроены. Если русского значения нет, может отображаться явно помеченная английская подсказка. Избранное и личные слова сохраняются на устройстве.';
}

init();
})();
