/* Piper model downloads, per-language selection, and local audio playback. */
'use strict';
(() => {
  const languages = ['ru', 'da', 'en'];
  const revision = 'e5349433ed883a32f893a434dc43a6c66b95ef7c';
  const modelBase = 'https://huggingface.co/rhasspy/piper-voices/resolve/' + revision + '/';
  const catalog = {
    'ru_RU-irina-medium': {name: 'Ирина', path: 'ru/ru_RU/irina/medium', size: 63201294,
      sha256: '8ff38212d23da300bbe3705c645e6e5b9475f0bfde01558eb17813e22acaaaaa',
      configSha256: 'c2ec28bb38e2b59e93b959b3e40348c1afebbd272f30fed5d41205d08e98a9d7'},
    'ru_RU-dmitri-medium': {name: 'Дмитрий', path: 'ru/ru_RU/dmitri/medium', size: 63221984,
      sha256: '9ed9941bac7373f2ec1be36627e0e71a349a59ca5522d4363fd50701db05193a',
      configSha256: 'c3741c9c1558fc38e902fd80d39155c32a7d019d7d17e3a43eac66b7bd3fbe09'},
    'da_DK-talesyntese-medium': {name: 'Talesyntese', path: 'da/da_DK/talesyntese/medium', size: 63201294,
      sha256: 'b9271efd25f7b8494bbd28d48dd675c8c119daa284f3ee488008935f515f1241',
      configSha256: '89fe13bd251406cc0088570d103ea7ac35823211d8466faf913268ab8506f41b'},
    'en_US-lessac-medium': {name: 'Lessac (США)', path: 'en/en_US/lessac/medium', size: 63201294,
      sha256: '5efe09e69902187827af646e1a6e9d269dee769f9877d17b16b1b46eeaaf019f',
      configSha256: 'efe19c417bed055f2d69908248c6ba650fa135bc868b0e6abb3da181dab690a0'},
    'en_GB-alba-medium': {name: 'Alba (Великобритания)', path: 'en/en_GB/alba/medium', size: 63221984,
      sha256: '1f9da809b6da1ef4190bb5dd6cce4f4af803274539e9cf9e0693085150bac3d7',
      configSha256: 'ed4b1f015a8aae5eb26d4bdeed7b712c660f5698a0dd954aa6df9c8be60b900b'},
  };
  const runtime = {
    'worker.js': 'text/javascript',
    'ort.wasm.min.js': 'text/javascript',
    'ort-wasm-simd-threaded.mjs': 'text/javascript',
    'ort-wasm-simd-threaded.wasm': 'application/wasm',
    'piper_phonemize.js': 'text/javascript',
    'piper_phonemize.wasm': 'application/wasm',
    'piper_phonemize.data': 'application/octet-stream',
  };
  const element = id => document.getElementById(id);
  const language = element('piperLanguage');
  const voice = element('piperVoice');
  const status = element('piperStatus');
  const download = element('piperDownload');
  const cancel = element('piperCancel');
  const importButton = element('piperImport');
  const files = element('piperFiles');
  const remove = element('piperRemove');
  const card = element('piperModelCard');
  const portable = document.documentElement.hasAttribute('data-portable-piper');
  const selections = {};
  const memory = new Map();
  const temporaryRuntime = new Map();
  let allInstalled = new Set();
  let database, assetURLs, portableRuntime, worker, resolveJob, audio, source;
  let operation, working = true, playbackId = 0;

  for (const code of languages) {
    try { selections[code] = localStorage.getItem('rusdansk:piper:' + code); } catch {}
  }

  function setVoice(id) {
    selections[language.value] = id;
    try { localStorage.setItem('rusdansk:piper:' + language.value, id); } catch {}
  }

  function openDatabase() {
    database ||= new Promise(resolve => {
      try {
        const request = indexedDB.open('RusDansk-Piper', 1);
        request.onupgradeneeded = () => request.result.createObjectStore('models', {keyPath: 'id'});
        request.onsuccess = () => resolve(request.result);
        request.onerror = request.onblocked = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
    return database;
  }

  async function storeRequest(mode, action) {
    const db = await openDatabase();
    if (!db) return action(memory);
    return new Promise((resolve, reject) => {
      const tx = db.transaction('models', mode);
      const request = action(tx.objectStore('models'));
      tx.oncomplete = () => resolve(request.result);
      tx.onabort = tx.onerror = () => reject(tx.error || request.error);
    });
  }

  const readVoice = id => memory.get(id) || storeRequest('readonly', store => store.get(id));
  const writeVoice = record => storeRequest('readwrite', store =>
    store instanceof Map ? store.set(record.id, record) : store.put(record));
  const eraseVoice = id => {
    memory.delete(id);
    return storeRequest('readwrite', store => store.delete(id));
  };
  const installedVoices = () => storeRequest('readonly', store =>
    store instanceof Map ? [...store.keys()] : store.getAllKeys());

  function modelURL(id) {
    return modelBase + catalog[id].path + '/' + id + '.onnx';
  }

  function renderVoiceOptions() {
    const code = language.value;
    voice.replaceChildren(new Option('Системный голос', 'system'));
    for (const [id, model] of Object.entries(catalog)) {
      if (!id.startsWith(code + '_')) continue;
      const detail = allInstalled.has(id) ? 'загружен' : '≈ 63 МБ';
      voice.add(new Option(model.name + ' · ' + detail, id));
    }
    voice.value = allInstalled.has(selections[code]) ? selections[code] : 'system';
  }

  function renderActions() {
    const model = catalog[voice.value];
    const installed = allInstalled.has(voice.value);
    const available = Boolean(model) && !installed;
    language.disabled = voice.disabled = working;
    download.hidden = importButton.hidden = !available;
    remove.hidden = !installed;
    cancel.hidden = !operation;
    download.disabled = importButton.disabled = remove.disabled = working;
    card.hidden = !model;
    if (model) card.href = modelBase.replace('/resolve/', '/blob/') + model.path + '/MODEL_CARD';
  }

  function voiceStatus(id) {
    const available = memory.has(id) || temporaryRuntime.size
      ? 'До закрытия страницы. Браузер не смог сохранить все файлы.'
      : 'Доступен без интернета.';
    return 'Выбран Piper · ' + catalog[id].name + '. ' + available;
  }

  function showChoice() {
    const id = voice.value;
    if (id === 'system' || allInstalled.has(id)) {
      setVoice(id);
      status.textContent = id === 'system'
        ? 'Выбран системный голос.'
        : voiceStatus(id);
    } else {
      status.textContent = 'Загрузите голос, чтобы выбрать его. При первой загрузке сохраняется и движок Piper.';
    }
    renderActions();
  }

  function runtimeURL(name) {
    return new URL('assets/piper/' + name, document.baseURI).href;
  }

  async function openRuntimeCache() {
    if (!('caches' in window)) return null;
    try {
      return await caches.open('RusDansk-Piper-runtime-v1:' + new URL('.', document.baseURI).href);
    } catch {
      return null;
    }
  }

  function loadPortableRuntime() {
    portableRuntime ||= new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'Piper_Runtime.js';
      script.onload = () => {
        if (window.RusDanskPiperAssets) resolve(window.RusDanskPiperAssets);
        else reject(new Error('Invalid portable Piper runtime'));
      };
      script.onerror = () => reject(new Error('Missing Piper_Runtime.js'));
      document.head.append(script);
    }).catch(error => {
      portableRuntime = undefined;
      throw error;
    });
    return portableRuntime;
  }

  async function prepareRuntime(signal) {
    if (portable) {
      await loadPortableRuntime();
      return null;
    }
    const cache = await openRuntimeCache();
    for (const [name, type] of Object.entries(runtime)) {
      const url = runtimeURL(name);
      if (temporaryRuntime.has(name) || await cache?.match(url)) continue;
      const response = await fetch(url, {cache: 'reload', redirect: 'error', signal});
      if (!response.ok) throw new Error('Piper runtime download failed: ' + name);
      const body = (await response.blob()).slice(0, undefined, type);
      try {
        if (!cache) throw new Error('Cache unavailable');
        await cache.put(url, new Response(body, {headers: {'Content-Type': type}}));
      } catch (error) {
        console.warn('RusDansk Piper runtime cache:', error);
        temporaryRuntime.set(name, body);
      }
    }
    return cache;
  }

  async function getAssetURLs() {
    assetURLs ||= (async () => {
      const urls = {};
      try {
        const local = portable ? await loadPortableRuntime() : null;
        const cache = local ? null : await prepareRuntime();
        for (const [name, type] of Object.entries(runtime)) {
          let blob;
          if (local) {
            const decoded = atob(local[name]);
            const bytes = new Uint8Array(decoded.length);
            for (let i = 0; i < bytes.length; i++) bytes[i] = decoded.charCodeAt(i);
            const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
            blob = (await new Response(stream).blob()).slice(0, undefined, type);
          } else {
            blob = temporaryRuntime.get(name) || await (await cache.match(runtimeURL(name))).blob();
          }
          urls[name] = URL.createObjectURL(blob);
        }
        return urls;
      } catch (error) {
        for (const url of Object.values(urls)) URL.revokeObjectURL(url);
        assetURLs = undefined;
        throw error;
      }
    })();
    return assetURLs;
  }

  async function downloadModel(id, signal) {
    const url = modelURL(id);
    const [weights, settings] = await Promise.all([
      fetch(url, {signal}),
      fetch(url + '.json', {signal}),
    ]);
    if (!weights.ok || !settings.ok || !weights.body) throw new Error('Model download failed');
    const reader = weights.body.getReader();
    const pieces = [];
    let count = 0, lastPercent = -1;
    while (true) {
      const {value, done} = await reader.read();
      if (done) break;
      count += value.byteLength;
      if (count > catalog[id].size) {
        await reader.cancel();
        throw new Error('Model file has the wrong size');
      }
      const percent = Math.floor(count / catalog[id].size * 100);
      if (percent !== lastPercent) {
        status.textContent = 'Загрузка голоса · ' + percent + '%';
        lastPercent = percent;
      }
      pieces.push(value);
    }
    return {model: new Blob(pieces), settings: await settings.blob()};
  }

  async function sha256(blob) {
    const hash = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
    return [...new Uint8Array(hash)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  }

  async function installVoice(localFiles) {
    const id = voice.value;
    if (!Object.hasOwn(catalog, id) || working) return;
    working = true;
    operation = new AbortController();
    const {signal} = operation;
    renderActions();
    try {
      let pack;
      if (localFiles) {
        const model = localFiles.find(file => file.name === id + '.onnx');
        const settings = localFiles.find(file => file.name === id + '.onnx.json');
        if (!model || !settings) {
          status.textContent = 'Выберите два файла для голоса ' + catalog[id].name + ' с расширениями .onnx и .onnx.json.';
          return;
        }
        pack = {model, settings};
      } else {
        status.textContent = 'Подключаемся к каталогу голосов…';
        pack = await downloadModel(id, signal);
      }
      status.textContent = 'Проверяем голос…';
      if (pack.settings.size > 25000) throw new Error('Piper configuration is too large');
      const config = JSON.parse(await pack.settings.text());
      if (pack.model.size !== catalog[id].size || !config.espeak?.voice ||
          config.audio?.sample_rate !== 22050 || config.phoneme_type !== 'espeak' ||
          !['noise_scale','length_scale','noise_w'].every(key => Number.isFinite(config.inference?.[key]))) {
        throw new Error('Invalid Piper model or configuration');
      }
      const [modelHash, configHash] = await Promise.all([sha256(pack.model), sha256(pack.settings)]);
      if (modelHash !== catalog[id].sha256 || configHash !== catalog[id].configSha256) {
        throw new Error('Piper voice checksum mismatch');
      }
      signal.throwIfAborted();

      status.textContent = 'Сохраняем движок для работы без интернета…';
      await prepareRuntime(signal);
      signal.throwIfAborted();
      const record = {id, config, model: pack.model};
      try {
        await writeVoice(record);
      } catch (error) {
        if (error?.name !== 'QuotaExceededError') throw error;
        memory.set(id, record);
      }
      allInstalled.add(id);
      setVoice(id);
      renderVoiceOptions();
      status.textContent = voiceStatus(id);
    } catch (error) {
      console.warn('RusDansk Piper voice installation:', error);
      status.textContent = signal.aborted ? 'Загрузка отменена.'
        : error?.name === 'QuotaExceededError' ? 'Недостаточно места для голоса в хранилище браузера.'
        : error.message === 'Missing Piper_Runtime.js' ? 'Распакуйте Piper_Runtime.js рядом с автономным HTML.'
        : 'Не удалось сохранить голос. Проверьте соединение или выберите два файла модели.';
    } finally {
      operation = undefined;
      working = false;
      renderActions();
    }
  }

  function stop() {
    playbackId++;
    if (source) {
      source.stop();
      source = undefined;
    }
    if (resolveJob) {
      worker.terminate();
      worker = undefined;
      resolveJob.reject(new DOMException('Playback canceled', 'AbortError'));
      resolveJob = undefined;
    }
  }

  async function playLocal(id, text, token) {
    const playing = audio.resume();
    playing.catch(() => {});
    const record = await readVoice(id);
    if (!record) throw new Error('Piper model is unavailable');
    const assets = await getAssetURLs();
    await playing;
    if (playbackId !== token) return;

    if (!worker) {
      worker = new Worker(assets['worker.js']);
      worker.onmessage = ({data}) => {
        const job = resolveJob;
        resolveJob = undefined;
        if (!job) return;
        if (data.error) job.reject(new Error(data.error));
        else job.resolve(data);
      };
      worker.onerror = event => {
        resolveJob?.reject(new Error(event.message || 'Piper worker error'));
        resolveJob = undefined;
        worker.terminate();
        worker = undefined;
      };
    }
    const {pcm, sampleRate} = await new Promise((resolve, reject) => {
      resolveJob = {resolve, reject};
      worker.postMessage({id: token, voice: id, model: record.model, config: record.config, text, assets});
    });
    if (playbackId !== token) return;
    const buffer = audio.createBuffer(1, pcm.length, sampleRate);
    buffer.copyToChannel(pcm, 0);
    const node = audio.createBufferSource();
    node.buffer = buffer;
    node.connect(audio.destination);
    node.onended = () => { if (source === node) source = undefined; };
    source = node;
    node.start();
    if (voice.value === id) status.textContent = 'Воспроизводится Piper · ' + catalog[id].name + '.';
    node.addEventListener('ended', () => {
      if (playbackId === token && voice.value === id) status.textContent = voiceStatus(id);
    }, {once: true});
  }

  window.RusDanskPiper = {
    get language() { return language.value; },
    play(text, locale, report) {
      const id = selections[locale.toLowerCase().split('-')[0]];
      stop();
      if (!allInstalled.has(id)) return false;
      const token = playbackId;
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) {
        report('Браузер не поддерживает воспроизведение Piper.');
        return true;
      }
      try {
        audio ||= new Audio();
        report('Готовим озвучивание Piper…');
        playLocal(id, text, token).catch(error => {
          if (playbackId !== token) return;
          console.warn('RusDansk Piper playback:', error);
          report('Piper не смог воспроизвести текст. Проверьте голос в настройках.');
        });
      } catch (error) {
        console.warn('RusDansk Piper audio:', error);
        report('Не удалось открыть устройство вывода звука.');
      }
      return true;
    },
  };

  language.addEventListener('change', () => {renderVoiceOptions(); showChoice();});
  voice.addEventListener('change', showChoice);
  download.addEventListener('click', () => installVoice());
  importButton.addEventListener('click', () => files.click());
  files.addEventListener('change', () => {
    const selected = [...files.files];
    files.value = '';
    if (selected.length) installVoice(selected);
  });
  cancel.addEventListener('click', () => operation?.abort());
  remove.addEventListener('click', async () => {
    const id = voice.value;
    working = true;
    renderActions();
    try {
      stop();
      await eraseVoice(id);
      allInstalled.delete(id);
      setVoice('system');
      renderVoiceOptions();
      status.textContent = 'Голос удалён. Выбран системный голос.';
    } catch {
      status.textContent = 'Не удалось удалить голос.';
    } finally {
      working = false;
      renderActions();
    }
  });

  installedVoices().then(ids => {
    allInstalled = new Set(ids);
  }).catch(() => {
    status.textContent = 'Хранилище голосов недоступно.';
  }).finally(() => {
    working = false;
    renderVoiceOptions();
    renderActions();
  });
})();
