/* Local Piper synthesis. Voice weights are provided by the application. */
'use strict';
let runtime, phonemizer, modelSession, modelId;
let phonemeSequences = [];
let queue = Promise.resolve();

async function init(assets) {
  importScripts(assets['ort.wasm.min.js'], assets['piper_phonemize.js']);
  ort.env.wasm.numThreads = 1;
  ort.env.wasm.wasmPaths = {
    mjs: assets['ort-wasm-simd-threaded.mjs'],
    wasm: assets['ort-wasm-simd-threaded.wasm'],
  };
  phonemizer = await createPiperPhonemize({
    locateFile: name => assets[name] || name,
    print: line => {
      const {phoneme_ids: ids} = JSON.parse(line);
      if (ids?.length) phonemeSequences.push(ids);
    },
    printErr: error => console.warn('Piper phonemizer:', error),
  });
}

function splitText(text) {
  const chunks = [];
  let chunk = '';
  for (const word of text.split(/\s+/)) {
    if (chunk && chunk.length + word.length + 1 > 250) {
      chunks.push(chunk);
      chunk = '';
    }
    chunk += (chunk ? ' ' : '') + word;
  }
  if (chunk) chunks.push(chunk);
  return chunks;
}

async function infer({voice, model, config, text, assets}) {
  runtime ||= init(assets);
  await runtime;
  if (voice !== modelId) {
    await modelSession?.release();
    modelId = undefined;
    modelSession = await ort.InferenceSession.create(await model.arrayBuffer(), {executionProviders: ['wasm']});
    modelId = voice;
  }
  const sampleRate = config.audio.sample_rate;
  const samples = [];
  const silence = new Float32Array(Math.round(sampleRate * .14));

  for (const chunk of splitText(text)) {
    phonemeSequences = [];
    phonemizer.callMain(['-l', config.espeak.voice, '--input',
      JSON.stringify([{text: chunk}]), '--espeak_data', '/espeak-ng-data']);

    for (const ids of phonemeSequences) {
      const feeds = {
        input: new ort.Tensor('int64', BigInt64Array.from(ids, BigInt), [1, ids.length]),
        input_lengths: new ort.Tensor('int64', BigInt64Array.of(BigInt(ids.length)), [1]),
        scales: new ort.Tensor('float32', Float32Array.of(config.inference.noise_scale,
          config.inference.length_scale, config.inference.noise_w), [3]),
      };
      if (modelSession.inputNames.includes('sid')) feeds.sid = new ort.Tensor('int64', BigInt64Array.of(0n), [1]);
      const {output} = await modelSession.run(feeds);
      if (samples.length) samples.push(silence);
      samples.push(output.data.slice());
      output.dispose();
    }
  }
  const pcm = new Float32Array(samples.reduce((size, sample) => size + sample.length, 0));
  if (!pcm.length) throw new Error('Piper produced no speech');
  let offset = 0;
  for (const sample of samples) {
    pcm.set(sample, offset);
    offset += sample.length;
  }
  return {pcm, sampleRate};
}

self.onmessage = ({data}) => {
  queue = queue.then(async () => {
    try {
      const result = await infer(data);
      self.postMessage({id: data.id, ...result}, [result.pcm.buffer]);
    } catch (error) {
      self.postMessage({id: data.id, error: String(error)});
    }
  });
};
