/* Installation and offline status for the hosted edition. */
'use strict';
(() => {
  const badge = document.getElementById('offlineStatus');
  const label = badge.querySelector('.offline-label');
  const status = document.getElementById('offlineHelp');
  const help = document.getElementById('installHelp');
  const retryButton = document.getElementById('retryOfflineButton');
  const installButtons = ['installAppButton', 'installSettingsButton'].map(id => document.getElementById(id));
  const displayMode = matchMedia('(display-mode: standalone)');
  const isAppleMobile = /iPhone|iPad|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const supported = window.isSecureContext && 'serviceWorker' in navigator;
  let installPrompt = null;
  let installed = false;
  let pendingCheck;

  function showInstallHelp() {
    installed ||= displayMode.matches || navigator.standalone === true;
    for (const button of installButtons) button.hidden = installed || !supported;
    if (!supported) {
      help.textContent = 'Для установки откройте переводчик по HTTPS.';
    } else if (installed) {
      help.textContent = 'RusDansk установлен.';
    } else if (installPrompt) {
      help.textContent = 'Нажмите «Установить», чтобы открыть окно установки.';
    } else if (isAppleMobile) {
      help.textContent = 'Откройте переводчик в Safari, выберите «Поделиться» и «На экран „Домой“».';
    } else {
      help.textContent = 'В меню браузера выберите «Установить приложение» или «Добавить на главный экран». Если переводчик открыт внутри другого приложения, откройте его в Chrome или Edge.';
    }
  }

  function setOfflineStatus(text, detail, state) {
    badge.dataset.state = state;
    badge.title = detail;
    badge.setAttribute('aria-label', detail);
    label.textContent = text;
    status.textContent = detail;
    retryButton.hidden = state !== 'error';
  }

  function showLoading() {
    setOfflineStatus('Сохраняем словари…', 'Сохраняем приложение и словари для работы без интернета.', 'loading');
  }

  function showError() {
    setOfflineStatus('Офлайн недоступен', 'Офлайн-копия не готова. При подключении к интернету можно повторить загрузку.', 'error');
  }

  function verifyCache(repair = false) {
    const worker = navigator.serviceWorker.controller;
    if (!worker) return;
    pendingCheck?.();
    const channel = new MessageChannel();
    const finish = () => {
      clearTimeout(timeout);
      channel.port1.close();
      pendingCheck = undefined;
    };
    const timeout = setTimeout(() => {
      finish();
      if (navigator.serviceWorker.controller === worker) showError();
    }, repair ? 120000 : 5000);
    pendingCheck = finish;
    channel.port1.onmessage = ({ data }) => {
      finish();
      if (navigator.serviceWorker.controller !== worker) return;
      if (data?.ready === true) {
        setOfflineStatus('Готово офлайн', 'Все словари сохранены. Перевод доступен без интернета.', 'ready');
      } else {
        showError();
      }
    };
    worker.postMessage({ type: repair ? 'rusdansk:cache-repair' : 'rusdansk:cache-status' }, [channel.port2]);
  }

  async function prepareOffline() {
    showLoading();
    try {
      const registration = await navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' });
      if (navigator.serviceWorker.controller) {
        verifyCache();
        return;
      }
      const worker = registration.installing || registration.waiting;
      if (worker) {
        const check = () => {
          if (worker.state === 'redundant' && !navigator.serviceWorker.controller) showError();
        };
        worker.addEventListener('statechange', check);
        check();
      } else if (registration.active) {
        await registration.active.postMessage({ type: 'rusdansk:claim' });
      } else {
        showError();
      }
    } catch (error) {
      console.warn('RusDansk offline setup failed:', error);
      showError();
    }
  }

  async function install() {
    if (installPrompt) {
      const prompt = installPrompt;
      installPrompt = null;
      try {
        const { outcome } = await prompt.prompt();
        if (outcome === 'accepted') installed = true;
      } catch (error) {
        console.warn('RusDansk installation prompt failed:', error);
      }
      showInstallHelp();
      return;
    }
    showInstallHelp();
    document.querySelector('[data-view="settings"]').click();
    help.scrollIntoView({ block: 'center' });
  }

  for (const button of installButtons) button.addEventListener('click', install);
  retryButton.addEventListener('click', () => {
    if (navigator.serviceWorker.controller) {
      showLoading();
      verifyCache(true);
    } else {
      prepareOffline();
    }
  });
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    installPrompt = event;
    showInstallHelp();
  });
  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    installed = true;
    showInstallHelp();
  });
  showInstallHelp();
  if (supported) {
    navigator.serviceWorker.addEventListener('controllerchange', () => verifyCache());
    prepareOffline();
  } else {
    setOfflineStatus('Нужен HTTPS', 'Для сохранения словарей откройте приложение по HTTPS.', 'unsupported');
  }
})();
