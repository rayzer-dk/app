/* Manual release check for the hosted edition. */
'use strict';
(() => {
  const button = document.getElementById('checkForUpdate');
  const status = document.getElementById('updateStatus');
  const currentVersion = document.documentElement.dataset.version;
  const workers = navigator.serviceWorker;
  let updateReady = false;

  function compareVersions(first, second) {
    const left = first.split('.').map(Number);
    const right = second.split('.').map(Number);
    return left[0] - right[0] || left[1] - right[1] || left[2] - right[2];
  }

  function waitForRelease(registration, version) {
    return new Promise((resolve, reject) => {
      let installing;
      let finished = false;
      const timeout = setTimeout(() => finish(new Error('Update timed out')), 90000);

      function finish(error) {
        if (finished) return;
        finished = true;
        clearTimeout(timeout);
        workers.removeEventListener('controllerchange', checkController);
        installing?.removeEventListener('statechange', checkInstall);
        if (error) reject(error);
        else resolve();
      }

      function checkInstall() {
        if (installing.state === 'redundant') finish(new Error('Update could not be installed'));
      }

      // Ask the controller before starting the update, in case it already
      // installed the requested release while this page was open.
      function checkController() {
        if (finished || !workers.controller) return;
        const request = new MessageChannel();
        const deadline = setTimeout(() => request.port1.close(), 3000);
        request.port1.onmessage = ({data}) => {
          clearTimeout(deadline);
          request.port1.close();
          if (typeof data?.version === 'string' && compareVersions(data.version, version) >= 0) {
            finish();
          }
        };
        try {
          workers.controller.postMessage({type:'rusdansk:version'}, [request.port2]);
        } catch {
          clearTimeout(deadline);
          request.port1.close();
        }
      }

      workers.addEventListener('controllerchange', checkController);
      checkController();
      registration.update().then(result => {
        if (finished) return;
        installing = result.installing;
        if (installing) {
          installing.addEventListener('statechange', checkInstall);
          checkInstall();
        }
        checkController();
      }).catch(finish);
    });
  }

  button.addEventListener('click', async () => {
    if (updateReady) {
      location.reload();
      return;
    }
    button.disabled = true;
    status.textContent = 'Проверяем версию на сервере…';
    let latest;
    try {
      const response = await fetch('./version.json', {
        cache: 'no-store',
        signal: AbortSignal.timeout(15000),
      });
      if (!response.ok) throw new Error('Version check failed');
      const {version} = await response.json();
      if (typeof version !== 'string' || !/^\d+\.\d+\.\d+$/.test(version)) throw new Error('Invalid version');
      if (compareVersions(version, currentVersion) <= 0) {
        status.textContent = 'У вас актуальная версия ' + currentVersion + '.';
        return;
      }

      latest = version;
      if (workers) {
        status.textContent = 'Версия ' + latest + ' найдена. Загружаем приложение и словари…';
        const registration = await workers.getRegistration();
        if (!registration) throw new Error('Service worker not registered');
        await waitForRelease(registration, latest);
      }
      updateReady = true;
      status.textContent = 'Версия ' + latest + ' готова. Нажмите «Обновить», чтобы открыть её.';
      button.textContent = 'Обновить';
    } catch {
      status.textContent = latest
        ? 'Версия ' + latest + ' найдена. Загрузка прервалась. Попробуйте ещё раз.'
        : 'Не удалось проверить обновления. Проверьте подключение к интернету.';
    } finally {
      button.disabled = false;
    }
  });
})();
