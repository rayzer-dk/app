/* RusDansk offline cache. Asset hashes identify this exact release. */
'use strict';
const PREFIX = 'rusdansk-static:' + self.registration.scope;
const CACHE = PREFIX + ':07784fbbecdea0cac010';
const ASSETS = {
  "LICENSE_AND_SOURCES.txt": "sha256-B2oSW0emJsJ4PapiqEZUHqOlbHoDwFZTVzGesW1mncQ=",
  "RusDansk.ico": "sha256-w6NNlfdUcnJLjgoTiAVlaCZO4CnpT/auJe5vhEVYZ8Y=",
  "assets/app.js": "sha256-ZYDGUfQwge31SuK7TdxSBiod3zxUsiLOwNzTFbAOu/8=",
  "assets/corext-bundled.js": "sha256-nt8BS847bQiA+vd3pEN7fk4cYXCm/yayvtZbdYSra0Y=",
  "assets/dictionary.js": "sha256-rJY8SSJ8/RowjpP9UnVHOArHyQ6Hl1S3HSDVlsnWWtQ=",
  "assets/extra-bundled.js": "sha256-wncmN1avo48kkdZzNleXwq/9xFDDuAQDCOmbYcRTm2k=",
  "assets/icon-180.png": "sha256-Ap7MAGIoRXs20nhIWNEKC8JsDqSB7U/JxSeuUQACXNg=",
  "assets/icon-192.png": "sha256-LiMCiLnqOCKSGloDsT7oA4jSKfyyxy9h8wol+9IEqck=",
  "assets/icon-256.png": "sha256-7qyksrAixQLlSrlhEWuFnnutP8AN7ngt8lSEmTsEjoc=",
  "assets/icon-48.png": "sha256-ad0RxMeeaq0KY21diMfUnb4WvGRCxhaeYEYQSOIWBhg=",
  "assets/icon-512.png": "sha256-3xGtKYswhL5++E38WJIozvv9tjll21Td2i+f0yiR7gM=",
  "assets/icon-96.png": "sha256-gpyy51a9X39ijk4+ELwdBgcajHHx5oKHHaKsjeUvh7c=",
  "assets/icon-maskable-512.png": "sha256-qwNhgnIqN4rvPAnmGDRG7UqITrkrsDaRqCmylwDl0C4=",
  "assets/multilang-bundled.js": "sha256-tdHii36LgAENlNTBQJNdef7BMnxr5on+K1+kdDHxgLc=",
  "assets/piper.js": "sha256-VaoprcyO4KRGkxzEbZpgZPhN69kt80got8h6eHgd/qY=",
  "assets/pwa.js": "sha256-qa8UWlZ8nGq4jLAgmS0wdjzRZNkaBFnhwXHIC5mdFDM=",
  "assets/style.css": "sha256-Fe5+IdGBnnWKKNkWnN13opdJxFPJ1LNEa+QEocl4yvM=",
  "assets/updates.js": "sha256-Nh6P/cUhxQ1mqtIMJiV83HwrQXm6dU/+8veEnX8UkUY=",
  "assets/wikdict-bundled.js": "sha256-el7PZD4RPO6wt2Mr0sj43pL8TVOV+uMIH9Sn+bGIXA8=",
  "manifest.webmanifest": "sha256-m4WbFx55PH+AtUC9bIHftR0gbyM5MIWZqAOBfo8VHd8=",
  "offline-shell.txt": "sha256-sBraF2YqA6D/gZodtotVzhZtU5TZrb/ulGijzS5LlPM="
};
const urls = new Map(Object.entries(ASSETS).map(([file, hash]) =>
  [new URL(file, self.registration.scope).href, hash]
));
const entry = new URL('index.html', self.registration.scope).href;
const offlineShell = new URL('offline-shell.txt', self.registration.scope).href;

const dictionaryAssets = new Set(
  [...urls.keys()].filter(url => url.endsWith('-bundled.js'))
);
const dictionarySource = new URL('__rusdansk_dictionary_cache__', self.registration.scope).href;

async function findReusableDictionaries() {
  for (const key of await caches.keys()) {
    if (!key.startsWith(PREFIX + ':') || key === CACHE) continue;
    const candidate = await caches.open(key);
    const entries = new Set((await candidate.keys()).map(request => request.url));
    if (![...dictionaryAssets].every(url => entries.has(url))) continue;
    let valid = true;
    for (const url of dictionaryAssets) {
      const response = await candidate.match(url);
      if (!response) {
        valid = false;
        break;
      }
      const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', await response.arrayBuffer()));
      if ('sha256-' + btoa(String.fromCharCode(...hash)) !== urls.get(url)) {
        valid = false;
        break;
      }
    }
    if (valid) return key;
  }
  return null;
}

async function getDictionaryCache(cache) {
  const reference = await cache.match(dictionarySource);
  if (!reference) return cache;
  const key = await reference.text();
  return await caches.has(key) ? caches.open(key) : cache;
}

async function populateCache() {
  const cache = await caches.open(CACHE);
  // Reuse verified dictionaries from a previous release without duplicating
  // them during the update. The old worker stays usable if installation fails.
  const reusable = await findReusableDictionaries();
  const requests = [...urls].filter(([url]) => !reusable || !dictionaryAssets.has(url))
    .map(([url, integrity]) => new Request(url, {cache: 'reload', integrity, redirect: 'error'}));
  await cache.addAll(requests);

  const shell = await cache.match(offlineShell);
  await cache.put(entry, new Response(await shell.text(), {
    headers: {'Content-Type': 'text/html; charset=utf-8'}
  }));
  if (reusable) await cache.put(dictionarySource, new Response(reusable));
  else await cache.delete(dictionarySource);
}

async function cacheIsReady(cache) {
  const entries = new Set((await cache.keys()).map(request => request.url));
  const dictionaryCache = await getDictionaryCache(cache);
  const dictionaryEntries = new Set((await dictionaryCache.keys()).map(request => request.url));
  return entries.has(entry) && [...urls.keys()].every(url =>
    entries.has(url) || (dictionaryAssets.has(url) && dictionaryEntries.has(url)));
}

self.addEventListener('install', event => event.waitUntil((async () => {
  try {
    await populateCache();
    await self.skipWaiting();
  } catch (error) {
    console.warn('RusDansk could not cache the offline release:', error);
    throw error;
  }
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  const reference = await cache.match(dictionarySource);
  const retained = reference ? await reference.text() : null;
  const keys = await caches.keys();
  await Promise.all(keys.filter(key => key.startsWith(PREFIX + ':') && key !== CACHE && key !== retained)
    .map(key => caches.delete(key)));
  await self.clients.claim();
})()));

self.addEventListener('message', event => {
  const type = event.data?.type;
  if (type === 'rusdansk:claim') {
    event.waitUntil(self.clients.claim());
    return;
  }
  const port = event.ports[0];
  if (type === 'rusdansk:version') {
    port?.postMessage({ version: '1.15.1' });
    return;
  }
  if (!port || !['rusdansk:cache-status', 'rusdansk:cache-repair'].includes(type)) return;
  event.waitUntil((async () => {
    try {
      if (type === 'rusdansk:cache-repair') await populateCache();
      const cache = await caches.open(CACHE);
      port.postMessage({ready: await cacheIsReady(cache)});
    } catch {
      port.postMessage({ ready: false });
    }
  })());
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  url.search = '';
  const key = event.request.mode === 'navigate' && url.href === self.registration.scope
    ? entry
    : url.href;
  if (key !== entry && !urls.has(key)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(key);
    if (cached) return cached;
    if (dictionaryAssets.has(key)) {
      const dictionaryCache = await getDictionaryCache(cache);
      const dictionary = await dictionaryCache.match(key);
      if (dictionary) return dictionary;
    }
    return fetch(event.request);
  })());
});
